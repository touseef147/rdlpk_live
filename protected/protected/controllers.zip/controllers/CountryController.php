<?php



class CountryController extends Controller

{

	

		public function actionCreate()

	{	

		if(Yii::app()->session['user_array']['per5']=='1')

			{

		

		$error = '';

		 $connection = Yii::app()->db;

		if ((isset($_POST['country']) && empty($_POST['country'])) )

		{

			$error = 'Please complete all required fields <br />';

		}

			

		

		if(empty($error))

		        {

				  

				$country = ($_POST['country']);

				

			    ;

			  

				  

                $sql  = "INSERT INTO tbl_country(country) VALUES('".$country."')";		

                $command = $connection -> createCommand($sql);

                $command -> execute();
					
				$note="Message";
				$this->redirect(array('country/country_list','note'=>$note) );
				
				//$this->redirect(array('country/country_list'));

				

				

				}

		

		

			}

			exit;

	}

	

		public function actionaddcity()

	{

		

		if(Yii::app()->session['user_array']['per5']=='1')

			{

		

		$error = '';

		 $connection = Yii::app()->db;

		if ((isset($_POST['city']) && empty($_POST['city'])) && (isset($_POST['zipcode']) && empty($_POST['zipcode'])) )

		{

			$error = 'Please complete all required fields <br />';

		}

			

		

		if(empty($error))

	      {

				  

				$city = ($_POST['city']);

				$country_id =($_POST['country_id']);

				$zipcode =($_POST['zipcode']);

				$sql  = "INSERT INTO tbl_city(city,country_id,zipcode) VALUES('".$city."','".$country_id."','".$zipcode."')";		

                $command = $connection -> createCommand($sql);

                $command -> execute();

				//$this->redirect(array('country/city_list'));
				
				$note="Message";
				$this->redirect(array('country/city_list','note'=>$note) );
				
				

				

				}

		

		

			}

			exit;

	}

	

	public function actionCity()

	{

	 if(Yii::app()->session['user_array']['per5']=='1')

	{

		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))

		{	     $connection = Yii::app()->db;

				$country  = "SELECT * from tbl_country";

			    $result_charges = $connection->createCommand($country)->query();

			   $this->render('city',array('country'=>$result_charges));

				

			

		}

		else{

			$this->redirect(array('user/user'));

		

			}

	}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	

	

	

	

	public function actionCountry()

	{

	 if(Yii::app()->session['user_array']['per5']=='1')

	{

		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))

		{	

				$this->render('country');

			

		}

		else{

			$this->redirect(array('user/user'));

		

			}

	}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	

	

	function actionDoc_Upload()

	 {

		

		$this->layout='//layouts/front';

			$this->render('Doc_Upload');

		 

	}

	

	public function actionCountry_list()

	{	

	if(Yii::app()->session['user_array']['per5']=='1')

	  {

	 if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))

	   {

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 

	$sql = "SELECT * FROM tbl_country";

	$result = $connection->createCommand($sql)->query();

	$this->render('country_list',array('country'=>$result));

	   }

	  	else{

			$this->redirect (array('user/user'));

	  		}

	  }else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}	 

	  

	  public function actionCity_list()

	{	

	if(Yii::app()->session['user_array']['per5']=='1')

	  {

	 if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))

	   {

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 

	$sql = "SELECT * FROM tbl_city";

	$result = $connection->createCommand($sql)->query();

	$this->render('city_list',array('city'=>$result));

	   }

	  	else{

			$this->redirect (array('user/user'));

	  		}

	  }else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}	 

	

	public function loadModel($id)

	{

		$model=User::model()->findByPk($id);

		if($model===null)

			throw new CHttpException(404,'The requested page does not exist.');

		return $model;

	}

	

	 function actionDelete_country()

	 {     

	 			if(Yii::app()->session['user_array']['per5']=='1')

			{

	 

	 		  $uid=Yii::app()->session['user_array']['id'];

			  $uid;

			 

			   $connection = Yii::app()->db;

	  		   $sql  = "Delete from tbl_country where id='".$_REQUEST['id']."'";

               $command = $connection -> createCommand($sql);

               $command -> execute();

			   

		 	   $this->redirect(array("country/country_list"));		

			   

			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	 function actionDelete_city()

	 {     

	 			if(Yii::app()->session['user_array']['per5']=='1')

			{

	 

	 		  $uid=Yii::app()->session['user_array']['id'];

			  $uid;

			 

			   $connection = Yii::app()->db;

	  		   $sql  = "Delete from tbl_city where id='".$_REQUEST['id']."'";

               $command = $connection -> createCommand($sql);

               $command -> execute();

			   

		 	   $this->redirect(array("country/city_list"));		

			   

			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	/**

	 * Performs the AJAX validation.

	 * @param User $model the model to be validated

	 */

	protected function performAjaxValidation($model)

	{

		if(isset($_POST['ajax']) && $_POST['ajax']==='user-form')

		{

			echo CActiveForm::validate($model);

			Yii::app()->end();

		}

	}

}

