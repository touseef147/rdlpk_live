<?php



class MemberplotsalesController extends Controller

{
	
	
	
	public function actionUpdatemem_plot()

	 	{ 
			if(Yii::app()->session['user_array']['per12']=='1')
			{   
					$error='';

                                    $error =array();

									$connection = Yii::app()->db;  
									
								  if ((isset($_POST['plotno']) && empty($_POST['plotno']))){

								 $error="Plot Membership No required. <br>";

								 }
								
								 	$pn=$_POST['plotno'];
									if(!empty($pn)){
									 $q ="SELECT * from memberplot where plotno='".$pn."'"; 
									  
									  $result_q = $connection->createCommand($q)->queryRow();
									if ($result_q['plotno']==$pn){
									 $error ="Membership # Already Added Try Another. <br>";
									}}
										 if(empty($error)){
										
		
				 $sql  = "Update memberplot set plotno='".$pn."' where plot_id='".$_POST['plot_id']."'";	
					 
					   $command = $connection -> createCommand($sql);
                        $command -> execute();
		             
					 
					 echo'Membership No. Updated Successfully';
					 } else{
						 
						 echo $error;
						 }

		
			}
		

	}
	
		public function actionUpdatemember_plot()

	{	

	 if(Yii::app()->session['user_array']['per12']=='1')

			{

	

		$connection = Yii::app()->db;  

		$sql_country  = "SELECT * from tbl_country";

		$result_country = $connection->createCommand($sql_country)->query();

		
		$sql_plan  = "SELECT * from installment_plan";
		$result_plan = $connection->createCommand($sql_plan)->query();

		$sql_project  = "SELECT * from projects";

		$result_projects = $connection->createCommand($sql_project)->query();

				$sql = "SELECT

    plots.id

    , plots.street_id

    , plots.plot_size

    , plots.com_res

	, plots.price

	, plots.cstatus

	 , plots.size2

    , plots.create_date

	, plots.sector

	, plots.category_id

	, plots.status

	, plots.image

	, plots.plot_detail_address

	, memberplot.plotno
	, memberplot.noi
, memberplot.insplan

    , projects.project_name

	, categories.name

	, streets.street
    , members.cnic
	
	

	

FROM

    plots

    Left JOIN streets  ON (plots.street_id = streets.id)

	Left JOIN projects  ON (plots.project_id = projects.id)

	Left JOIN memberplot  ON (plots.id = memberplot.plot_id)
    Left JOIN members ON (member_id = members.id)

	Left JOIN categories  ON (plots.category_id = categories.id) where  plots.id='".$_REQUEST['id']."'";

	//	  $sql = "SELECT * from plots where type='plot' and id='".$_REQUEST['id']."'";

		$result = $connection->createCommand($sql)->query();

		$this->render('updatemember_plot',array('plot'=>$result,'projects'=>$result_projects,'country'=>$result_country,'plan'=>$result_plan));

		

			}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

				

	}
	function actionGenpdf()
	{ if (!empty($_POST['submit'])){

    //require_once();
    include Yii::app()->baseUrl."/dompdf/dompdf_config.inc.php";
	$stream=TRUE;
    $dompdf = new DOMPDF();
	$html=$_POST['html'];
	//echo $html;exit;
	$filename='PDF File';
    $dompdf->set_paper('letter','landscape');
	$dompdf->load_html($html);
    $dompdf->render();
	$dompdf->set_base_path(realpath(APPLICATION_PATH . 'styles.css'));
    if ($stream) {
        $dompdf->stream($filename.".pdf");
    } else {
        return $dompdf->output();
    }
}}
	public function actionInstallment_up()

     	{

		if( Yii::app()->session['user_array']['per12']=='1' && isset(Yii::app()->session['user_array']['username']))

			{

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 
 $sql_payment  = "SELECT * FROM installpayment where id='".$_GET['id']."'";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

	$this->render('installment_up',array('payments'=>$result_payments));

	
			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

    }
	public function actionCapture_image()

     	{

		



    $connection = Yii::app()->db; 
	$this->render('index');

	
			
    }

	public function actionInstallment_update()

     	{

		if(Yii::app()->session['user_array']['per12']=='1'&& isset(Yii::app()->session['user_array']['username']))

			{

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 
 $sql_payment  = "SELECT * FROM installpayment where id='".$_GET['id']."'";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

	$this->render('installment_update',array('payments'=>$result_payments));

	
			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

    }
	public function actionPhotofortransfer(){
	
		echo 123;exit;
		$name = $_REQUEST['id'];
		
		$newname="images/imagetransfer/".$name.".jpg";
		$file = file_put_contents( $newname, file_get_contents('php://input') );
		 $connection = Yii::app()->db;  
      $sql3 = "UPDATE transferplot SET image='".$_REQUEST['id']."' WHERE id = '".$_REQUEST['id']."'"; 	
    
	$command = $connection -> createCommand($sql3);
	$command -> execute();
		

	  		$url = 'http://rdlpk.com/' . $newname;
		print "$url\n";
		}

	public function actionCreate()

	{

		if(Yii::app()->session['user_array']['per12']=='1')

			{

		

		$model=new memberplot;

		$error = '';

		if ((isset($_POST['project_id']) && empty($_POST['project_id'])) || (isset($_POST['street_id']) && empty($_POST['street_id'])) || (isset($_POST['plot_id']) && empty($_POST['plot_id'])) || (isset($_POST['plot_size']) && empty($_POST['plot_size']))  || (isset($_POST['cnic']) && empty($_POST['cnic'])) )

		{

			$error = 'Please complete all required fields <br />';

		}

		

		

		if(empty($error))

		{

				$model->project_id = mysql_real_escape_string($_POST['project_id']);

				$model->street_id = mysql_real_escape_string($_POST['street_id']);

				$model->plot_id = mysql_real_escape_string($_POST['plot_id']);

				$model->plot_size = mysql_real_escape_string($_POST['plot_size']);

				$model->cnic = mysql_real_escape_string($_POST['cnic']);

				$model->create_date = date('Y-m-d h:i:s');

				try {

						$model->save();

					} catch (Exception $e) {

						echo 'Caught exception: ',  $e->getMessage(), "\n";

					}		

		}else

		{	

			echo json_encode(array($error,$_POST));

		}

		exit;

			}

	 }

	 function actionEdit()

	 {

		 if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))

		{

			$this->layout='column3';

			$this->render('edit_register');

		}

		 

	}

		public function actionDownload()

{

	$plot_id = $_GET['id'];

	$this->layout='//layouts/back';

	$connection = Yii::app()->db;  

		$sql_member  = "SELECT

    members.id
	,memberplot.plotno
	, members.name

    , members.sodowo

    , members.cnic

    , members.address

    , members.dob

    , members.email

    , members.phone

    , members.image

    , members.nomineename

	,members.city_id

	,plots.street_id

	,plots.type

	,plots.plot_size

	,plots.com_res

	,plots.sector

	,plots.size2
	,size_cat.size

	,plots.plot_detail_address

	,memberplot.create_date
	,streets.street
	,sectors.sector_name

	FROM

    memberplot

    LEFT JOIN members 

        ON (memberplot.member_id = members.id ) 

		left join plots on memberplot.plot_id=plots.id
		left join sectors on plots.sector=sectors.id
		left join size_cat on plots.size2=size_cat.id
		left join streets on plots.street_id=streets.id

		where memberplot.plot_id=".$plot_id;

		

		$member_result = $connection->createCommand($sql_member)->queryAll();

	 	$this->render('pdf',array('member'=>$member_result)); 

}



	public function actionAjaxRequest7($val1)

	{	

		$connection = Yii::app()->db;  

		$sql_plot  = "SELECT * from installment_plan where project_id='".$val1."' ";

		$result_plots = $connection->createCommand($sql_plot)->query();

			

		$plot=array();

		foreach($result_plots as $plo){

			$plot[]=$plo;

			} 

		

	echo json_encode($plot); exit();

	}
	public function actionProjectcode($val1)

	{	

		$connection = Yii::app()->db;  

		$sql_plot  = "SELECT * from projects where id='".$val1."' ";

		$result_plots = $connection->createCommand($sql_plot)->query();

			

		$plot=array();

		foreach($result_plots as $plo){

			$plot[]=$plo;

			} 

		

	echo json_encode($plot); exit();

	}
	public function actionSizecode($size)

	{	

		$connection = Yii::app()->db;  

		$sql_plot  = "SELECT * from size_cat where id='".$size."' ";

		$result_plots = $connection->createCommand($sql_plot)->query();

			

		$plot=array();

		foreach($result_plots as $plo){

			$plot[]=$plo;

			} 

		

	echo json_encode($plot); exit();

	}


public function actionPo()

	{	
	$i=0;
$count= count($_POST['dueamount']);
do{
	$connection = Yii::app()->db;  
	$sql1="UPDATE installpayment SET paidamount='".$_POST['paidamount'][$i]."',dueamount='".$_POST['dueamount'][$i]."', lab='".$_POST['lab'][$i]."',due_date='".$_POST['due_date'][$i]."',paid_date='".$_POST['paid_date'][$i]."' WHERE id='".$_POST['ppid'][$i]."' ";	
    $command = $connection -> createCommand($sql1);
    $command -> execute();
	$i++;
	}while($i<$count);
	$this->redirect(array("installment_edit?id=".$_POST['ploid'].""));
	
	}

	public function actionTransferplot()
	{	

	 
	$this->layout='//layouts/back';
	$plotid = $_GET['plot_id'];		 
	$connection = Yii::app()->db;  
	$sql_plotedtails = "SELECT mp.member_id,mp.create_date, m.name,m.name,m.sodowo,m.cnic,p.id   plot_id,p.plot_detail_address,p.plot_size,s.street, j.project_name 
FROM memberplot mp left join members m on mp.member_id=m.id left join plots p on mp.plot_id=p.id left join streets s on p.street_id=s.id left join projects j on s.project_id=j.id 
   WHERE p.id ='".$plotid."' ";
	$plotdetails = $connection->createCommand($sql_plotedtails)->queryRow();
	$this->render('transferplot',array('plotdetails'=>$plotdetails));
	exit();
	}

		public function actionCrequest()
	 	{
			
		    $error ='';
	   
									  $connection = Yii::app()->db;  
									
									      $sql1="UPDATE plots set status='Allotted' WHERE id='".$_REQUEST['plot_id']."' ";	
        		   					 $command = $connection -> createCommand($sql1);
                      				 $command -> execute();
	            					    $sql="DELETE FROM transferplot WHERE plot_id='".$_REQUEST['plot_id']."'  ";	 
        		   					 
									 $command = $connection -> createCommand($sql);
                      				 $command -> execute();
									 	
									 $this->redirect (array('memberplot/member_lis'));
	
			}
	public function actionRequestTransfer()
	 	{
			
		    $error ='';
	   
									  $connection = Yii::app()->db;  
									 $base=$_POST['cnic']; 
									 $uid=Yii::app()->session['user_array']['id'];
									 $sql ="SELECT * from members where cnic='".$base."'"; 
									  $result_data = $connection->createCommand($sql)->queryRow();
									  
									  $sql1 ="SELECT * from transferplot where plot_id='".$_POST['plot_id']."'"; 
									  $result_data1 = $connection->createCommand($sql1)->queryRow();
									  if(!empty($result_data1)&& ($result_data1['status']!='Rejected')){
										
										  $error="Already Requested. <br>";
										
										  }
										  
									if ((isset($base) && empty($base))){
									 $error="CNIC required. <br>";
									}elseif(empty($result_data)){
									 $error.='Applicant Containing '.$base.' CNIC is Not Register Member <br>';
									 }elseif($result_data['status']!=1){
									 $error.='Applicant Containing '.$base.' CNIC is Not Active Register Member.<br>';
									}
									
										if(!empty($error)){
											echo $error;exit;
											}else{
                                        $transferto_memberid = $result_data['id'];
				  		                
	            					   $sql="INSERT INTO transferplot SET plot_id='".$_POST['plot_id']."',uid='".$uid."',transferfrom_id='".$_POST['transfer_from_memberid']."',transferto_id='".                                     $transferto_memberid."',status='New Request',cmnt='New Request',create_date='".date('Y-m-d H:i:s')."' ";	 
        		   					 $command = $connection -> createCommand($sql);
                      				 $command -> execute();
									 	
									 $sql1="UPDATE plots set status='Requested(T)' WHERE id='".$_POST['plot_id']."' ";	 
        		   					 $command = $connection -> createCommand($sql1);
                      				 $command -> execute();
									 	echo "Plot transfer request has been sent successfully ";
										echo '<form action="timage"  enctype="multipart/form-data" method="post"  >';
										echo'<input type="hidden" name="plot_id" value="'.$_POST['plot_id'].'" />';
										echo '<input type="file" name="image">
										<input type="submit" name="upload" value="Upload">
										</form>';
	}
			}
	public function actionTimage(){
		
		 $connection = Yii::app()->db;  
    echo 123;exit;
				 $path="images/imagetransfer/";
				 $image=$_FILES['image']["name"];
				$newfilename = $_FILES["image"]["name"];
				
				move_uploaded_file($_FILES["image"]["tmp_name"],
				$path.$image);
				echo $sql="UPDATE transferplot SET image='".$newfilename."' WHERE id='".$_POST['plot_id']."'";exit;
					$command = $connection -> createCommand($sql);
	               $command -> execute();
					$this->redirect('memberplot/member_lis'); 
		
		}
	public function actionAlotaplot()

	 	{ 
		
          
			if(Yii::app()->session['user_array']['per12']=='1')

			{   
					$error='';

                                    //$error =array();

									$connection = Yii::app()->db;  

									 $base=$_POST['cnic']; 
									 $sql ="SELECT * from members where cnic='".$base."'"; 
									  $result_data = $connection->createCommand($sql)->queryRow();
									if ((isset($base) && empty($base))){
									 $error="CNIC required. <br>";
									}elseif(empty($result_data)){
									 $error.='Applicant Containing '.$base.' CNIC is Not Register Member <br>';
									 }elseif($result_data['status']!=1){
									 $error.='Applicant Containing '.$base.' CNIC is Not Active Register Member.<br>';
									}
									
									if ((isset($_POST['plot_id']) && empty($_POST['plot_id']))){
									 $error.="Plot No Required. <br>";}
									
										 if ((isset($_POST['project']) && empty($_POST['project']))){
								    	 $error.="Please Select Project. <br>";
										 }
										 if ((isset($_POST['street_id']) && empty($_POST['street_id']))){
										 $error.="Please Select Street <br>";
									 }
								  
								  if ((isset($_POST['noi']) && empty($_POST['noi']))){

									 $error.="No.Of Installment required. <br>";
									 }
									  if (!empty($_POST['noi']) ){
										  $noi='';
										  $noi=$_POST['noi'];
										if($noi<=0){
									 $error.="No.Of Installment Must be 1 or More . <br>";
									 }}
							  if ((isset($_POST['insplan']) && empty($_POST['insplan']))){

									 $error.="Installment Plan required. <br>";
								  }
								

								  if ((isset($_POST['plotno']) && empty($_POST['plotno']))){

								 $error.="Plot Membership No required. <br>";

								 }
								
								 	$pn=$_POST['procode'].'-'.$_POST['plotno'].'-'.$_POST['sizecode'];
									if(!empty($pn)){
									$q ="SELECT * from memberplot where plotno='".$pn."'"; 
									  $result_q = $connection->createCommand($q)->queryRow();
									if ($result_q['plotno']==$pn){
									 $error.="Membership # Already Added Try Another. <br>";
									}
									}
										 if(empty($error)){
											 	
	
										 $uid=Yii::app()->session['user_array']['id'];
										 
				 $sql  = "INSERT INTO memberplot (plot_id,user_name,member_id,create_date,noi,insplan,status,plotno) 

	VALUES ('".$_POST['plot_id']."','".$uid."','".$result_data['id']."','".date('Y-m-d H:i:s')."','".$_POST['noi']."','".$_POST['insplan']."','New','".$pn."')";	
					 
					   $command = $connection -> createCommand($sql);
                        $command -> execute();
						$insert_id = Yii::app()->db->getLastInsertID();
			
			$discount  = "INSERT INTO discnt (ms_id,status,discount)VALUES ('".$insert_id."','New','".$_POST['disc']."')";		
  			$command = $connection -> createCommand($discount);
            $command -> execute();				
		
		$update  = "UPDATE plots set status= 'Requested' WHERE id='".$_REQUEST['plot_id']."'";		
  
					   $command = $connection -> createCommand($update);
                        $command -> execute();
						$sqlinstalplan ="SELECT * from installment_plan where tno='".$_POST['insplan']."'"; 
						$dataplan = $connection->createCommand($sqlinstalplan)->queryRow();
							
						$tno=$_POST['noi'];
						$insplan=$_POST['insplan'];
						$insert=0;
						$create=$_POST['date'];
						$instalno=0;
						$lab=0;
						
						do{
						$lab++;
						$instalno++;	
						
						$tno=$_POST['noi'];
						
						if($instalno==1){$tno=$tno+1;}
						 $sqlinstall="INSERT INTO installpayment SET lab='".$dataplan['lab'.$lab.'']."',dueamount='".$dataplan[''.$instalno.'']."', due_date='".$create."', plot_id='".$_POST['plot_id']."',mem_id='".$result_data['id']."'"; 
						$next_due_date = strtotime($create.' + '.$tno.' Months');
						$create=date('d-m-Y', $next_due_date);			
   		               $command = $connection -> createCommand($sqlinstall);
                        $command -> execute();
						$insert++;
						
						}while($insert<$insplan);
						
					echo 'Plot Allotment Request Sent For Verification';
exit;
						}

						  else if(!empty($error)){ 
 
						    echo $error;



             } 

		

					

		
			}
		

	}

	



	public function actionInstalment()

	{

		if(Yii::app()->session['user_array']['per12']=='1')

			{

		
		$error =array();
		$error = '';

		if((isset($_POST['payment-type']) && empty($_POST['payment-type'])) ||(isset($_POST['plot_id']) && empty($_POST['plot_id'])) || (isset($_POST['member_id']) && empty($_POST['member_id'])) || (isset($_POST['amount']) && empty($_POST['amount'])) || (isset($_POST['paid-as']) && empty($_POST['paid-as'])) || (isset($_POST['detail']) && empty($_POST['detail'])) || (isset($_POST['date']) && empty($_POST['date'])))

		{

			$error = 'Please complete all required fields <br />';

		}

			if(empty($error)){

					  // Insert in to member a new member

                                        $connection = Yii::app()->db;  

                                   
									 $sql  = 'INSERT INTO plotpayment  (payment_type, plot_id, mem_id, amount,discount, paidas, detail, surcharge, date, create_date ) VALUES ("'.$_POST['payment_type'].'","'.$_POST['plot_id'].'", "'.$_POST['member_id'].'", "'.$_POST['amount'].'", "'.$_POST['discount'].'",  "'.$_POST['paid-as'].'", "'.$_POST['detail'].'", "'.$_POST['surcharge'].'", "'.$_POST['date'].'", "'.date('Y-m-d h:i:s').'")';		                  $command = $connection -> createCommand($sql);

                                        $command -> execute();
										echo $note="Payment Added Successfully";

			}
				if(!empty($error)){
					echo $error;
				}

	}

	

	}

	////////////////////////////////////////PLOT CHARGES FUNCTION////////////////////

	public function actioncharge()

	{

		if(Yii::app()->session['user_array']['per12']=='1')

			{

		

		$error =array();
		$error = '';

		if((isset($_POST['plot_id']) && empty($_POST['plot_id']))  ||(isset($_POST['duedate']) && empty($_POST['duedate']))  || (isset($_POST['charges_id']) && empty($_POST['charges_id'])) || (isset($_POST['comment']) && empty($_POST['comment']))|| (isset($_POST['total']) && empty($_POST['total'])))

		{

			$error = 'Please complete all required fields <br />';

		}

			if(empty($error)){
				    $connection = Yii::app()->db;
					$sqlchrgesdetail='Select * from charges where id="'.$_POST['charges_id'].'"';
					 $resultcharges = $connection->createCommand($sqlchrgesdetail)->queryRow();
                      $sql  = 'INSERT INTO plotpayment  (plot_id,payment_type,amount, remarks,duedate) VALUES ("'.$_POST['plot_id'].'","'.$resultcharges['name'].'", "'.$_POST['total'].'","'.$_POST['comment'].'","'.$_POST['duedate'].'")';                      
					    $command = $connection -> createCommand($sql);
			            $command -> execute();
						echo "Charges Added Successfully";
			        }

					if(!empty($error)){
					echo $error;
				}

	}

	}

	

	////////////////////////////////////////////////////////////////////////////////
/*
	public function actionUpdate($id)

	{

		$model=$this->loadModel($id);

	if(isset($_POST['User']))

		{

			$model->attributes=$_POST['User'];

			if($model->save())

				$this->redirect(array('view','id'=>$model->user_id));

		}

		$this->render('update',array(

			'model'=>$model,

		));

	}*/

	public function actionDelete($id)

	{

		$this->loadModel($id)->delete();



		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser

		if(!isset($_GET['ajax']))

			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));

	}

public function actionDelete_Ins()

	{
		if(Yii::app()->session['user_array']['per12']=='1')
			{
		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))
		{	
   
			 $connection = Yii::app()->db; 
			  $sql_del = "DELETE from installpayment where id=".$_GET['did'];
			 $command = $connection -> createCommand($sql_del);
             $command -> execute();
			 $this->redirect (array('memberplot/installment_details?id='.$_GET['id'].''));
		}

	  else{

		  $this->redirect (array('user/user'));

	  }}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	
public function actionDelete_Charges()

	{
		if(Yii::app()->session['user_array']['per12']=='1')
			{
		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))
		{	
   
			 $connection = Yii::app()->db; 
			  $sql_del = "DELETE from plotpayment where id=".$_GET['id'];
			 $command = $connection -> createCommand($sql_del);
             $command -> execute();
			 $this->redirect (array('memberplot/payment_details?id='.$_GET['pid'].''));
		}

	  else{

		  $this->redirect (array('user/user'));

	  }}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	

	public function actionIndex()

	{

		

		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))

		{

			 $this->redirect(array('datasource'));

		}else

		{

			$error = '';

			$layout='//layouts/column1';

			

			$this->render('index');

		}

	}

	

	

	

	public function actionSearch_memberplot()

	{	

	  

		 if(Yii::app()->session['user_array']['per12']=='1')

			{

		

	$connection = Yii::app()->db;  

		$sql_project  = "SELECT * from projects";

		$result_projects = $connection->createCommand($sql_project)->query();

			$this->render('search_memberplot',array('projects'=>$result_projects));

			}

			else{

				$this->redirect('dashboard');

			}

	}

	public function actionPlotprice()
	{	//$_REQUEST['pid']=1;
		$connection = Yii::app()->db;  
		$sql_plot  = "SELECT * from plots where id='".$_REQUEST['pid']."'";
		$result_plot = $connection->createCommand($sql_plot)->query();

		$plot=array();

		foreach($result_plot as $plo){
			$plot[]=$plo;
		} 
	echo json_encode($plot);exit;
	}

	public function actionCatprice()
	{	
		$connection = Yii::app()->db;  
		//$_REQUEST['pid']=1;
		//$_REQUEST['pid']=7;
		$sql_cat  = "SELECT * from cat_plot where plot_id='".$_REQUEST['pid']."'";
		$result_cat = $connection->createCommand($sql_cat)->queryAll();
		
		$cat=array();
		foreach($result_cat as $cate){
			$sql  = "SELECT * from categories where id='".$cate['cat_id']."'";
			$result = $connection->createCommand($sql)->queryRow();
			//echo $result['title'];exit;
			$result1=1;
			if($result!==''){
			//echo $result['title'];
			$sql1  = "SELECT * from charges where name LIKE '%".$result['title']."%'";
			$result1 = $connection->createCommand($sql1)->queryRow();}
			if($result1!==1 && $result1!==false && $result1!==''){
			$cat[]=$result1;
			}
			
		} 
	
		 
	echo json_encode($cat);exit;
	

	}

	public function actionAjaxRequest3($val1)

	{	

		$connection = Yii::app()->db;  

		$sql_city  = "SELECT * from tbl_city where country_id='".$val1."'";

		$result_city = $connection->createCommand($sql_city)->query();

			

		$city=array();

		foreach($result_city as $cit){

			$city[]=$cit;

			} 

		

	echo json_encode($city); exit();

	}
	public function actionAjaxRequest12($val1)

	{	

		$connection = Yii::app()->db;  

		$sql_city  = "SELECT * from sectors where project_id='".$val1."'";

		$result_city = $connection->createCommand($sql_city)->query();

			

		$city=array();

		foreach($result_city as $cit){

			$city[]=$cit;

			} 

		

	echo json_encode($city); exit();

	}

	public function actionPayment()

	{	

	if(Yii::app()->session['user_array']['per12']=='1')

			{

		

			$this->layout='//layouts/back';

			$connection = Yii::app()->db;

			$sql_projects  = "SELECT * from plothistory where transferfrom_id='".$_REQUEST['id']."'";

			$result_projects = $connection->createCommand($sql_projects)->query();

			

			$sql_page  = "SELECT mp.member_id,mp.create_date, m.name,m.username,m.sodowo,m.cnic, m.address,p.id   ,mp.plot_id,p.plot_detail_address,p.plot_size,s.street, j.project_name 

FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id

left join projects j on s.project_id=j.id 

WHERE plot_id ='".$_REQUEST['id']."'";

			$result_pages = $connection->createCommand($sql_page)->query();

				

			$sql_charges  = "SELECT * from charges where project_id='".$_REQUEST['pid']."'";

			$result_charges = $connection->createCommand($sql_charges)->query();

			

			$this->render('payment',array('projects'=>$result_projects,'pages'=>$result_pages,'charges'=>$result_charges));

			}

	}

	///////////////////////////PLOT CHARGES////////////////////

	

	public function actionPlotcharges()

	{	

			$this->layout='//layouts/back';

			$connection = Yii::app()->db;

			$plot_id =$_REQUEST['id'];
						
			$sql_charges  = "SELECT * from charges where project_id='".$_REQUEST['pid']."'";
			$result_charges = $connection->createCommand($sql_charges)->query();

			$sql_plots  = "SELECT * from plots where id='".$plot_id."'";
			$result_plots = $connection->createCommand($sql_plots)->query();
			

			$this->render('plotcharges',array('plots'=>$result_plots,'charges'=>$result_charges));

	}

	

	

	

	

	//////////////////////////////////////////////////////////////

	 

	public function actionMemberplot()

	{	

	 if(Yii::app()->session['user_array']['per12']=='1')

			{

	

		$connection = Yii::app()->db;  

		$sql_country  = "SELECT * from tbl_country";
		$result_country = $connection->createCommand($sql_country)->query();

		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();

		$sql_plan  = "SELECT ip.*,p.project_name from installment_plan ip
		left join projects p on ip.project_id=p.id
		
		 ";
		$result_plan = $connection->createCommand($sql_plan)->query();
	
		

		$this->render('memberplot',array('projects'=>$result_projects,'country'=>$result_country,'plan'=>$result_plan));

		

			}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

				

	}

		public function actionAllotplot()

	{	

	 if(Yii::app()->session['user_array']['per12']=='1')

			{

	

		$connection = Yii::app()->db;  

		$sql_country  = "SELECT * from tbl_country";

		$result_country = $connection->createCommand($sql_country)->query();

		
		
		 
		$sql_plan  = "SELECT * from installment_plan where project_id='".$_REQUEST['pro']."'";
		$result_plan = $connection->createCommand($sql_plan)->query();

		$sql_project  = "SELECT * from projects";

		$result_projects = $connection->createCommand($sql_project)->query();

				$sql = "SELECT

   plots.id




    , plots.street_id



    , plots.plot_size



    , plots.com_res



	, plots.price
	, plots.cstatus
	 , plots.size2
    , plots.create_date
	, plots.sector
	, plots.category_id
	, plots.status
	, plots.image
	, plots.plot_detail_address
	, memberplot.plotno
    , projects.project_name
	, projects.code as pcode
	, categories.name
	, streets.street
	, sectors.sector_name
	, size_cat.code as scode
FROM
    plots
    Left JOIN streets  ON (plots.street_id = streets.id)
	Left JOIN size_cat  ON (plots.size2 = size_cat.id)
	Left JOIN sectors  ON (plots.sector = sectors.id)
	Left JOIN projects  ON (plots.project_id = projects.id)
	Left JOIN memberplot  ON (plots.id = memberplot.plot_id)
	Left JOIN categories  ON (plots.category_id = categories.id) where type='plot' and plots.id='".$_REQUEST['id']."'";

	//	  $sql = "SELECT * from plots where type='plot' and id='".$_REQUEST['id']."'";

		$result = $connection->createCommand($sql)->query();

		$this->render('allotplot',array('plot'=>$result,'projects'=>$result_projects,'country'=>$result_country,'plan'=>$result_plan));

		

			}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

				

	}

	public function actionMember_list()

	{	

			if(Yii::app()->session['user_array']['per12']=='1')

			{

    

	$connection = Yii::app()->db; 

	$sql_member = "SELECT mp.member_id,mp.create_date, m.name,m.sodowo,m.cnic,p.plot_detail_address,mp.status, 					p.plot_size,s.street, j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id

left join projects j on p.project_id=j.id where p.type='plot' and mp.status='Approved'";

		$result_members = $connection->createCommand($sql_member)->query();

		$this->render('member_list',array('members'=>$result_members));

			}

			else

			{

			$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard");

			}

	}
public function actionSearchreq()
	 	{
		$where='';
		$and=false;
		$and = false;
			if (!empty($_POST['name1'])){
				$where.=" m.name LIKE '%".$_POST['name1']."%'";
				$and = true;
			}
			if (!empty($_POST['sodowo'])){				
				if ($and==true)
				{
					$where.=" and m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}
				else
				{

					$where.=" m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}
				$and=true;

			}

			if (!empty($_POST['cnic'])){

				if ($and==true)
				{
					$where.=" and m.cnic =".$_POST['cnic']."";
				}
				else
				{
					$where.=" m.cnic =".$_POST['cnic']."";
				}
				$and=true;
			}
			if (!empty($_POST['project_name'])){
				if($and==true)
				{
					$where.=" AND p.project_id LIKE '%".$_POST['project_name']."%'";
				}
				else
				{
					$where.="  p.project_id LIKE '%".$_POST['project_name']."%'";
				}
				$and=true;
			}
			if (!empty($_POST['plot_detail_address'])){

				if ($and==true)
				{
					$where.=" and p.plot_detail_address ='".$_POST['plot_detail_address']."'";
				}
				else
				{
					$where.="p.plot_detail_address='".$_POST['plot_detail_address']."'";
				}
				$and==true;
			}
			if (!empty($_POST['plotno'])){

				if ($and==true)
				{
					$where.=" and mp.plotno ='".$_POST['plotno']."'";
				}
				else
				{
					$where.="mp.plotno='".$_POST['plotno']."'";
				}
				$and==true;
			}
	$connection = Yii::app()->db; 
     $sql_member = "SELECT mp.member_id,mp.plotno,mp.create_date,p.id,p.type,p.project_id,m.name,mp.plotno,m.image,m.sodowo,m.cnic,p.plot_detail_address,mp.plot_id,mp.status,p.plot_size,p.project_id,p.street_id,s.street,s.id,j.id,j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id


left join projects j on p.project_id=j.id

where $where and p.type='plot' and mp.status='Approved' "; 
	
		$result_members = $connection->createCommand($sql_member)->query();
	
	    
 
	$count=0;

	if ($result_members!=''){

		$home=Yii::app()->request->baseUrl; 
$check=1;
    $res=array();

            foreach($result_members as $key){

            $count++;
			//echo $count.' result found';
			 echo '<tr><td>'.$key['plotno'].'</td><td><img src="/upload_pic/'.$key['image'].'" width="100" height="130" /></td><td><a href="'.$home.'/index.php/user/memhistory?id='.$key['member_id'].'">'.$key['name'].'</a></td><td>'.$key['sodowo'].'</td><td>'.$key['cnic'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['plot_id'].'">'.$key['plot_detail_address'].'</a><td>'.$key['plot_size'].'</td><td>'.$key['street'].'</td><td>'.$key['project_name'].'</td><td><div class="dropdown">
                 <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
                  Dropdown
                  <span class="caret"></span>
                  </button>
                  <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
			 
			 <li role="presentation"><a target="_blank" href="payment_details?id='.$key['plot_id'].'&& pid='.$key['project_id'].'">Payment Details</a></li>
			 
'; 

$sqltest = "SELECT * FROM  plots where id='".$key['plot_id']."'  "; 
	
		$resulttest = $connection->createCommand($sqltest)->query();
	
	echo'
	<script>
    function ConfirmDelete()
    {
      var x = confirm("Are you sure you want to cancel?");
      if (x)
          return true;
      else
        return false;
    }
</script>    
	
	';
             
  		}

	}else{echo '';}exit;
	echo $count.' result found' ;
	    if(isset($_POST['username']) && empty($_POST['username']))

			{

				$error = 'Please enter username<br>';

			}

			if(isset($_POST['password']) && empty($_POST['password']))

			{

				$error .= 'Please enter Password<br>';

			}

			if(empty($error))

			{

				  $username = $_POST['username'];

				 $password = md5($_POST['password']);

				  $connection = Yii::app()->db;  

				   $sql = "SELECT * FROM user where username ='".$username."' AND  password='".$password."' AND status=1";

				  $result_data = $connection->createCommand($sql)->queryRow();

				  if($result_data)

				  {

						Yii::app()->session['user_array'] = $result_data;

						echo 1;exit();

				  }else

				  {

					 echo "Invalid Username and Password"; 

				  }

			}else

			{

				echo $error;

			}

	exit;	 



	}
	
	public function actionSearchreqf()
	 	{
		$where='';
		
		$and = false;
			if (!empty($_POST['name1'])){
				$where.=" m.name LIKE '%".$_POST['name1']."%'";
				$and = true;
			}
			if (!empty($_POST['sodowo'])){				
				if ($and==true)
				{
					$where.=" and m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}
				else
				{

					$where.=" m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}
				$and=true;

			}


			if (!empty($_POST['cnic'])){

				if ($and==true)
				{
					$where.=" and m.cnic =".$_POST['cnic']."";
				}
				else
				{
					$where.=" m.cnic =".$_POST['cnic']."";
				}
				$and=true;
			}
			if (!empty($_POST['project_name'])){
				if($and==true)
				{
					$where.=" AND p.project_id LIKE '%".$_POST['project_name']."%'";
				}
				else
				{
					$where.="  p.project_id LIKE '%".$_POST['project_name']."%'";
				}
				$and=true;
			}
			if (!empty($_POST['plot_detail_address'])){

				if ($and==true)
				{
					$where.=" and p.plot_detail_address ='".$_POST['plot_detail_address']."'";
				}
				else
				{
					$where.="p.plot_detail_address='".$_POST['plot_detail_address']."'";
				}
				$and==true;
			}
			if (!empty($_POST['plotno'])){

				if ($and==true)
				{
					$where.=" and mp.plotno ='".$_POST['plotno']."'";
				}
				else
				{
					$where.="mp.plotno='".$_POST['plotno']."'";
				}
				$and==true;
			}
	$connection = Yii::app()->db; 
     $sql_member = "SELECT mp.member_id,mp.plotno,tp.status,mp.create_date,mp.fstatus,p.id,p.type,p.project_id,m.name,mp.plotno,m.image,m.sodowo,m.cnic,p.plot_detail_address,mp.plot_id,mp.status,p.plot_size,p.status as pstatus,p.project_id,p.street_id,s.street,s.id,j.id,j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id
left join transferplot tp on p.id=tp.id

left join streets s on p.street_id=s.id


left join projects j on p.project_id=j.id

where $where and p.type='file' "; 
	
		$result_members = $connection->createCommand($sql_member)->query();
	
	    
 
	$count=0;

	if ($result_members!=''){

		$home=Yii::app()->request->baseUrl; 
$check=1;
    $res=array();

            foreach($result_members as $key){

            $count++;
			//echo $count.' result found';
			
			 echo '<tr><td>'.$key['plotno'].'</td><td><img src="/upload_pic/'.$key['image'].'" width="100" height="130" /></td><td><a href="'.$home.'/index.php/user/memhistory?id='.$key['member_id'].'">'.$key['name'].'</a></td><td>'.$key['sodowo'].'</td><td>'.$key['cnic'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['plot_id'].'">'.$key['plot_detail_address'].'</a><td>'.$key['plot_size'].'</td>';
			 
			 echo '<td>';

$M='';
			if($key['pstatus']=='Requested'){if(!empty($key['fstatus'])){$M='M';}else{$F='F'; } echo 'Requested('.$M.$F.')';

			}else{echo $key['pstatus'];}
			echo '</td>
			 
			 <td>'.$key['project_name'].'</td><td><a target="_blank" href="payment_details?id='.$key['plot_id'].'&& pid='.$key['project_id'].'">Payment Details</a>';

 

 

			}
			 
			
			
			
			}else{echo '';}
 exit;
	echo $count.' result found' ;exit;

	    if(isset($_POST['username']) && empty($_POST['username']))

			{

				$error = 'Please enter username<br>';

			}

			if(isset($_POST['password']) && empty($_POST['password']))

			{

				$error .= 'Please enter Password<br>';

			}

			if(empty($error))

			{

				  $username = $_POST['username'];

				 $password = md5($_POST['password']);

				  $connection = Yii::app()->db;  

				   $sql = "SELECT * FROM user where username ='".$username."' AND  password='".$password."' AND status=1";

				  $result_data = $connection->createCommand($sql)->queryRow();

				  if($result_data)

				  {

						Yii::app()->session['user_array'] = $result_data;

						echo 1;exit();

				  }else

				  {

					 echo "Invalid Username and Password"; 

				  }

			}else

			{

				echo $error;

			}

	exit;	 



	}
	
	
	
	public function actionMember_lis()
	{	
			$name='';
			$sodowo='';
			$cnic='';
			$plotno='';
			$project_name='';
			$plot_detail_address='';
			$where='';
			$and = false;
			if (!empty($_POST['name'])){
				$where.=" m.name =".$_POST['name']."";
				$and = true;
			}
			if (!empty($_POST['sodowo'])){				
				if ($and==true)
				{
					$where.=" and m.sodowo =".$_POST['sodowo']."";

				}
				else
				{

					$where.=" m.sodowo =".$_POST['sodowo']."";

				}
				$and=true;

			}

			if (!empty($_POST['cnic'])){

				if ($and==true)
				{
					$where.=" and m.cnic =".$_POST['cnic']."";
				}
				else
				{
					$where.=" m.cnic =".$_POST['cnic']."";
				}
				$and=true;
			}
			if (!empty($_POST['project_name'])){
				if($and==true)
				{
					$where.=" AND p.project_id  '%".$_POST['project_name']."%'";
				}
				else
				{
					$where.="  p.project_id LIKE '%".$_POST['project_name']."%'";
				}
				$and=true;
			}
				if (!empty($_POST['plot_detail_address'])){

				if ($and==true)
				{
					$where.=" and p.plot_detail_address ='".$_POST['plot_detail_address']."'";
				}
				else
				{
					$where.="p.plot_detail_address='".$_POST['plot_detail_address']."'";
				}
				$and==true;
			}
				
			if (!empty($_POST['plotno'])){

				if ($and==true)
				{
					$where.=" and mp.plotno ='".$_POST['plotno']."'";
				}
				else
				{
					$where.="mp.plotno='".$_POST['plotno']."'";
				}
				$and==true;
			}
				$sql2='';
				$members="";
				$connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();
					$error="";
			$and = false;
			$where='';
			if (!empty($_POST['name'])){
				$where.=" m.name LIKE '%".$_POST['name']."%'";
				$and = true;
			}
			if (!empty($_POST['sodowo'])){				
				if ($and==true)
				{
					$where.=" and m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}
				else
				{

					$where.=" m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}
				$and=true;

			}

			if (!empty($_POST['cnic'])){

				if ($and==true)
				{
					$where.=" and m.cnic LIKE '%".$_POST['cnic']."%'";
				}
				else
				{
					$where.=" m.cnic LIKE '%".$_POST['cnic']."%'";
				}
				$and=true;
			}
			if (!empty($_POST['project_name'])){
				if($and==true)
				{
					$where.=" AND p.project_id LIKE '%".$_POST['project_name']."%'";
				}
				else
				{
					$where.="  p.project_id LIKE '%".$_POST['project_name']."%'";
				}
				$and=true;
			}

			if (!empty($_POST['plotno'])){

				if ($and==true)

				{

					$where.=" and mp.plotno ='".$_POST['plotno']."'";

				}

				else

				{

					$where.="mp.plotno='".$_POST['plotno']."'";

				}

				$and==true;

			}

//if($and ==true){echo 0;}else{echo 1;}exit;

			

			if (!empty($_POST['plot_detail_address'])){

				if ($and==true)

				{

					$where.=" and p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";

				}

			    else

				{

					$where.=" p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";

				}

				/*if($where!='')

					$where.=" AND ";

				else $where.=' WHERE ';

				$where.="p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";*/

			}

			

		

	$connection = Yii::app()->db; 

	 $sql_member = "SELECT mp.member_id,mp.plotno,mp.create_date,p.id,p.type,p.project_id,m.name,mp.plotno,m.image,m.sodowo,m.cnic,p.plot_detail_address,mp.plot_id,mp.status,p.plot_size,p.project_id,p.street_id,s.street,s.id,j.id,j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id


left join projects j on p.project_id=j.id

where $where p.type='plot' and mp.status='Approved' "; 
	     	$result_members = $connection->createCommand($sql_member)->query();

        $connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();

			if(isset($_POST['search'])){

            $res=array();
			

            foreach($members as $key){

  echo '<tr><td><img src="/upload_pic/'.$key['image'].'" width="100" height="130" /></td><td>'.$key['create_date'].'</td><td><a href="'.$home.'/index.php/user/memhistory?id='.$key['member_id'].'">'.$key['name'].'</a></td><td>'.$key['sodowo'].'</td><td>'.$key['cnic'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['plot_id'].'">'.$key['plot_detail_address'].'</a><td>'.$key['plot_size'].'</td><td>'.$key['street'].'</td><td>'.$key['project_name'].'</td><td><a target="_blank" href="payment?id='.$key['plot_id'].' & pid='.$key['project_id'].'">Add Payment</a></br><a target="_blank" href="plotcharges?id='.$key['plot_id'].'&& pid='.$key['project_id'].'">Plot Charges</a>
  </br><a target="_blank" href="download?id='.$key['plot_id'].'">Document</a>

</br>';if($key['status']=='New Request'){ echo'Cancel Request';}else {echo'<a target="_blank" href="transferplot?plot_id='.$key['plot_id'].'">Transfer asdsaasdPlot</a>';}

echo'  </td></tr>'; 

            }
			}

			$this->render('member_lis',array('members'=>$result_members,'error'=>$error,'projects'=>$result_projects));

	}

	public function actionMember_lisf()
	{	
			$name='';
			$sodowo='';
			$cnic='';
			$plotno='';
			$project_name='';
			$plot_detail_address='';
			$where='';
			$and = false;
			if (!empty($_POST['name1'])){
				$where.=" m.name ".$_POST['name1']."%'";
				$and = true;
			}
			if (!empty($_POST['sodowo'])){				
				if ($and==true)
				{
					$where.=" and m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}
				else
				{

					$where.=" m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}
				$and=true;

			}

			if (!empty($_POST['cnic'])){

				if ($and==true)
				{
					$where.=" and m.cnic LIKE '%".$_POST['cnic']."%'";
				}
				else
				{
					$where.=" m.cnic LIKE '%".$_POST['cnic']."%'";
				}
				$and=true;
			}
			if (!empty($_POST['project_name'])){
				if($and==true)
				{
					$where.=" AND p.project_id  '%".$_POST['project_name']."%'";
				}
				else
				{
					$where.="  p.project_id LIKE '%".$_POST['project_name']."%'";
				}
				$and=true;
			}
				if (!empty($_POST['plot_detail_address'])){

				if ($and==true)
				{
					$where.=" and p.plot_detail_address ='".$_POST['plot_detail_address']."'";
				}
				else
				{
					$where.="p.plot_detail_address='".$_POST['plot_detail_address']."'";
				}
				$and==true;
			}
				
			if (!empty($_POST['plotno'])){

				if ($and==true)
				{
					$where.=" and mp.plotno ='".$_POST['plotno']."'";
				}
				else
				{
					$where.="mp.plotno='".$_POST['plotno']."'";
				}
				$and==true;
			}
			
				$members="";
				$connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();
					$error="";
			

//if($and ==true){echo 0;}else{echo 1;}exit;

			

			if (!empty($_POST['plot_detail_address'])){

				if ($and==true)

				{

					$where.=" and p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";

				}

			    else

				{

					$where.=" p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";

				}

				/*if($where!='')

					$where.=" AND ";

				else $where.=' WHERE ';

				$where.="p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";*/

			}

			

		

	$connection = Yii::app()->db; 

	 $sql_member = "SELECT mp.member_id,mp.plotno,mp.create_date,p.id,p.type,p.project_id,m.name,mp.plotno,m.image,m.sodowo,m.cnic,p.plot_detail_address,mp.plot_id,mp.status,p.plot_size,p.project_id,p.street_id,s.street,s.id,j.id,j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id


left join projects j on p.project_id=j.id

where $where p.type='file' and mp.status='Approved' "; 
	     	$result_members = $connection->createCommand($sql_member)->query();

        $connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();

			if(isset($_POST['search'])){

            $res=array();
			

            foreach($members as $key){

  echo '<tr><td>'.$key['plotno'].'</td><td><img src="/upload_pic/'.$key['image'].'" width="100" height="130" /></td><td>'.$key['create_date'].'</td><td><a href="'.$home.'/index.php/user/memhistory?id='.$key['member_id'].'">'.$key['name'].'</a></td><td>'.$key['sodowo'].'</td><td>'.$key['cnic'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['plot_id'].'">'.$key['plot_detail_address'].'</a><td>'.$key['plot_size'].'</td><td>'.$key['street'].'</td><td>'.$key['project_name'].'</td><td><a target="_blank" href="payment?id='.$key['plot_id'].' & pid='.$key['project_id'].'">Add Payment</a></br><a target="_blank" href="plotcharges?id='.$key['plot_id'].'&& pid='.$key['project_id'].'">Plot Charges</a></br><a target="_blank" href="payment_details?id='.$key['plot_id'].'&& pid='.$key['project_id'].'">Payment Details</a>

  </br><a target="_blank" href="download?id='.$key['plot_id'].'">Document</a>

  </br><a target="_blank" href="transferplot?plot_id='.$key['plot_id'].'">Transfer Plot</a>

  </td></tr>'; 

            }
			}

			$this->render('member_lisf',array('members'=>$result_members,'error'=>$error,'projects'=>$result_projects));

	}


	

	public function actionMember_flist()

	{	

	if(Yii::app()->session['user_array']['per12']=='1')

			{

		

	$connection = Yii::app()->db; 

	$sql_member = "SELECT mp.member_id,mp.create_date, m.name,m.sodowo,m.cnic,p.plot_detail_address,mp.status, 					p.plot_size,s.street, j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id

left join projects j on p.project_id=j.id where p.type='file'  and mp.status='Approved'";

		$result_members = $connection->createCommand($sql_member)->query();

		$this->render('member_flist',array('members'=>$result_members));

	}

	}

	public function actionMember_flis()

	{	

	if(Yii::app()->session['user_array']['per12']=='1')

			{

		

			if ((empty($_POST['name'])) && (empty($_POST['sodowo'])) && (empty($_POST['cnic'])) && (empty($_POST['plotno'])) && (empty($_POST['project_name'])) && (empty($_POST['plot_detail_address']))){

				$error = "Please Fill Atleast one field";

				$members="";
				$connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();


				$this->render('member_flis',array('error'=>$error,'members'=>$members,'projects'=>$result_projects));

				exit;

				}

			$error="";

			$and = false;

			$where='';

			if ($_POST['name']!=""){

				$where.=" m.name LIKE '%".$_POST['name']."%'";

				$and = true;

			}

			

			

			if ($_POST['sodowo']!=""){				

				if ($and==true)

				{

					$where.=" and m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}

				else

				{

					$where.=" m.sodowo LIKE '%".$_POST['sodowo']."%'";

				}

				$and=true;

			}

			

			

			if ($_POST['cnic']!=""){

				if ($and==true)

				{

					$where.=" and m.cnic LIKE '%".$_POST['cnic']."%'";

				}

				else

				{

					$where.=" m.cnic LIKE '%".$_POST['cnic']."%'";

				}

				$and=true;

			}

			

			

			
			

			

			if ($_POST['project_name']!=""){

				if($and==true)

				{

					$where.=" and p.project_id LIKE '%".$_POST['project_name']."%'";

				}

				else

				{

					$where.=" p.project_id LIKE '%".$_POST['project_name']."%'";

				}

				$and=true;

				

			}

			
         if (!empty($_POST['plotno'])){

				if ($and==true)

				{

					$where.=" and mp.plotno ='".$_POST['plotno']."'";

				}

				else

				{

					$where.="mp.plotno='".$_POST['plotno']."'";

				}

				$and==true;

			}

			

			if ($_POST['plot_detail_address']!=""){

				if ($and==true)

				{

					$where.=" and p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";

				}

			    else

				{

					$where.=" p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";

				}

				/*if($where!='')

					$where.=" AND ";

				else $where.=' WHERE ';

				$where.="p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";*/

			}

			

		

	$connection = Yii::app()->db; 

	 $sql_member = "SELECT mp.member_id,mp.create_date,mp.plotno,p.id,p.type, m.name,m.image,m.sodowo,m.cnic,p.plot_detail_address,mp.plot_id,mp.status,p.project_id,p.plot_size,s.street, j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id

left join projects j on p.project_id=j.id 

where $where and p.type='file'  and mp.status='Approved' "; 

		$result_members = $connection->createCommand($sql_member)->query();
		$connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();

			$this->render('member_flis',array('members'=>$result_members,'error'=>$error,'projects'=>$result_projects));

	}

	}

public function actionPayment_details()

	{

		$connection = Yii::app()->db;

	$land  = "SELECT * FROM installpayment where plot_id='".$_REQUEST['id']."' ";

		$land_cost = $connection->createCommand($land)->queryAll();
		

		$sql_payment  = "SELECT * FROM plotpayment where plot_id='".$_REQUEST['id']."'";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

		

	   $sql_member= "SELECT mp.id,mp.plot_id,mp.plotno,mp.member_id,m.cnic,m.name FROM memberplot mp
	   left join members m on mp.member_id=m.id
	    where plot_id='".$_REQUEST['id']."'";

		$result_members = $connection->createCommand($sql_member)->queryAll();
		

		

		$sql = "SELECT pc.plot_id,pc.charges_id,c.name,c.total FROM plotcharges pc

left join charges c on pc.charges_id=c.id 

where plot_id='".$_REQUEST['id']."'";

		$res=$connection->createCommand($sql)->queryAll();

		

		//$sql_charges  = "SELECT * FROM plotcharges where plot_id='".$_REQUEST['id']."'";

		//$result_charges = $connection->createCommand($sql_charges)->queryAll();

		

		$sql_plotinfo  = "SELECT p.*,proj.project_name,sec.sector_name,st.street,s.size FROM plots p
		left join projects proj on p.project_id=proj.id
		left join sectors sec on p.sector=sec.id
		 left join streets st on p.street_id=st.id
		left join size_cat s on p.size2=s.id
		 where p.id='".$_REQUEST['id']."'";
		$result_plotinfo = $connection->createCommand($sql_plotinfo)->queryAll();

		

	

		$this->render('payment_details',array('payments'=>$result_payments,'landcost'=>$land_cost,'info'=>$result_plotinfo,'receivable'=>$res,'members'=>$result_members));

		

	}

	public function actionInstallment_details()

	{
		$connection = Yii::app()->db;
		$sql_payment  = "SELECT * FROM installpayment where plot_id='".$_REQUEST['id']."' ";
		$result_payments = $connection->createCommand($sql_payment)->queryAll();
			   $sql_member= "SELECT mp.id,mp.plot_id,mp.plotno,mp.member_id,m.cnic,m.name FROM memberplot mp
	   left join members m on mp.member_id=m.id
	    where plot_id='".$_REQUEST['id']."'";
		$result_members = $connection->createCommand($sql_member)->queryAll();
		$sql_charges  = "SELECT * FROM plotcharges where plot_id='".$_REQUEST['id']."'";
		$result_charges = $connection->createCommand($sql_charges)->queryAll();
	//	$sql_plotinfo  = "SELECT * FROM plots where id='".$_REQUEST['id']."'";
		$sql_plotinfo  = "SELECT p.*,proj.project_name,sec.sector_name,st.street,s.size FROM plots p
		left join projects proj on p.project_id=proj.id
		left join sectors sec on p.sector=sec.id
		 left join streets st on p.street_id=st.id
		left join size_cat s on p.size2=s.id
		 where p.id='".$_REQUEST['id']."'";
		$result_plotinfo = $connection->createCommand($sql_plotinfo)->queryAll();

		
		$sql_minfo  = "SELECT * FROM memberplot where plot_id='".$_REQUEST['id']."'";

		$result_minfo = $connection->createCommand($sql_minfo)->queryAll();

		

		$this->render('installment_details',array('payments'=>$result_payments,'charges'=>$result_charges,'info'=>$result_plotinfo,'minfo'=>$result_minfo,'members'=>$result_members));

		

	}
	public function actionInstallment_edit()

	{
		$connection = Yii::app()->db;
		$sql_payment  = "SELECT * FROM installpayment where plot_id='".$_REQUEST['id']."' ";
		$result_payments = $connection->createCommand($sql_payment)->queryAll();
			   $sql_member= "SELECT mp.id,mp.plot_id,mp.plotno,mp.member_id,m.cnic,m.name FROM memberplot mp
	   left join members m on mp.member_id=m.id
	    where plot_id='".$_REQUEST['id']."'";
		$result_members = $connection->createCommand($sql_member)->queryAll();
		$sql_charges  = "SELECT * FROM plotcharges where plot_id='".$_REQUEST['id']."'";
		$result_charges = $connection->createCommand($sql_charges)->queryAll();
	//	$sql_plotinfo  = "SELECT * FROM plots where id='".$_REQUEST['id']."'";
		$sql_plotinfo  = "SELECT p.*,proj.project_name,sec.sector_name,st.street,s.size FROM plots p
		left join projects proj on p.project_id=proj.id
		left join sectors sec on p.sector=sec.id
		 left join streets st on p.street_id=st.id
		left join size_cat s on p.size2=s.id
		 where p.id='".$_REQUEST['id']."'";
		$result_plotinfo = $connection->createCommand($sql_plotinfo)->queryAll();

		
		$sql_minfo  = "SELECT * FROM memberplot where plot_id='".$_REQUEST['id']."'";

		$result_minfo = $connection->createCommand($sql_minfo)->queryAll();

		

		$this->render('installment_edit',array('payments'=>$result_payments,'charges'=>$result_charges,'info'=>$result_plotinfo,'minfo'=>$result_minfo,'members'=>$result_members));

		

	}

	public function actionUpdate()

     	{

		if(Yii::app()->session['user_array']['per3']=='1' && isset(Yii::app()->session['user_array']['username']))

			{

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 
	  /*?>$sql= "SELECT
    projects.project_name
	,size_cat.size
	,ins.*
    FROM
    installment_plan ins
	Left JOIN projects  ON (ins.project_id = projects.id)
	  Left JOIN size_cat  ON (ins.category_id = size_cat.id)  

	  WHERE ins.id='".$_GET['id']."'";

	$result = $connection->createCommand($sql)->query();
	$sql_project = "SELECT * from projects";
	$result_project = $connection->createCommand($sql_project)->query();
   $sql_size = "SELECT * from size_cat";
	$result_size = $connection->createCommand($sql_size)->query();<?php */

//	$this->render('update',array('pla'=>$result,'projects'=>$result_project,'size'=>$result_size));
$this->render('update');
	
			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

    }
	public function actionUpdate_charges()

     	{

		if(Yii::app()->session['user_array']['per3']=='1' &&Yii::app()->session['user_array']['per12']=='1'&& isset(Yii::app()->session['user_array']['username']))

			{

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 
			
		 $sql_payment  = "SELECT * FROM plotpayment where id='".$_GET['id']."'";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

			$sql_charges  = "SELECT * from charges where project_id='".$_REQUEST['pid']."'";

			$result_charges = $connection->createCommand($sql_charges)->query();

			
		$this->render('update_charges',array('charges'=>$result_charges,'payments'=>$result_payments));


	
			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

    }
	public function actionUp_charges()

     	{

		if(Yii::app()->session['user_array']['per3']=='1' &&Yii::app()->session['user_array']['per12']=='1'&& isset(Yii::app()->session['user_array']['username']))

			{

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 
			
		 $sql_payment  = "SELECT * FROM plotpayment where id='".$_GET['id']."'";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

			$sql_charges  = "SELECT * from charges where project_id='".$_REQUEST['pid']."'";

			$result_charges = $connection->createCommand($sql_charges)->query();

			
		$this->render('up_charges',array('charges'=>$result_charges,'payments'=>$result_payments));


	
			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

    }
	
public function actionPaymentupdate()

	{       $error='';
			if ((isset($_POST['dueamount']) && empty($_POST['dueamount']))){
			$error.="Enter Due Amount. <br>";}
			if ((isset($_POST['lab']) && empty($_POST['lab']))){
			$error.="Enter Label. <br>";}
			if ((isset($_POST['paidamount']) && empty($_POST['paidamount']))){
			$error.="Enter Paid Amount. <br>";
			}
			if ((isset($_POST['payment_type']) && empty($_POST['payment_type']))){
			$error.="Please Select Payment Type <br>";
			}		  
			if ((isset($_POST['detail']) && empty($_POST['detail']))){
			$error.="Enter Voucher NO. <br>";
			 }
		  if ((isset($_POST['remarks']) && empty($_POST['remarks']))){
			$error.="Enter Remarks. <br>";
			}
			
			if ((isset($_POST['paid_date']) && empty($_POST['paid_date']))){
			$error.="Enter Paid Date. <br>";
			 }	
			   $connection = Yii::app()->db;  
				  if(empty($error))

			{
			   $sql="UPDATE installpayment set 
			 dueamount='".$_POST['dueamount']."',
			 lab='".$_POST['lab']."',  
			 paidsurcharge='".$_POST['paidsurcharge']."',
			 paidamount='".$_POST['paidamount']."',
			 payment_type='".$_POST['payment_type']."',
			 detail='".$_POST['detail']."',
			 surcharge='".$_POST['surcharge']."',
			 remarks='".$_POST['remarks']."',
			 paid_date='".$_POST['paid_date']."',
			 due_date='".$_POST['due_date']."'
			  where id=".$_POST['id']."";
               $command = $connection -> createCommand($sql);
               $command -> execute();
			   	echo 'Installment Updated Successfully';}
				else{
					echo $error;
					}
			  
	}
	public function actionInstallmentup()

	{       $error='';
			if ((isset($_POST['dueamount']) && empty($_POST['dueamount']))){
			$error.="Enter Due Amount. <br>";}
			if ((isset($_POST['lab']) && empty($_POST['lab']))){
			$error.="Enter Label. <br>";}
			
		  if ((isset($_POST['remarks']) && empty($_POST['remarks']))){
			$error.="Enter Remarks. <br>";
			}
			
			if ((isset($_POST['due_date']) && empty($_POST['due_date']))){
			$error.="Enter Due Date. <br>";
			 }	
			   $connection = Yii::app()->db;  
				  if(empty($error))

			{
			   $sql="UPDATE installpayment set 
			 dueamount='".$_POST['dueamount']."',
			 lab='".$_POST['lab']."',  
			surcharge='".$_POST['surcharge']."',
			 remarks='".$_POST['remarks']."',
			 due_date='".$_POST['due_date']."'
			  where id=".$_POST['id']."";
               $command = $connection -> createCommand($sql);
               $command -> execute();
			   	echo 'Installment Updated Successfully';}
				else{
					echo $error;
					}
			  
	}
public function actionChargupdate()

	{        $error='';
			if ((isset($_POST['amount']) && empty($_POST['amount']))){
			$error.="Enter Due Amount. <br>";}
			if ((isset($_POST['paidamount']) && empty($_POST['amount']))){
			$error.="Enter Paid Amount. <br>";
			}
			if ((isset($_POST['payment_type']) && empty($_POST['payment_type']))){
			$error.="Please Select Payment Type <br>";
			}		  
			if ((isset($_POST['detail']) && empty($_POST['detail']))){
			$error.="Enter Voucher NO. <br>";
			 }
		  if ((isset($_POST['remarks']) && empty($_POST['remarks']))){
			$error.="Enter Remarks. <br>";
			}
			
			if ((isset($_POST['date']) && empty($_POST['date']))){
			$error.="Enter Paid Date. <br>";
			 }	
			

			   $connection = Yii::app()->db;  
				
			if(empty($error)){
			   $sql="UPDATE plotpayment set 
			 amount='".$_POST['amount']."',
			  paidas='".$_POST['paidas']."',
			 paidsurcharge='".$_POST['paidsurcharge']."',
			 paidamount='".$_POST['paidamount']."',
			 payment_type='".$_POST['payment_type']."',
			 detail='".$_POST['detail']."',
			 surcharge='".$_POST['surcharge']."',
			 remarks='".$_POST['remarks']."',
			 date='".$_POST['date']."',
			 duedate='".$_POST['duedate']."',
			  mem_id='".$_POST['mem_id']."'
			  where id=".$_POST['id']."";
               $command = $connection -> createCommand($sql);
               $command -> execute();
			   	echo 'Payments Updated Successfully';
			}
			else{
				echo $error;
				}
			  
	}
	public function actionChargup()

	{        
	
	
	$error='';
			if ((isset($_POST['amount']) && empty($_POST['amount']))){
			$error.="Enter Due Amount. <br>";}
			
			if ((isset($_POST['payment_type']) && empty($_POST['payment_type']))){
			$error.="Please Select Payment Type <br>";
			}		
			if(empty($_POST['duedate'])){
				$error.="Please Enter Due Date";
				}  
		
		
				
			   $connection = Yii::app()->db;  
				
			if(empty($error)){
			   $sql="UPDATE plotpayment set 
			 amount='".$_POST['amount']."',
			 remarks='".$_POST['remarks']."',
			 duedate='".$_POST['duedate']."',
			  mem_id='".$_POST['mem_id']."'
			  where id=".$_POST['id']."";
               $command = $connection -> createCommand($sql);
               $command -> execute();
			   	echo 'Payments Updated Successfully';
			}
			else{
				echo $error;
				}
			  
	}
	public function actionMemberplot_list()

	{	

	if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per6']=='1')

			{

	$connection = Yii::app()->db; 

	$sql_member = "SELECT mp.member_id,mp.id,mp.plot_id,mp.create_date,mp.fstatus,mp.plotno,p.status,p.type, p.size2,siz.size,m.name,m.sodowo,m.cnic,p.plot_detail_address,p.plot_size,s.street, j.project_name FROM memberplot mp

left join members m on m.id=mp.member_id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id
left join size_cat siz on p.size2=siz.id

left join projects j on s.project_id=j.id where p.type='plot' and mp.status='new'and mp.fstatus='approved' ";

		$memberplot_list = $connection->createCommand($sql_member)->query();

		

		$connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();

		

		$this->render('memberplot_list',array('memberplot_list'=>$memberplot_list,'projects'=>$result_projects));

		}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

				

	}

	/////////////////////////////SEARCH MEMBERPLOT BY APP NO, BY MEM ID, BY STATUS, BY DATE//////////////////

	

	

	

	public function actionMemberplot_search_lis()

	{	

	if(Yii::app()->session['user_array']['per12']=='1')

			{
					$connection = Yii::app()->db; 

			$and = false;

			$where='';
	    // echo   $qry="Select * from memberplot where create_date BETWEEN '".$_POST['fromdate']."'  AND  '".$_POST['todate']."'  ";

			//exit;		

			$from=$_POST['fromdate'];

			$to=$_POST['todate'];

			

			if (($_POST['fromdate']!="") && ($_POST['todate']!="")) {

				if ($and==true)

				{

				$where.="and mp.create_date BETWEEN '".$from."' AND '".$to."' ";

				}else{$where.="mp.create_date BETWEEN '".$from."' AND '".$to."' ";}

			$and=true;

			}

			

				if ($_POST['username']!=""){

				if ($and==true)

				{

				$where.="and m.name LIKE '%".$_POST['username']."%'";

				}else{

				$where.=" m.name  LIKE '%".$_POST['username']."%'";

				}

			$and=true;	

			}

			

			

			if ($_POST['plot_detail_address']!=""){

				if ($and==true)

				{

					$where.=" and p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";

				}

				else

				{

					$where.=" p.plot_detail_address LIKE '%".$_POST['plot_detail_address']."%'";

				}

				$and=true;

			}

			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				

				$pro=$_POST['project_id'];

				if ($and==true)

				{

					$where.=" and p.project_id LIKE '%".$_POST['project_id']."%'";

				}
				else
				{

					$where.=" p.project_id LIKE '%".$_POST['project_id']."%'";

				}
}
				$and=true;

  $sql_member = "SELECT mp.id,mp.fstatus,mp.member_id,mp.status,mp.fstatus,mp.plot_id,mp.plotno,mp.create_date,p.id,m.username, m.name,siz.size,m.image,m.sodowo,m.cnic,p.plot_detail_address,p.plot_size,s.street, j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id

left join projects j on s.project_id=j.id 
left join size_cat siz on p.size2=siz.id

where ".$where." AND p.type='plot' and mp.status='new'and mp.fstatus='approved' ";

		$result_members = $connection->createCommand($sql_member)->query();

		

		$sql_projects = "SELECT * from projects ";





		$result_projects = $connection->createCommand($sql_projects)->query();



			$this->render('memberplot_list',array('memberplot_list'=>$result_members,'projects'=>$result_projects));

	}

	

	

	}

	
	public function actionRequested_detail()

	 {

	if(Yii::app()->session['user_array']['per12']=='1')

			{

			$connection = Yii::app()->db; 	

		 $sql_details  = "SELECT mp.member_id, u.firstname,u.cnic,u.email,c.size,mp.noi,mp.id,mp.create_date,mp.member_id,mp.user_name,mp.plotno,m.id,m.image, p.size2,m.name,m.sodowo,m.cnic,p.price,p.com_res,p.status,p.plot_detail_address,p.id,p.plot_size,s.street, j.project_name FROM  memberplot mp
left join members m on mp.member_id=m.id
left join plots p on mp.plot_id=p.id
left join streets s on p.street_id=s.id
left join size_cat c on p.size2=c.id
left join user u on mp.user_name=u.id

left join projects j on s.project_id=j.id where mp.status!='Approved' And mp.plot_id=".$_REQUEST['id'];

			$result_details = $connection->createCommand($sql_details)->query();

			

			$sql_payment  = "SELECT * from plotpayment where plot_id='".$_REQUEST['id']."'";

			$result_payments = $connection->createCommand($sql_payment)->queryRow();

			$this->render('requested_detail',array('plotdetails'=>$result_details, 'plotpayments'=>$result_payments)); 

			}else{$this->redirect(array("dashboard"));}

	}

	

	////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////REQUEST DETAIL///////////////

	

	

	

	public function actionReq_detail()

	 {

	if(Yii::app()->session['user_array']['per12']=='1')

			{

			$connection = Yii::app()->db; 	

		$sql_details  = "SELECT mp.member_id, u.firstname,u.cnic,u.email,c.size,mp.noi,mp.id,mp.fcomment,mp.create_date,mp.fstatus,mp.member_id,mp.user_name,mp.plotno,m.id,m.image, p.size2,m.name,m.sodowo,m.cnic,p.price,p.com_res,p.status,p.plot_detail_address,p.id,p.plot_size,s.street, j.project_name FROM  memberplot mp
left join members m on mp.member_id=m.id
left join plots p on mp.plot_id=p.id
left join streets s on p.street_id=s.id
left join size_cat c on p.size2=c.id
left join user u on mp.user_name=u.id

left join projects j on s.project_id=j.id where mp.plot_id=".$_REQUEST['plot_id'];

			$result_details = $connection->createCommand($sql_details)->query();

			

			$sql_payment  = "SELECT * from plotpayment where plot_id='".$_REQUEST['plot_id']."'";

			$result_payments = $connection->createCommand($sql_payment)->queryRow();

			$this->render('req_detail',array('plotdetails'=>$result_details, 'plotpayments'=>$result_payments)); 

			}else{$this->redirect(array("dashboard"));}

	}

	

	

	

	//////////////////////////////////////////

	public function actionCancelreq()

	{
	
		$connection = Yii::app()->db;
	 
		 $plotid=$_POST['pid'];
   	 
		 $sql="Update plots SET status='' where id='".$plotid."'"; 	
        $command = $connection -> createCommand($sql);
        $command -> execute();
		$sql1="DELETE FROM  memberplot where plot_id='".$plotid."'";	
		//$sql="Update plots SET status='Alloted' where plot_id='".$plotid."'";	
        $command = $connection -> createCommand($sql1);
        $command -> execute();
		$sql2="DELETE FROM  installpayment where plot_id='".$plotid."'";		
        $command = $connection -> createCommand($sql2);
        $command -> execute();
		$this->redirect(array("plots/plots_lis"));
	
		}

	////////////////////SUBMIT STATUS///////

	

	public function actionSubmitstatus()
	{
	if($_POST['statusapp']=='Approved')
		{
		$connection = Yii::app()->db;
	 	$memberid=$_POST['member_id'];
		$plotid=$_POST['plot_id'];
   	    $status=$_POST['status'];
		$sql="Update plots SET status='Allotted' where id='".$plotid."'";	
        $command = $connection -> createCommand($sql);
        $command -> execute();
		$sql="Update memberplot SET status='Approved',comment='".$_POST['cmnt']."' where plot_id='".$plotid."'";	
        $command = $connection -> createCommand($sql);
        $command -> execute();
		
		$this->redirect(array("memberplot/memberplot_list"));
		} 
		
		if($_POST['statusapp']=='Rejected')
		{
			
		$connection = Yii::app()->db;
		$plotid=$_POST['plot_id'];
		//echo $sqlup="Update plots SET status='' where id='".$plotid."'";	
          $sqlup="UPDATE plots set status='' WHERE id='".$plotid."'"; 
		$command = $connection -> createCommand($sqlup);
        $command -> execute();
		$sqldel="DELETE FROM memberplot WHERE plot_id='".$plotid."'  ";
        
		$command = $connection -> createCommand($sqldel);
        $command -> execute();
$sql2="DELETE FROM  installpayment where plot_id='".$plotid."'";		
        $command = $connection -> createCommand($sql2);
        $command -> execute();



			$this->redirect(array("memberplot/memberplot_list"));

		}

		}

	//////////////////////////////////////////

	

	

	public function actionAjaxRequest($pro,$sec)
	{	

	$connection = Yii::app()->db;  

		$sql_street  = "SELECT * from streets where project_id='".$pro."' and sector_id='".$sec."'";

		$result_streets = $connection->createCommand($sql_street)->query();

			

		$street=array();

		foreach($result_streets as $str){

			$street[]=$str;

			} 

		

	echo json_encode($street); exit();

	}

	

	

	

	public function actionAjaxRequest1()

	{	

		$connection = Yii::app()->db;  
if($_POST['pptype']=='C'){$type='Commercial';}else{$type='Residential';}
		$sql_plot  = "SELECT * from plots where street_id='".$_POST['street']."' and project_id='".$_POST['pro']."' and size2='".$_POST['size']."' and com_res='".$type."' and sector='".$_POST['sector']."' and type='Plot' and status=''";
		$result_plots = $connection->createCommand($sql_plot)->query();

			

		$plot=array();

		foreach($result_plots as $plo){

			$plot[]=$plo;

			} 

		

	echo json_encode($plot); exit();

	}

	
	public function actionAjaxRequest31($val1)

	{	
		$connection = Yii::app()->db;  
		$sql_city  = "SELECT * from charges where id='".$val1."' ";
		$result_city = $connection->createCommand($sql_city)->query();
		$city=array();

		foreach($result_city as $cit){
			$city[]=$cit;
			} 
	echo json_encode($city); exit();
	}

	public function actionAjaxRequest5($val1)

	{	

		$connection = Yii::app()->db;  

		$sql_city  = "SELECT * from members where cnic=".$val1." AND status=1";

		$result_city = $connection->createCommand($sql_city)->query();

			

		$city=array();

		foreach($result_city as $cit){

			$city[]=$cit;

			} 

		

	echo json_encode($city); exit();

	}

	

	public function actionAjaxRequest6($val1)

	{	

		$connection = Yii::app()->db;  

		$sql_city  = "SELECT * from memberplot where plotno='".$val1."'";

		$result_city = $connection->createCommand($sql_city)->query();

			

		$city=array();

		foreach($result_city as $cit){

			$city[]=$cit;

			} 

		

	echo json_encode($city); exit();

	}

	

	

	

	  

	

	public function loadModel($id)

	{

		$model=User::model()->findByPk($id);

		if($model===null)

			throw new CHttpException(404,'The requested page does not exist.');

		return $model;

	}



	/**

	 * Performs the AJAX validation.

	 * @param User $model the model to be validated

	 */

	protected function performAjaxValidation($model)

	{

		if(isset($_POST['ajax']) && $_POST['ajax']==='user-form')

		{

			echo CActiveForm::validate($model);

			Yii::app()->end();

		}

	}

}

