<?php







class AllotmentsController extends Controller



{



	

function actionGenpdf()

	{ if (!empty($_POST['submit'])){



    //require_once();

    include Yii::app()->baseUrl."/dompdf/dompdf_config.inc.php";

	$stream=TRUE;

    $dompdf = new DOMPDF();

	$html=$_POST['html'];

	//echo $html;exit;

	$filename='PDF File';

    $dompdf->set_paper('letter','landscape');

	$dompdf->load_html($html);

    $dompdf->render();

	$dompdf->set_base_path(realpath(APPLICATION_PATH . 'styles.css'));

    if ($stream) {

        $dompdf->stream($filename.".pdf");

    } else {

        return $dompdf->output();

    }

}}

	function actionNewballott()

	{

	if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')



			{

		$connection = Yii::app()->db;  

			

			$sql="INSERT INTO ballotting SET project='".$_POST['project']."', size='".$_POST['plot_size']."',

status='".$_POST['status']."', desc1='".$_POST['desc']."', createdate='".date('y-m-d')."'";	  



        $command = $connection -> createCommand($sql);



        $command -> execute();

		echo "New Ballot Saved ";

			}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

function actionResdrow()

	{

			if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{

	

	$connection = Yii::app()->db;  

	$sql="INSERT INTO member_plot SET plot_id='".$_POST['plot_id']."', member_name='".$_POST['appno']."'";	  

	$command = $connection -> createCommand($sql);

	$command -> execute();

	$sql="UPDATE app SET status='done' WHERE id='".$_POST['appno']."'";	  

	$command = $connection -> createCommand($sql);

	$command -> execute();

	$sql="UPDATE plots SET bstatus='done' WHERE id='".$_POST['plot_id']."'";	  

	$command = $connection -> createCommand($sql);

	$command -> execute();

	$this->redirect(Yii::app()->baseUrl."/index.php/allotments/reserve");

	exit;

	}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

	

	

	 function actionGenerate()



	 {

			if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{

	

	 $this->layout='//layouts/back';



	 $this->render('generate_list');



		 

	}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}



	 function actionRefreshdraw()



	 {

			if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{

   $connection = Yii::app()->db;  

    $sql="Update ballotting SET  status='Open' where id='".$_POST['bid']."'";	  

	$command = $connection -> createCommand($sql);

	$command -> execute();

    $sql1="Delete member_plot.* From member_plot

	Left JOIN plots ON plots.id=member_plot.plot_id 

    where plots.project_id='".$_POST['project']."' and plots.size2='".$_POST['plot_size']."' ";	  

	$command = $connection -> createCommand($sql1);

	$command -> execute();

	 $this->render('ballotting');

	}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}



	 function actionProject_wise_list()



	 {

			if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{

	 $this->layout='//layouts/back';



	 $this->render('project_wise_list');

		 

	}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}



	 function actionAllot()



	 {

		if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{



	 $this->layout='//layouts/back';

	 $this->render('index');

	 }

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	 

	}

	function actionAddballott()



	 {

		if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{

	 $this->layout='//layouts/back';



	 $this->render('addballotting');

			}

		 

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

	

	 function actionPlots()



	 {

		 	if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{



	$this->layout='//layouts/back';

	$connection = Yii::app()->db; 	

	$list_sql = "select plots.* FROM plots

	Left JOIN projects p ON p.id=plots.project_id where bid='".$_REQUEST['bid']."'";

	$result_details = $connection->createCommand($list_sql)->query();

	$list_sql5 = "select plots.* FROM plots

	Left JOIN projects p ON p.id=plots.project_id where project_id='".$_REQUEST['pid']."' AND size2='".$_REQUEST['size']."'";

	$result_details5 = $connection->createCommand($list_sql5)->query();

	$total=0;

	$totalr=0;

	foreach($result_details5 as $row){$total++;if($row['bstatus']=='reserved'){$totalr++;}}

	$list_sql1 = "select * FROM ballotting

	Left JOIN projects p ON p.id=ballotting.project

	 where ballotting.id='".$_REQUEST['bid']."'";

	$result_details1 = $connection->createCommand($list_sql1)->query();

	

	//print_r($result_details);exit;

	 $this->render('plots', array('plots'=>$result_details,'plot'=>$result_details1,'total'=>$total,'totalr'=>$totalr));

			}

			

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}



	function actionRand()

	{

		if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{



	$connection = Yii::app()->db; 	

	$list_sql1 = "select * FROM ballotting

	Left JOIN projects p ON p.id=ballotting.project where ballotting.id='".$_REQUEST['bid']."'";

	$result_details1 = $connection->createCommand($list_sql1)->query();

	

	$list_sql = "select * FROM member_plot

	Left JOIN plots p ON p.id=member_plot.plot_id

	Left JOIN app a ON a.id=member_plot.member_name where a.project='".$_REQUEST['pid']."' AND a.plot_size='".$_REQUEST['size']."' ORDER BY a.app_no";

	$result_details = $connection->createCommand($list_sql)->query();

	$this->layout='//layouts/back';

	$this->render('Random_allotment', array('plot'=>$result_details1,'list'=>$result_details));

	}

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	

	}

	

	function actionEditplotform()

	{

				if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{



		$connection = Yii::app()->db;

		$sql="Update plots SET bstatus='".$_POST['status']."' where id='".$_POST['pid']."'";	  

        $command = $connection -> createCommand($sql);

        $command -> execute(); 

		$this->redirect(array("allotments/plots?pid=".$_POST['pid']."&size=".$_POST['size']."&bid=".$_POST['bid'].""));

		}

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

	

	function actionEditballotform()

	{	

		if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

    	{

		$connection = Yii::app()->db;

		$sql="Update ballotting SET desc1='".$_POST['desc1']."', status='".$_POST['status']."' where id='".$_POST['bid']."'";	  

        $command = $connection -> createCommand($sql);

        $command -> execute(); 

		$this->redirect(array("allotments/ballotting"));

		}

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

	

	

	function actionEditmemberform()

	{

		if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

    	{

		$connection = Yii::app()->db;

		$error =array();

			if(isset($_POST['member_name']) && empty($_POST['member_name']))



			{



				$error = 'Please Enter Member Name<br>';



			}

			if(isset($_POST['cnic']) && empty($_POST['cnic']))



			{



				$error .= 'Please Enter CNIC<br>';



			}

			

			

			if(isset($_POST['email']) && empty($_POST['email']))



			{



				$error .= 'Please Enter Email<br>';



			}

			if(isset($_POST['mobile']) && empty($_POST['mobile']))



			{



				$error .= 'Please Enter Mobile #<br>';



			}

			if(isset($_POST['status']) && empty($_POST['status']))



			{



				$error .= 'Please Select Status<br>';



			}

			if(empty($error)){

		$sql="Update app SET app_no='".$_POST['app_no']."',status='".$_POST['status']."',member_name='".$_POST['member_name']."',cnic='".$_POST['cnic']."',email='".$_POST['email']."',mobile='".$_POST['mobile']."' where id=".$_REQUEST['mid']."";	  

        $command = $connection -> createCommand($sql);

        $command -> execute();

			echo "Record Updated Successfully";

			}

			if(!empty($error))

			{

				echo $error;

			}

		///$this->redirect(array("allotments/ballotting"));

		}

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

	

	function actionBallotting()



	 {



		if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

			{

	 $this->layout='//layouts/back';

	 $this->render('ballotting');

	 }

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	function actionEdit_plot()



	 {

		 if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{

    $this->layout='//layouts/back';

	$connection = Yii::app()->db; 	

	$list_sql = "select * FROM plots

	Left JOIN projects p ON p.id=plots.project_id where plots.id='".$_REQUEST['pid']."'";

	$result_details = $connection->createCommand($list_sql)->query();



	 $this->render('edit_plot',array('plot'=>$result_details));

		 }

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

	

	function actionEdit_app()

	{

    if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{

 	$this->layout='//layouts/back';

	$connection = Yii::app()->db; 	

	$list_sql = "select * FROM app

	Left JOIN projects p ON p.id=app.project where app.id='".$_REQUEST['mid']."'";

	$result_details = $connection->createCommand($list_sql)->query();

	$this->render('edit_app',array('plot'=>$result_details));

    }

	else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

	function actionDelete_ballott()

	{

    if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{

 	$connection = Yii::app()->db; 	

	$sql = "DELETE FROM ballotting where id='".$_REQUEST['bid']."'";

	$command = $connection -> createCommand($sql);

    $command -> execute(); 

	

	   $sql1="Delete member_plot.* From member_plot

	Left JOIN plots ON plots.id=member_plot.plot_id 

    where plots.project_id='".$_GET['pid']."' and plots.size2='".$_GET['size']."' ";	  

	$command = $connection -> createCommand($sql1);

	$command -> execute();



	$this->redirect(array("allotments/ballotting?pid=".$_REQUEST['pid']."&size=".$_REQUEST['size']."&bid=".$_REQUEST['bid'].""));	

	    }

	else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	function actionDeleteapp()

	{

	    if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{

 	$connection = Yii::app()->db; 	

	$sql = "DELETE FROM app where id='".$_REQUEST['mid']."'";

	$command = $connection -> createCommand($sql);

    $command -> execute(); 

	$this->redirect(array("allotments/add_members?mid=".$_REQUEST['mid']."&pid=".$_REQUEST['pid']."&size=".$_REQUEST['size']."&bid=".$_REQUEST['bid'].""));

	   }

	else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	

	}

	function actionDeleteplot()

	 {

    if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 

    $this->layout='//layouts/back';

	$connection = Yii::app()->db;

	$sql = "Update plots SET bid='',bstatus='' where id=".$_REQUEST['pid']."";

	$command = $connection -> createCommand($sql);

    $command -> execute();  

	$this->redirect(array("allotments/plots?bid=".$_REQUEST['bid']."&size=".$_REQUEST['size']."&pid=".$_REQUEST['pid'].""));		

	}

	else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	

	}

	

	function actionEdit_ballott()

	 {

    if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 

 	$this->layout='//layouts/back';

	$connection = Yii::app()->db; 	

	$list_sql = "select * FROM ballotting

	Left JOIN projects p ON p.id=ballotting.project

	Left JOIN size_cat s ON s.id=ballotting.size

	 where ballotting.id='".$_REQUEST['bid']."'";

	$result_details = $connection->createCommand($list_sql)->query();

	 $this->render('edit_ballott',array('ballott'=>$result_details));

	}

	else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	function actionAdd()

	 {

	    if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 

	$this->layout='//layouts/back';

    $connection = Yii::app()->db;



	

//echo $_REQUEST['pid'].$_REQUEST['size'].$_REQUEST['bid']; exit;	

			$error =array();

			if(isset($_POST['member_name']) && empty($_POST['member_name']))



			{



				$error = 'Please Enter Member Name<br>';



			}

			if(isset($_POST['cnic']) && empty($_POST['cnic']))



			{



				$error .= 'Please Enter CNIC<br>';



			}

			if(isset($_POST['app']) && empty($_POST['app']))



			{



				$error .= 'Please Enter Application #<br>';



			}

			if(!empty($_POST['app'])){

				

			 $check_user_query = 'select * from app where app_no="'.$_POST['app'].'"';

		    $check_user_result = $connection->createCommand($check_user_query)->queryRow();

	  		if($check_user_result['app_no']==$_POST['app'])

				{

					$error ="Application # Already Exists<br>";

				}

			}	

	

			

			if(isset($_POST['email']) && empty($_POST['email']))



			{



				$error .= 'Please Enter Email<br>';



			}

			if(isset($_POST['mobile']) && empty($_POST['mobile']))



			{



				$error .= 'Please Enter Mobile #<br>';



			}

			if(isset($_POST['status']) && empty($_POST['status']))



			{



				$error .= 'Please Select Status<br>';



			}

							if(empty($error)){

							$member_name = $_POST['member_name'];

							$plot_size = $_POST['size'];

							$cnic = $_POST['cnic'];

							$app = $_POST['app'];

							$sql_insert_member = "insert into app (project,member_name,CNIC,app_no,plot_size,mobile,email,status ) values('".$_POST[		                            'project']."','".$member_name."','".$cnic."','".$app."','".$plot_size."','". $_POST['mobile']."','". $_POST['email'].                            "','". $_POST['status']."')";

							$command = $connection -> createCommand($sql_insert_member);

							$command -> execute();

							echo "Applicant Added Successfully";

							}

							if(!empty($error))

							{

								echo $error;

							}

								}

	else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}



function actionAdd_members()



	 {

		 	    if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 



	 $this->layout='//layouts/back';



	$connection = Yii::app()->db;



		$list_sql1 = "select * FROM ballotting

	Left JOIN projects p ON p.id=ballotting.project where ballotting.id='".$_REQUEST['bid']."'";

	$result_details1 = $connection->createCommand($list_sql1)->query();

	

	$list_sql2 = "select app.*,project_name FROM app

	Left JOIN projects p ON p.id=app.project where project='".$_REQUEST['pid']."' AND plot_size='".$_REQUEST['size']."'";

	$result_details2 = $connection->createCommand($list_sql2)->query();

	

	$list_sql5 = "select * FROM app

	Left JOIN projects p ON p.id=app.project where project='".$_REQUEST['pid']."' AND plot_size='".$_REQUEST['size']."'";

	$result_details5 = $connection->createCommand($list_sql5)->query();

	$total=0;

	$totalr=0;

	foreach($result_details5 as $row){$total++;if($row['status']=='reserve'){$totalr++;}}

	 $this->render('add_members', array('detail'=>$result_details1,'app'=>$result_details2,'total'=>$total,'totalr'=>$totalr));

	}

	else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	 }

	 

	 function actionReserve()



	 {

		 	 	    if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 



	 $this->layout='//layouts/back';



	$connection = Yii::app()->db;



	$list_sql1 = "select * FROM ballotting

	Left JOIN projects p ON p.id=ballotting.project where ballotting.id='".$_REQUEST['bid']."'";

	$result_details1 = $connection->createCommand($list_sql1)->query();

		

	$list_sql2 = "select app.* FROM app where project='".$_REQUEST['pid']."' AND plot_size='".$_REQUEST['size']."' AND status='reserve'";

	$result_details2 = $connection->createCommand($list_sql2)->query();



	$list_sql5 = "select plots.* FROM plots

	Left JOIN projects p ON p.id=plots.project_id where bid='".$_REQUEST['bid']."' and bstatus='reserved' AND status!='Alloted'";

	$result_details5 = $connection->createCommand($list_sql5)->queryAll();

	

	

	//foreach($result_details5 as $row){$total++;if($row['status']=='reserve'){$totalr++;}}

	 $this->render('reserved', array('plot'=>$result_details1,'app'=>$result_details2,'plots'=>$result_details5));

		}

	else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	 }

	 

	function actionProject_wise()

	{

	if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 

	

	$this->layout='//layouts/back';

	$this->render('project_wise');

	}

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}

	

	function actionReslist()



	 {

		if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 

		 $connection = Yii::app()->db;

	$list_sql = "select p.*,projects.project_name,streets.street,member_plot.plot_id,member_plot.member_name,a.member_name,a.CNIC,a.app_no FROM member_plot

	Left JOIN plots p ON p.id=member_plot.plot_id

	Left JOIN projects ON projects.id=p.project_id

	Left JOIN streets ON streets.id=p.street_id

	Left JOIN app a ON a.id=member_plot.member_name where bid='".$_REQUEST['bid']."'  ORDER BY a.app_no";

	$result_details = $connection->createCommand($list_sql)->queryAll();

	 $this->layout='//layouts/back';



	 $this->render('reslist',array('list'=>$result_details));

     }

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

	}

	function actionAddtoballot()



	 {

			if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 

	

	$connection = Yii::app()->db;

	$s=0;

	

	if(isset($_POST['vara'])){

	$check=$_POST['vara'];

	foreach($check as $checked)

	{

	$sql="Update plots SET bstatus='Open', bid='".$_POST['bid']."' where id='".$checked."' ";	  

    $command = $connection -> createCommand($sql);

    $command -> execute(); 

	

	

	}}

	$this->redirect(array("allotments/plots?pid=".$_POST['pid']."&size=".$_POST['size']."&bid=".$_POST['bid'].""));

	}

		else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}



	public function actionUpdate($id)



	{



		$model=$this->loadModel($id);







		// Uncomment the following line if AJAX validation is needed



	







		if(isset($_POST['User']))



		{



			$model->attributes=$_POST['User'];



			if($model->save())



				$this->redirect(array('view','id'=>$model->user_id));



		}







		$this->render('update',array(



			'model'=>$model,



		));



	}



	







	/**



	 * Deletes a particular model.



	 * If deletion is successful, the browser will be redirected to the 'admin' page.



	 * @param integer $id the ID of the model to be deleted



	 */



	public function actionDelete($id)



	{



		$this->loadModel($id)->delete();







		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser



		if(!isset($_GET['ajax']))



			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));



	}







	public function actionIndex()



	{



		



		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))



		{



			 $this->redirect(array('datasource'));



		}else



		{



			$error = '';



			$layout='//layouts/column1';



			$this->render('index');



		}



	}



	





	



	public function actionCategory()



	{



		if(Yii::app()->session['user_array']['per3']=='1')



			{



		



					



		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))



		{	



				$this->render('category');



			



			}



			else{



				$this->redirect(array('user/user'));



				



			}



			}



	}



	



	



	



	 



	  



	



	public function loadModel($id)



	{



		$model=User::model()->findByPk($id);



		if($model===null)



			throw new CHttpException(404,'The requested page does not exist.');



		return $model;



	}







	/**



	 * Performs the AJAX validation.



	 * @param User $model the model to be validated



	 */



	protected function performAjaxValidation($model)



	{



		if(isset($_POST['ajax']) && $_POST['ajax']==='user-form')



		{



			echo CActiveForm::validate($model);



			Yii::app()->end();



		}



	}

	 

	 public function actionSearchreq()

	 	{

					if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 



		$where='';

		$and=false;

		 if (isset($_POST['sector']) && $_POST['sector']!=""){

				$where.="plots.sector LIKE '%".$_POST['sector']."%'";

				$and = true;

				$sector=$_POST['sector'];

			}

			

			

			if (isset($_POST['plotno']) && $_POST['plotno']!=""){

				$plotno=$_POST['plotno'];

				if ($and==true)

				{

					  $where.=" and plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				else

				{

					$where.=" plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				$and=true;

			}

			if (isset($_POST['size']) && $_POST['size']!=""){

				

				if ($and==true)

				{

					  $where.=" and plots.size2='".$_POST['size']."'";

				}

				else

				{

					$where.=" plots.size2 LIKE '%".$_POST['size']."%'";

				}

				$and=true;

			}

			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				

				$pro=$_POST['project_id'];

				if ($and==true)

				{

					$where.=" and plots.project_id='".$_POST['project_id']."'";

				}

				else

				{

					$where.=" plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				$and=true;

			}

			if (isset($_POST['street_id']) && $_POST['street_id']!=""){

				$st=$_POST['street_id'];

				if ($and==true)

				{

					$where.=" and plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				else

				{

					$where.=" plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				$and=true;

			}

			$connection = Yii::app()->db; 

			$sql_member = "SELECT

			plots.id

			, plots.street_id

			, plots.type

			, plots.plot_size

			, plots.com_res

			, plots.size2

			, plots.create_date

			, plots.sector

			, plots.category_id

			, plots.status

			, plots.plot_detail_address

			, projects.project_name

			, streets.street
			,size_cat.size

	

FROM

    plots
    left join size_cat ON (plots.size2=size_cat.id)

    Left JOIN streets  ON (plots.street_id = streets.id)

	Left JOIN projects  ON (plots.project_id = projects.id)



where $where and bid='' AND bstatus='open'"; 

       $result_members = $connection->createCommand($sql_member)->query();

	   

	    $sql_project = "SELECT * from projects";

		$result_project = $connection->createCommand($sql_project)->query();

		

		$sql_categories  = "SELECT * from categories";

		$categories = $connection->createCommand($sql_categories)->query();

			

	   

	    $sql_sector ="SELECT DISTINCT sector FROM plots";

		$result_sector = $connection->createCommand($sql_sector)->query();

		

	

	$count=0;

	if ($result_members!=''){

		$home=Yii::app()->request->baseUrl; 

    $res=array();

            foreach($result_members as $key){

            $count++;

			echo '<tr><td>'.$key['project_name'].'</td><td>'.$key['street'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['id'].'">'.$key['plot_detail_address'].'</a></td><td>'.$key['size'].'</td><td>'.$key['plot_size'].'</td><td>'.$key['com_res'].'/'.$key['type'].'</td><td>'.$key['sector'].'</td>

			<td><input type="checkbox" name="vara[]" value="'.$key['id'].'"></input></tr>';

			

			} 

			}else{echo '';}

	echo $count.' result found' ;exit;

	    if(isset($_POST['username']) && empty($_POST['username']))

			{

				$error = 'Please enter username<br>';

			}

			if(isset($_POST['password']) && empty($_POST['password']))

			{

				$error .= 'Please enter Password<br>';

			}

			if(empty($error))

			{

				  $username = $_POST['username'];

				 $password = md5($_POST['password']);

				  $connection = Yii::app()->db;  

				   $sql = "SELECT * FROM user where username ='".$username."' AND  password='".$password."' AND status=1";

				  $result_data = $connection->createCommand($sql)->queryRow();

				  if($result_data)

				  {

						Yii::app()->session['user_array'] = $result_data;

						echo 1;exit();

				  }else

				  {

					 echo "Invalid Username and Password"; 

				  }

			}else

			{

				echo $error;

			}

	exit;	 



	}

			else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }



	}



	public function actionAddplots()

	{	

		if(isset(Yii::app()->session['user_array']['username'] )&& Yii::app()->session['user_array']['per7']=='1')

	{ 

				   

	   		$plotno='';

			$st='';

			$pro='';

			$sector='';

			$cat='';

			$where='';

			$and = false;

			$where='';

			

			if (isset($_POST['sector']) && $_POST['sector']!=""){

				$where.="plots.sector LIKE '%".$_POST['sector']."%'";

				$and = true;

				$sector=$_POST['sector'];

			}

			

			if ($and==true)

				{

					$where.="  and type='plot' ";

				}

				else

				{

					$where.="type='plot' ";

				}

				$and=true;

			

			if (isset($_POST['cat']) && $_POST['cat']!=""){

				$cat=$_POST['cat'];

			

				

				if ($and==true)

				{

					  $where.=" and plots.category_id LIKE '%".$_POST['cat']."%'";

				}

				else

				{

					$where.=" plots.category_id LIKE '%".$_POST['cat']."%'";

				}

				$and=true;

			}

			

			if (isset($_POST['plotno']) && $_POST['plotno']!=""){

				$plotno=$_POST['plotno'];

				if ($and==true)

				{

					  $where.=" and plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				else

				{

					$where.=" plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				$and=true;

			}

			

			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				

				$pro=$_POST['project_id'];

				if ($and==true)

				{

					$where.=" and plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				else

				{

					$where.=" plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				$and=true;

			}

			

			

			if (isset($_POST['street_id']) && $_POST['street_id']!=""){

				$st=$_POST['street_id'];

				if ($and==true)

				{

					$where.=" and plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				else

				{

					$where.=" plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				$and=true;

			}

			

			

			

			

		

	$connection = Yii::app()->db; 

    $sql_member = "SELECT

    plots.id

    , plots.street_id

    , plots.plot_size

    , plots.com_res

	 , plots.size2

    , plots.create_date

	, plots.sector

	, plots.category_id

	, plots.status

	, plots.plot_detail_address

	, memberplot.plotno

    , projects.project_name
	,size_cat.size
	, streets.street

	

FROM

    plots
    left join size_cat  ON (plots.size2=size_cat.id)
    Left JOIN streets  ON (plots.street_id = streets.id)

	Left JOIN projects  ON (plots.project_id = projects.id)

	Left JOIN memberplot  ON (plots.id = memberplot.plot_id)

where $where"; 

        $sql_project = "SELECT * from projects";

		$result_project = $connection->createCommand($sql_project)->query();

		$sql_categories  = "SELECT * from categories";

		    $categories = $connection->createCommand($sql_categories)->query();

			

	   

	    $sql_sector ="SELECT DISTINCT sector FROM plots";

		$result_sector = $connection->createCommand($sql_sector)->query();

		$result_members = $connection->createCommand($sql_member)->query();

		 

		    $home=Yii::app()->request->baseUrl; 

			if(isset($_POST['search'])){

            $res=array();



            foreach($result_members as $key){



			



			



            	

            echo '<tr><td>'.$key['project_name'].'</td><td>'.$key['street'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['id'].'">'.$key['plot_detail_address'].'</a></td><td>'.$key['plot_size'].'</td><td>'.$key['size'].'</td><td>'.$key['com_res'].'</td><td>'.$key['sector'].'</td><td>'.$key['create_date'].'</td><td>';

			if($key['status']==''){ echo'<a href="'.$home.'/index.php/memberplot/allotplot?id='.$key['id'].'">' ."Allot".'</a>';}else{ echo $key['status'];}echo '</td>

			<td><a href="reallocate?id='.$key['id'].'">Reallocate</a></td><td><a href="updateplot?id='.$key['id'].'">Edit</a>/<a href="deleteplot?id='.$key['id'].'">Delete</a></td></tr>'; 

            }}

			$this->render('plots_lis',array('members'=>$result_members,'projects'=>$result_project,'sectors'=>$result_sector,'pro'=>$pro,'st'=>$st,'sector'=>$sector,'plotno'=>$plotno,'categories'=>$categories));

			

	   

	}

	

	}

	



}



