<?php



class FinanceController extends Controller

{
public function actionPayment_details()

	{

		$connection = Yii::app()->db;

	$land  = "SELECT * FROM installpayment where plot_id='".$_REQUEST['id']."' ";

		$land_cost = $connection->createCommand($land)->queryAll();
		

		$sql_payment  = "SELECT * FROM plotpayment where plot_id='".$_REQUEST['id']."'";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

		

	   $sql_member= "SELECT mp.id,mp.plot_id,mp.plotno,mp.member_id,m.cnic,m.image,m.name FROM memberplot mp
	   left join members m on mp.member_id=m.id
	    where plot_id='".$_REQUEST['id']."'";

		$result_members = $connection->createCommand($sql_member)->queryAll();
		

		

		$sql = "SELECT pc.plot_id,pc.charges_id,c.name,c.total FROM plotcharges pc

left join charges c on pc.charges_id=c.id 

where plot_id='".$_REQUEST['id']."'";

		$res=$connection->createCommand($sql)->queryAll();

		

		//$sql_charges  = "SELECT * FROM plotcharges where plot_id='".$_REQUEST['id']."'";

		//$result_charges = $connection->createCommand($sql_charges)->queryAll();

		

		$sql_plotinfo  = "SELECT p.*,proj.project_name,sec.sector_name,st.street,s.size FROM plots p
		left join projects proj on p.project_id=proj.id
		left join sectors sec on p.sector=sec.id
		 left join streets st on p.street_id=st.id
		left join size_cat s on p.size2=s.id
		 where p.id='".$_REQUEST['id']."'";
		$result_plotinfo = $connection->createCommand($sql_plotinfo)->queryAll();

		

	

		$this->render('payment_details',array('payments'=>$result_payments,'landcost'=>$land_cost,'info'=>$result_plotinfo,'receivable'=>$res,'members'=>$result_members));

		

	}

	public function actionInstallment_details()

	{
		$connection = Yii::app()->db;
		$sql_payment  = "SELECT * FROM installpayment where plot_id='".$_REQUEST['id']."' ";
		$result_payments = $connection->createCommand($sql_payment)->queryAll();
			   $sql_member= "SELECT mp.id,mp.plot_id,mp.plotno,mp.member_id,m.cnic,m.name FROM memberplot mp
	   left join members m on mp.member_id=m.id
	    where plot_id='".$_REQUEST['id']."'";
		$result_members = $connection->createCommand($sql_member)->queryAll();
		$sql_charges  = "SELECT * FROM plotcharges where plot_id='".$_REQUEST['id']."'";
		$result_charges = $connection->createCommand($sql_charges)->queryAll();
	//	$sql_plotinfo  = "SELECT * FROM plots where id='".$_REQUEST['id']."'";
		$sql_plotinfo  = "SELECT p.*,proj.project_name,sec.sector_name,st.street,s.size FROM plots p
		left join projects proj on p.project_id=proj.id
		left join sectors sec on p.sector=sec.id
		 left join streets st on p.street_id=st.id
		left join size_cat s on p.size2=s.id
		 where p.id='".$_REQUEST['id']."'";
		$result_plotinfo = $connection->createCommand($sql_plotinfo)->queryAll();

		
		$sql_minfo  = "SELECT * FROM memberplot where plot_id='".$_REQUEST['id']."'";

		$result_minfo = $connection->createCommand($sql_minfo)->queryAll();

		

		$this->render('installment_details',array('payments'=>$result_payments,'charges'=>$result_charges,'info'=>$result_plotinfo,'minfo'=>$result_minfo,'members'=>$result_members));

		

	}
  public function actionSearchreq()

	 {
		$where='';

		$and=false;
		   $from=$_POST['fromdate'];
			$to=$_POST['todate'];
			//echo $from.$to; exit;
		
		
		 if (isset($_POST['status']) && $_POST['status']!=""){
                $and=true;

				if($_POST['status']=='new'){$where.="plotpayment.fstatus='' and paidamount!=''";}
				else if($_POST['status']=='due'){$where.="plotpayment.fstatus='' and paidamount=''";}else{
				$where.="plotpayment.fstatus LIKE '%".$_POST['status']."%'";
				}
				$and = true;
				
			}
				if (($_POST['fromdate']!="") && ($_POST['todate']!="")) {
				

				if ($and==true)

				{

				$where.="and plotpayment.date BETWEEN '".$from."' AND '".$to."' ";

				}else{$where.="plotpayment.date BETWEEN '".$from."' AND '".$to."' ";}

			$and=true;

			}
		if (isset($_POST['plotno']) && $_POST['plotno']!=""){
				$plotno=$_POST['plotno'];
				if ($and==true)
				{
					  $where.=" and memberplot.plotno ='".$_POST['plotno']."'";
				}
				else
				{
					$where.=" memberplot.plotno ='".$_POST['plotno']."'";
				}
				$and=true;

			}
			
			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				

				$pro=$_POST['project_id'];

				if ($and==true)

				{

					$where.=" and plots.project_id = '".$_POST['project_id']."'";

				}

				else

				{

					$where.=" plots.project_id = '".$_POST['project_id']."'";

				}

				$and=true;

			}

		$connection = Yii::app()->db; 
 $sql_payment  = "SELECT plots.plot_detail_address

	, plotpayment.*
    , plots.plot_detail_address
	 , plots.com_res
	 , plots.create_date
	 , projects.project_name
	 ,memberplot.plotno
FROM

    plotpayment

    Left JOIN plots  ON (plots.id = plotpayment.plot_id)
	Left JOIN projects  ON (projects.id = plots.project_id)
	Left JOIN memberplot  ON (memberplot.plot_id = plots.id)
	 where $where"; 
//		$sql_payment  = "SELECT * FROM plotpayment
	//	 where $where";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

        $sql_project = "SELECT * from projects";

		$result_project = $connection->createCommand($sql_project)->query();
		$sql_categories  = "SELECT * from categories";

		    $categories = $connection->createCommand($sql_categories)->query();
	    $sql_sector ="SELECT DISTINCT sector FROM plots";

		$result_sector = $connection->createCommand($sql_sector)->query();

		$sql_payments= $connection->createCommand($sql_payment)->query();
		
		$sql_size  = "SELECT * from size_cat";

		$sizes = $connection->createCommand($sql_size)->query();
		

	$count=0;

	if ($sql_payments!=''){

		$home=Yii::app()->request->baseUrl; 

    $res=array();
$i=0;
            foreach($sql_payments as $row){

          
//$old_date = $row['create_date'];            
//$middle = strtotime($old_date);             
//$new_date = date('d-m-Y', $middle);
		$i++;

		//$due=$due+$row['amount'];
		//$paid=$paid+$row['paidamount'];
  echo '<tr><td>' . $i . '</td>
 <td>' . $row['plotno'] . '</td>
 <td>' . $row['com_res'] . '</td>
 <td>' . $row['plot_detail_address'] . '</td>

 <td>' . $row['payment_type'] . '</td>

 <td style="text-align:right">' . number_format($row['amount']) . '</td>
 <td style="text-align:right">' . number_format($row['paidamount']) . '</td>

  <td >' . $row['duedate']. '</td>

  <td>' . $row['paidas'] . '</td>

  <td>' . $row['detail'] . '</td>

  <td>' . $row['surcharge'] . '</td>


   <td>' . $row['date'] . '</td>
 
  <td><a href="update_charges?id='.$row['id'].'">Verify Status</a></td>
  
</tr>  ';

		 

			} 

			}else{echo exit;}

	 exit;

	    if(isset($_POST['username']) && empty($_POST['username']))

			{

				$error = 'Please enter username<br>';

			}

			if(isset($_POST['password']) && empty($_POST['password']))

			{

				$error .= 'Please enter Password<br>';

			}

			if(empty($error))

			{

				  $username = $_POST['username'];

				 $password = md5($_POST['password']);

				  $connection = Yii::app()->db;  

				   $sql = "SELECT * FROM user where username ='".$username."' AND  password='".$password."' AND status=1";

				  $result_data = $connection->createCommand($sql)->queryRow();

				  if($result_data)

				  {

						Yii::app()->session['user_array'] = $result_data;

						echo 1;exit();

				  }else

				  {

					 echo "Invalid Username and Password"; 

				  }

			}else

			{

				echo $error;

			}

	exit;	 



	}
	
public function actionPayment_lis()

	{
		if((Yii::app()->session['user_array']['per9']=='1')&& isset(Yii::app()->session['user_array']['username']))

			{
			$plotno='';

			$st='';

			$pro='';

			$sector='';
			$size='';

			$cat='';

			$where='';

			$and = false;

			$where='';

			

			if (isset($_POST['sector']) && $_POST['sector']!=""){

				$where.="plots.sector LIKE '%".$_POST['sector']."%'";

				$and = true;

				$sector=$_POST['sector'];

			}

			

			if ($and==true)

				{

					$where.="  and type='plot' ";

				}

				else

				{

					$where.="type='plot' ";

				}

				$and=true;

			

			

			

			if (isset($_POST['plotno']) && $_POST['plotno']!=""){

				$plotno=$_POST['plotno'];

				if ($and==true)

				{

					  $where.=" and plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				else

				{

					$where.=" plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				$and=true;

			}

				if (isset($_POST['size']) && $_POST['size']!=""){

				$size=$_POST['size'];

				if ($and==true)

				{

					  $where.=" and plots.size2 LIKE '%".$_POST['size']."%'";

				}

				else

				{

					$where.=" plots.size2 LIKE '%".$_POST['size']."%'";

				}

				$and=true;

			}


			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				

				$pro=$_POST['project_id'];

				if ($and==true)

				{

					$where.=" and plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				else

				{

					$where.=" plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				$and=true;

			}

			

			

			if (isset($_POST['street_id']) && $_POST['street_id']!=""){

				$st=$_POST['street_id'];

				if ($and==true)

				{

					$where.=" and plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				else

				{

					$where.=" plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				$and=true;

			}

			

			

			

			

		

	$connection = Yii::app()->db; 

    $sql_member = "SELECT

    plots.id

    , plots.street_id

    , plots.plot_size

    , plots.com_res

	 , plots.size2

    , plots.rstatus

	, plots.sector

	, plots.category_id

	, plots.status

	, plots.plot_detail_address

	, memberplot.plotno

    , projects.project_name

	, streets.street


	

FROM

    plots

    Left JOIN streets  ON (plots.street_id = streets.id)


	Left JOIN projects  ON (plots.project_id = projects.id)

	Left JOIN memberplot  ON (plots.id = memberplot.plot_id)

where $where";
		$result_members = $connection->createCommand($sql_member)->query();
            $sql_payment  = "SELECT * FROM installpayment where fstatus='' and paidamount!=''";
			$result_payments = $connection->createCommand($sql_payment)->queryAll();
			$installments=count ( $result_payments );
       $connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$pro = $connection->createCommand($sql_project)->query() or mysql_error();
		$sql_categories  = "SELECT * from categories";
		$categories = $connection->createCommand($sql_categories)->query();
				$sql_size  = "SELECT * from size_cat";
		$sizes = $connection->createCommand($sql_size)->query();
	    $sql_sector ="SELECT DISTINCT sector FROM plots";
		$result_sector = $connection->createCommand($sql_sector)->query();
		    $home=Yii::app()->request->baseUrl; 
			if(isset($_POST['search'])){
            $res=array();
            foreach($result_members as $key){
            echo '<tr><td>'.$key['plotno'].'</td><td>'.$key['project_name'].'</td><td>'.$key['street'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['id'].'">'.$key['plot_detail_address'].'</a></td><td>'.$key['plot_size'].'</td><td>'.$key['size2'].'</td><td>'.$key['com_res'].'</td><td>'.$key['sector'].'</td><td>'.$key['rstatus'].'</td><td>';

			if($key['status']==''){ echo'<a href="'.$home.'/index.php/memberplot/allotplot?id='.$key['id'].'">' ."Allot".'</a>';}else{ echo $key['status'];}echo '</td>

			<td><a href="reallocate?id='.$key['id'].'">Reallocate</a></td><td><a href="updateplot?id='.$key['id'].'">Edit</a>/<a href="deleteplot?id='.$key['id'].'">Delete</a></td></tr>'; 

            }}

			$this->render('payment_lis',array('members'=>$result_members,'installment'=>$installments,'sectors'=>$result_sector,'pro'=>$pro,'st'=>$st,'sector'=>$sector,'plotno'=>$plotno,'categories'=>$categories,'sizes'=>$sizes));
			}
			else{
				$this->redirect(array('user/dashboard'));
				}
			

	   

	}
	
public function actionAlotmentreq()

	 {
		$where='';

		$and=false;
			$from=$_POST['fromdate'];

			$to=$_POST['todate'];
   
		 if (isset($_POST['status']) && $_POST['status']!=""){

				if($_POST['status']=='new'){$where.="mp.fstatus=''";}else{
				$where.="mp.fstatus LIKE '%".$_POST['status']."%'";
				}
				$and = true;
			}
				if (($_POST['fromdate']!="") && ($_POST['todate']!="")) {
				

				if ($and==true)

				{

				$where.="and mp.create_date BETWEEN '".$from."' AND '".$to."' ";

				}else{$where.="mp.create_date BETWEEN '".$from."' AND '".$to."' ";}

			$and=true;

			}

		if (isset($_POST['plotno']) && $_POST['plotno']!=""){

				$plotno=$_POST['plotno'];

				if ($and==true)

				{

					  $where.=" and p.plot_detail_address ='".$_POST['plotno']."'";

				}

				else

				{

					$where.=" p.plot_detail_address ='".$_POST['plotno']."'";

				}

				$and=true;

			}
			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				
				if ($and==true)
				{
					$where.=" and p.project_id ='".$_POST['project_id']."'";
				}
				else
				{
					$where.=" p.project_id = '".$_POST['project_id']."'";
				}
				$and=true;
			}
		$connection = Yii::app()->db; 

		$sql_payment  = "SELECT  mp.member_id,mp.plotno,mp.create_date,mp.id as mp_id,p.type,m.name,mp.plotno,m.image,m.sodowo,m.cnic,p.plot_detail_address,mp.plot_id,mp.status,p.plot_size,s.street,j.project_name FROM memberplot mp

left join members m on mp.member_id=m.id

left join plots p on mp.plot_id=p.id

left join streets s on p.street_id=s.id


left join projects j on p.project_id=j.id

where $where ";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

        $sql_project = "SELECT * from projects";

		$result_project = $connection->createCommand($sql_project)->query();
		$sql_categories  = "SELECT * from categories";

		    $categories = $connection->createCommand($sql_categories)->query();
	    $sql_sector ="SELECT DISTINCT sector FROM plots";

		$result_sector = $connection->createCommand($sql_sector)->query();

		$sql_payments= $connection->createCommand($sql_payment)->query();
		
		$sql_size  = "SELECT * from size_cat";

		$sizes = $connection->createCommand($sql_size)->query();
		

	$count=0;

	if ($sql_payments!=''){

		$home=Yii::app()->request->baseUrl; 

    $res=array();
//$i=0;
            foreach($sql_payments as $key){

          
//$old_date = $row['create_date'];            
//$middle = strtotime($old_date);             
//$new_date = date('d-m-Y', $middle);
		
		$ID=$key['mp_id'];
		
		//$due=$due+$row['amount'];
		//$paid=$paid+$row['paidamount'];
  echo '<tr><td>'.$key['plotno'].'</td><td>'.$key['name'].'</td><td>'.$key['sodowo'].'</td><td>'.$key['cnic'].'</td><td>'.$key['plot_detail_address'].'<td>'.$key['plot_size'].'</td><td>'.$key['street'].'</td><td>'.$key['project_name'].'</td><td><a target="_blank" href="req_detail?id='.$ID.'">Detail</a>

 

  </td></tr>';

		 

			} 

			}else{echo exit;}

	 exit;

	    if(isset($_POST['username']) && empty($_POST['username']))

			{

				$error = 'Please enter username<br>';

			}

			if(isset($_POST['password']) && empty($_POST['password']))

			{

				$error .= 'Please enter Password<br>';

			}

			if(empty($error))

			{

				  $username = $_POST['username'];

				 $password = md5($_POST['password']);

				  $connection = Yii::app()->db;  

				   $sql = "SELECT * FROM user where username ='".$username."' AND  password='".$password."' AND status=1";

				  $result_data = $connection->createCommand($sql)->queryRow();

				  if($result_data)

				  {

						Yii::app()->session['user_array'] = $result_data;

						echo 1;exit();

				  }else

				  {

					 echo "Invalid Username and Password"; 

				  }

			}else

			{

				echo $error;

			}

	exit;	 



	}
	
public function actionAlotment_lis()

	{
		if((Yii::app()->session['user_array']['per9']=='1')&& isset(Yii::app()->session['user_array']['username']))

			{
			$plotno='';

			$st='';

			$pro='';

			$sector='';
			$size='';

			$cat='';

			$where='';

			$and = false;

			$where='';

			

			if (isset($_POST['sector']) && $_POST['sector']!=""){

				$where.="plots.sector LIKE '%".$_POST['sector']."%'";

				$and = true;

				$sector=$_POST['sector'];

			}

			

			if ($and==true)

				{

					$where.="  and type='plot' ";

				}

				else

				{

					$where.="type='plot' ";

				}

				$and=true;

			

			

			

			if (isset($_POST['plotno']) && $_POST['plotno']!=""){

				$plotno=$_POST['plotno'];

				if ($and==true)

				{

					  $where.=" and plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				else

				{

					$where.=" plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				$and=true;

			}

				if (isset($_POST['size']) && $_POST['size']!=""){

				$size=$_POST['size'];

				if ($and==true)

				{

					  $where.=" and plots.size2 LIKE '%".$_POST['size']."%'";

				}

				else

				{

					$where.=" plots.size2 LIKE '%".$_POST['size']."%'";

				}

				$and=true;

			}


			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				

				$pro=$_POST['project_id'];

				if ($and==true)

				{

					$where.=" and plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				else

				{

					$where.=" plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				$and=true;

			}

			

			

			if (isset($_POST['street_id']) && $_POST['street_id']!=""){

				$st=$_POST['street_id'];

				if ($and==true)

				{

					$where.=" and plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				else

				{

					$where.=" plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				$and=true;

			}

			

			

			

			

		

	$connection = Yii::app()->db; 

    $sql_member = "SELECT

    plots.id

    , plots.street_id

    , plots.plot_size

    , plots.com_res

	 , plots.size2
	

    , plots.rstatus

	, plots.sector

	, plots.category_id

	, plots.status

	, plots.plot_detail_address

	, memberplot.plotno
	, memberplot.create_date
	, memberplot.id as mp_id

    , projects.project_name

	, streets.street


	

FROM

    plots

    Left JOIN streets  ON (plots.street_id = streets.id)


	Left JOIN projects  ON (plots.project_id = projects.id)

	Left JOIN memberplot  ON (plots.id = memberplot.plot_id)

where $where";
		$result_members = $connection->createCommand($sql_member)->query();

        $connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();

		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql_categories  = "SELECT * from categories";
		$categories = $connection->createCommand($sql_categories)->query();
		$sql_size  = "SELECT * from size_cat";
		$sizes = $connection->createCommand($sql_size)->query();
		    $sql_sector ="SELECT DISTINCT sector FROM plots";
		$result_sector = $connection->createCommand($sql_sector)->query();
		    $home=Yii::app()->request->baseUrl; 
			if(isset($_POST['search'])){
            $res=array();
            foreach($result_members as $key){
            echo '<tr><td>'.$key['plotno'].'</td><td>'.$key['project_name'].'</td><td>'.$key['street'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['id'].'">'.$key['plot_detail_address'].'</a></td><td>'.$key['plot_size'].'</td><td>'.$key['size2'].'</td><td>'.$key['com_res'].'</td><td>'.$key['sector'].'</td><td>'.$key['rstatus'].'</td><td>';

			if($key['status']==''){ echo'<a href="'.$home.'/index.php/memberplot/allotplot?id='.$key['id'].'">' ."Allot".'</a>';}else{ echo $key['status'];}echo '</td>

			<td><a href="reallocate?id='.$key['id'].'">Reallocate</a></td><td><a href="updateplot?id='.$key['id'].'">Edit</a>/<a href="deleteplot?id='.$key['mp_id'].'">Delete</a></td></tr>'; 

            }}

			$this->render('alotment_lis',array('members'=>$result_members,'sectors'=>$result_sector,'pro'=>$result_projects,'st'=>$st,'sector'=>$sector,'plotno'=>$plotno,'categories'=>$categories,'sizes'=>$sizes));

			}else{
				$this->redirect(array('user/dashboard'));
				
				}

	   

	}	
	


	
	
public function actionTransferreq()

	 	{
		$where='';

		$and=false;
		
			$from=$_POST['fromdate'];

			$to=$_POST['todate'];
			

		 if (isset($_POST['status']) && $_POST['status']!=""){

				if($_POST['status']=='new'){$where.="tp.fstatus=''";}else{
				$where.="tp.fstatus LIKE '%".$_POST['status']."%'";
				}
				$and = true;
			}
							if (($_POST['fromdate']!="") && ($_POST['todate']!="")) {
				

				if ($and==true)

				{

				$where.="and tp.create_date BETWEEN '".$from."' AND '".$to."' ";

				}else{$where.="tp.create_date BETWEEN '".$from."' AND '".$to."' ";}

			$and=true;

			}

		if (isset($_POST['plotno']) && $_POST['plotno']!=""){

				$plotno=$_POST['plotno'];

				if ($and==true)

				{

					  $where.=" and p.plot_detail_address ='".$_POST['plotno']."'";

				}

				else

				{

					$where.=" p.plot_detail_address ='".$_POST['plotno']."'";

				}

				$and=true;

			}
			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				
				if ($and==true)
				{
					$where.=" and p.project_id LIKE '%".$_POST['project_id']."%'";
				}
				else
				{
					$where.=" p.project_id LIKE '%".$_POST['project_id']."%'";
				}
				$and=true;
			}

		$connection = Yii::app()->db; 

		$sql_payment  = "SELECT tp.*,s.street,siz.size,p.price,mp.comment,p.com_res,p.plot_detail_address,p.plot_size,pro.project_name,mp.plotno,m_from.name from_name,m_to.name to_name,m_to.RFM RFM FROM transferplot tp



			Left JOIN members m_from ON m_from.id=tp.transferfrom_id



			Left JOIN members m_to ON m_to.id=tp.transferto_id



			Left JOIN plots p ON p.id=tp.plot_id


			Left JOIN memberplot mp ON mp.plot_id=p.id


			Left JOIN streets s ON s.id=p.street_id


				Left JOIN size_cat siz  ON p.size2 = siz.id

			Left JOIN projects pro ON pro.id=p.project_id where $where AND tp.RFM=''AND tp.fstatus='' ";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

        $sql_project = "SELECT * from projects";

		$result_project = $connection->createCommand($sql_project)->query();
		$sql_categories  = "SELECT * from categories";

		    $categories = $connection->createCommand($sql_categories)->query();
	    $sql_sector ="SELECT DISTINCT sector FROM plots";

		$result_sector = $connection->createCommand($sql_sector)->query();

		$sql_payments= $connection->createCommand($sql_payment)->query();
		
		$sql_size  = "SELECT * from size_cat";

		$sizes = $connection->createCommand($sql_size)->query();
		

	$count=0;

	if ($sql_payments!=''){

		$home=Yii::app()->request->baseUrl; 

    $res=array();
$i=0;
            foreach($sql_payments as $key){

          
//$old_date = $row['create_date'];            
//$middle = strtotime($old_date);             
//$new_date = date('d-m-Y', $middle);
		$i++;

		//$due=$due+$row['amount'];
		//$paid=$paid+$row['paidamount'];
   echo '<tr><td>'.$key['id'].'</td><td>'.$key['from_name'].'</td><td>'.$key['to_name'].'</td><td>'.$key['plot_detail_address'].'</td><td>'.$key['price'].'</td><td>'.$key['size'].'</td><td>'.$key['plotno'].'</td><td>'.$key['com_res'].'</td><td>'.$key['street'].'</td><td>'.$key['project_name'].'</td><td><a target="_blank" href="treq_detail?id='.$key['id'].'">View Request</a></td></tr>'; 

		 

			} 

			}else{echo exit;}

	 exit;

	    if(isset($_POST['username']) && empty($_POST['username']))

			{

				$error = 'Please enter username<br>';

			}

			if(isset($_POST['password']) && empty($_POST['password']))

			{

				$error .= 'Please enter Password<br>';

			}

			if(empty($error))

			{

				  $username = $_POST['username'];

				 $password = md5($_POST['password']);

				  $connection = Yii::app()->db;  

				   $sql = "SELECT * FROM user where username ='".$username."' AND  password='".$password."' AND status=1";

				  $result_data = $connection->createCommand($sql)->queryRow();

				  if($result_data)

				  {

						Yii::app()->session['user_array'] = $result_data;

						echo 1;exit();

				  }else

				  {

					 echo "Invalid Username and Password"; 

				  }

			}else

			{

				echo $error;

			}

	exit;	 



	}
	
public function actionTransfer_lis()

	{
		if((Yii::app()->session['user_array']['per9']=='1')&& isset(Yii::app()->session['user_array']['username']))

			{
			$plotno='';

			$st='';

			$pro='';

			$sector='';
			$size='';

			$cat='';

			$where='';

			$and = false;

			$where='';

			

			if (isset($_POST['sector']) && $_POST['sector']!=""){

				$where.="plots.sector LIKE '%".$_POST['sector']."%'";

				$and = true;

				$sector=$_POST['sector'];

			}

			

			if ($and==true)

				{

					$where.="  and type='plot' ";

				}

				else

				{

					$where.="type='plot' ";

				}

				$and=true;

			

			

			

			if (isset($_POST['plotno']) && $_POST['plotno']!=""){

				$plotno=$_POST['plotno'];

				if ($and==true)

				{

					  $where.=" and plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				else

				{

					$where.=" plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";

				}

				$and=true;

			}

				if (isset($_POST['size']) && $_POST['size']!=""){

				$size=$_POST['size'];

				if ($and==true)

				{

					  $where.=" and plots.size2 LIKE '%".$_POST['size']."%'";

				}

				else

				{

					$where.=" plots.size2 LIKE '%".$_POST['size']."%'";

				}

				$and=true;

			}


			if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				

				$pro=$_POST['project_id'];

				if ($and==true)

				{

					$where.=" and plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				else

				{

					$where.=" plots.project_id LIKE '%".$_POST['project_id']."%'";

				}

				$and=true;

			}

			

			

			if (isset($_POST['street_id']) && $_POST['street_id']!=""){

				$st=$_POST['street_id'];

				if ($and==true)

				{

					$where.=" and plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				else

				{

					$where.=" plots.street_id LIKE '%".$_POST['street_id']."%'";

				}

				$and=true;

			}

			

			

			

			

		

	$connection = Yii::app()->db; 

    $sql_member = "SELECT

    plots.id

    , plots.street_id

    , plots.plot_size

    , plots.com_res

	 , plots.size2

    , plots.rstatus

	, plots.sector

	, plots.category_id

	, plots.status
	, transferplot.RFM
	

	, plots.plot_detail_address

	, memberplot.plotno

    , projects.project_name

	, streets.street
	, size_cat.size


	

FROM

    plots

    Left JOIN streets  ON (plots.street_id = streets.id)


	Left JOIN projects  ON (plots.project_id = projects.id)
	Left JOIN size_cat  ON (plots.size2 = size_cat.id)

	Left JOIN memberplot  ON (plots.id = memberplot.plot_id)
    Left JOIN transferplot  ON (memberplot.plot_id = transferplot.id)

where $where AND transferplot.RFM='' ";
		$result_members = $connection->createCommand($sql_member)->query();

        $connection = Yii::app()->db; 
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$temp_projects_array = Yii::app()->session['projects_array'];
		$num_of_projects_counter = count($temp_projects_array);	
		$num_of_projects_counter2 = $num_of_projects_counter;
		$sql1 =   "select * from projects where";
		$num_of_projects_counter--;
		while($num_of_projects_counter>-1)
		{
			$sql2[$num_of_projects_counter] = " id=".Yii::app()->session['projects_array'][$num_of_projects_counter]['project_id'];
			$num_of_projects_counter--;
		}
		
		$sql_project = $sql1;
		$sql_project = $sql_project.implode(' or',$sql2);
		$result_projects = $connection->createCommand($sql_project)->query() or mysql_error();

		$sql_categories  = "SELECT * from categories";
		$categories = $connection->createCommand($sql_categories)->query();
		$sql_size  = "SELECT * from size_cat";
		$sizes = $connection->createCommand($sql_size)->query();
	    $sql_sector ="SELECT DISTINCT sector FROM plots";
		$result_sector = $connection->createCommand($sql_sector)->query();
		    $home=Yii::app()->request->baseUrl; 
			if(isset($_POST['search'])){
            $res=array();
            foreach($result_members as $key){
            echo '<tr><td>'.$key['plotno'].'</td><td>'.$key['project_name'].'</td><td>'.$key['street'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['id'].'">'.$key['plot_detail_address'].'</a></td><td>'.$key['size'].'</td><td>'.$key['size2'].'</td><td>'.$key['com_res'].'</td><td>'.$key['sector'].'</td><td>'.$key['rstatus'].'</td><td>';

			if($key['status']==''){ echo'<a href="'.$home.'/index.php/memberplot/allotplot?id='.$key['id'].'">' ."Allot".'</a>';}else{ echo $key['status'];}echo '</td>

			<td><a href="reallocate?id='.$key['id'].'">Reallocate</a></td><td><a href="updateplot?id='.$key['id'].'">Edit</a>/<a href="deleteplot?id='.$key['id'].'">Delete</a></td></tr>'; 

            }}

			$this->render('transfer_lis',array('members'=>$result_members,'sectors'=>$result_sector,'pro'=>$result_projects,'st'=>$st,'sector'=>$sector,'plotno'=>$plotno,'categories'=>$categories,'sizes'=>$sizes));
			}else{
				$this->redirect(array('user/dashboard'));
				}
			

	   

	}	



public function actionUpdate_charges()

     	{

		if(Yii::app()->session['user_array']['per9']=='1' && isset(Yii::app()->session['user_array']['username']))

			{

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 
	
			$sql_charges  = "SELECT plotpayment.*,mp.plotno, m.name,m.cnic,m.phone,p.plot_detail_address,s.street,pr.project_name from plotpayment
			left join members m on plotpayment.mem_id=m.id
			left join plots p on plotpayment.plot_id=p.id
			left join memberplot mp on mp.plot_id=p.id
			left join streets s on p.street_id=s.id
			left join projects pr on p.project_id=pr.id
			where plotpayment.id='".$_REQUEST['id']."'
			";

			$result_charges = $connection->createCommand($sql_charges)->query();
			
			
		$this->render('update_charges',array('charges'=>$result_charges));


	
			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

    }
public function actionChargupdate()

	{       

			   $connection = Yii::app()->db;  
				 $error='';
			if ((isset($_POST['status']) && empty($_POST['status']))){
			$error.="Select  status. <br>";}
			if ((isset($_POST['remark']) && empty($_POST['remark']))){
			$error.="Enter Remark. <br>";
			}
			if(empty($error)){

			   $sql="UPDATE plotpayment set 
			 	fstatus='".$_POST['status']."',
			    others='".$_POST['remark']."'
			    where id=".$_POST['id']."";
               $command = $connection -> createCommand($sql);
               $command -> execute();
			   	echo 'Installment Updated Successfully';}
				else{ echo $error;}
			  
	}
	
	
  public function actionSearchinstallment()

	 	{
		$where='';

		$and=false;

		 if (isset($_POST['status']) && $_POST['status']!=""){

				if($_POST['status']=='new'){$where.="installpayment.fstatus='' and paidamount!=''";}
				else if($_POST['status']=='due'){$where.="installpayment.fstatus='' and paidamount=''";}else{
				$where.="installpayment.fstatus LIKE '%".$_POST['status']."%'";
				}
				$and = true;
			}
		if (isset($_POST['plotno']) && $_POST['plotno']!=""){

				$plotno=$_POST['plotno'];

				if ($and==true)

				{

					  $where.=" and mp.plotno ='".$_POST['plotno']."'";

				}

				else

				{

					$where.=" mp.plotno ='".$_POST['plotno']."'";

				}

				$and=true;

			}

		$connection = Yii::app()->db; 

		$sql_payment  = "SELECT mp.plotno,installpayment.payment_type,installpayment.dueamount,installpayment.paidamount,installpayment.due_date,installpayment.paidas,installpayment.detail,installpayment.surcharge,installpayment.paid_date,installpayment.id,installpayment.fstatus,installpayment.lab FROM installpayment 
		left join memberplot mp on(installpayment.plot_id=mp.plot_id)
		where $where";
		$result_payments = $connection->createCommand($sql_payment)->queryAll();
        $sql_project = "SELECT * from projects";
		$result_project = $connection->createCommand($sql_project)->query();
		$sql_categories  = "SELECT * from categories";
		    $categories = $connection->createCommand($sql_categories)->query();
	    $sql_sector ="SELECT DISTINCT sector FROM plots";
		$result_sector = $connection->createCommand($sql_sector)->query();
		$sql_payments= $connection->createCommand($sql_payment)->query();
		$sql_size  = "SELECT * from size_cat";
		$sizes = $connection->createCommand($sql_size)->query();
	$count=0;
	if ($sql_payments!=''){
		$home=Yii::app()->request->baseUrl; 
    $res=array();
$i=0;
            foreach($sql_payments as $row){
		$i++;
  echo '<tr><td>' . $i . '</td>
 <td>' . $row['plotno'] . '</td>
 <td>' . $row['lab'] . '</td>

 <td>' . $row['dueamount'] . '</td>
 <td>' . $row['paidamount'] . '</td>
  <td>' . $row['due_date']. '</td>
  <td>' . $row['payment_type'] . '</td>
  <td>' . $row['detail'] . '</td>
  <td>' . $row['surcharge'] . '</td>
   <td>' . $row['paid_date'] . '</td>
  <td><a href="update_installment?id='.$row['id'].'">Update</a></td>
</tr>  ';

		 

			} 

			}else{exit;}
exit;

	    if(isset($_POST['username']) && empty($_POST['username']))

			{

				$error = 'Please enter username<br>';

			}

			if(isset($_POST['password']) && empty($_POST['password']))

			{

				$error .= 'Please enter Password<br>';

			}

			if(empty($error))

			{

				  $username = $_POST['username'];

				 $password = md5($_POST['password']);

				  $connection = Yii::app()->db;  

				   $sql = "SELECT * FROM user where username ='".$username."' AND  password='".$password."' AND status=1";

				  $result_data = $connection->createCommand($sql)->queryRow();

				  if($result_data)

				  {

						Yii::app()->session['user_array'] = $result_data;

						echo 1;exit();

				  }else

				  {

					 echo "Invalid Username and Password"; 

				  }

			}else

			{

				echo $error;

			}

	exit;	 



	}	
	public function actionInstallment_lis()
	{
		
			if((Yii::app()->session['user_array']['per9']=='1')&& isset(Yii::app()->session['user_array']['username']))

			{
				$plotno='';
	
				$st='';
	
				$pro='';
	
				$sector='';
				$size='';
	
				$cat='';
	
				$where='';
	
				$and = false;
	
				$where='';
	
				
	
				if (isset($_POST['sector']) && $_POST['sector']!=""){
	
					$where.="plots.sector LIKE '%".$_POST['sector']."%'";
	
					$and = true;
	
					$sector=$_POST['sector'];
	
				}
	
				
	
				if ($and==true)
	
					{
	
						$where.="  and type='plot' ";
	
					}
	
					else
	
					{
	
						$where.="type='plot' ";
	
					}
	
					$and=true;
	
				
	
				
	
				
	
				if (isset($_POST['plotno']) && $_POST['plotno']!=""){
	
					$plotno=$_POST['plotno'];
	
					if ($and==true)
	
					{
	
						  $where.=" and plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";
	
					}
	
					else
	
					{
	
						$where.=" plots.plot_detail_address LIKE '%".$_POST['plotno']."%'";
	
					}
	
					$and=true;
	
				}
	
					if (isset($_POST['size']) && $_POST['size']!=""){
	
					$size=$_POST['size'];
	
					if ($and==true)
	
					{
	
						  $where.=" and plots.size2 LIKE '%".$_POST['size']."%'";
	
					}
	
					else
	
					{
	
						$where.=" plots.size2 LIKE '%".$_POST['size']."%'";
	
					}
	
					$and=true;
	
				}
	
	
				if ( isset($_POST['project_id']) &&  $_POST['project_id']!=""){				
	
					$pro=$_POST['project_id'];
	
					if ($and==true)
	
					{
	
						$where.=" and plots.project_id LIKE '%".$_POST['project_id']."%'";
	
					}
	
					else
	
					{
	
						$where.=" plots.project_id LIKE '%".$_POST['project_id']."%'";
	
					}
	
					$and=true;
	
				}
	
				
	
				
	
				if (isset($_POST['street_id']) && $_POST['street_id']!=""){
	
					$st=$_POST['street_id'];
	
					if ($and==true)
	
					{
	
						$where.=" and plots.street_id LIKE '%".$_POST['street_id']."%'";
	
					}
	
					else
	
					{
	
						$where.=" plots.street_id LIKE '%".$_POST['street_id']."%'";
	
					}
	
					$and=true;
	
				}
	
				
	
				
	
				
	
				
	
			
	
		$connection = Yii::app()->db; 
	
		$sql_member = "SELECT
	
		plots.id
	
		, plots.street_id
	
		, plots.plot_size
	
		, plots.com_res
	
		 , plots.size2
	
		, plots.rstatus
	
		, plots.sector
	
		, plots.category_id
	
		, plots.status
	
		, plots.plot_detail_address
	
		, memberplot.plotno
	
		, projects.project_name
	
		, streets.street
	
	
		
	
	FROM
	
		plots
	
		Left JOIN streets  ON (plots.street_id = streets.id)
	
	
		Left JOIN projects  ON (plots.project_id = projects.id)
	
		Left JOIN memberplot  ON (plots.id = memberplot.plot_id)
	
	where $where";
			$result_members = $connection->createCommand($sql_member)->query();
	
			$connection = Yii::app()->db; 
			$temp_projects_array = Yii::app()->session['projects_array'];
			$num_of_projects_counter = count($temp_projects_array);	
			$num_of_projects_counter2 = $num_of_projects_counter;
			$sql_categories  = "SELECT * from categories";
			$categories = $connection->createCommand($sql_categories)->query();
			$sql_pro  = "SELECT * from projects";
		$pro = $connection->createCommand($sql_pro)->query();
			$sql_size  = "SELECT * from size_cat";
			$sizes = $connection->createCommand($sql_size)->query();
			$sql_sector ="SELECT DISTINCT sector FROM plots";
			$result_sector = $connection->createCommand($sql_sector)->query();
				$home=Yii::app()->request->baseUrl; 
				if(isset($_POST['search'])){
				$res=array();
				foreach($result_members as $key){
				echo '<tr><td>'.$key['plotno'].'</td><td>'.$key['project_name'].'</td><td>'.$key['street'].'</td><td><a href="'.$home.'/index.php/user/plothistory?id='.$key['id'].'">'.$key['plot_detail_address'].'</a></td><td>'.$key['plot_size'].'</td><td>'.$key['size2'].'</td><td>'.$key['com_res'].'</td><td>'.$key['sector'].'</td><td>'.$key['rstatus'].'</td><td>';
	
				if($key['status']==''){ echo'<a href="'.$home.'/index.php/memberplot/allotplot?id='.$key['id'].'">' ."Allot".'</a>';}else{ echo $key['status'];}echo '</td>
	
				<td><a href="reallocate?id='.$key['id'].'">Reallocate</a></td><td><a href="updateplot?id='.$key['id'].'">Edit</a>/<a href="deleteplot?id='.$key['id'].'">Delete</a></td></tr>'; 
	
				}}
	
				$this->render('installment_lis',array('members'=>$result_members,'sectors'=>$result_sector,'pro'=>$pro,'st'=>$st,'sector'=>$sector,'plotno'=>$plotno,'categories'=>$categories,'sizes'=>$sizes));
			}else{
				$this->redirect(array('user/dashboard'));
				}
				
	
		   
	
		}

	public function actionUpdate_installment()
	{

		if(Yii::app()->session['user_array']['per9']=='1' && isset(Yii::app()->session['user_array']['username']))

			{

	$this->layout='//layouts/back';

    $connection = Yii::app()->db; 
	
			$sql_charges  = "SELECT installpayment.*,mp.plotno, m.name,m.cnic,m.phone,p.plot_detail_address,s.street,pr.project_name from installpayment
			left join members m on installpayment.mem_id=m.id
			left join plots p on installpayment.plot_id=p.id
			left join memberplot mp on mp.plot_id=p.id
			left join streets s on p.street_id=s.id
			left join projects pr on p.project_id=pr.id
			where installpayment.id='".$_REQUEST['id']."'
			";

			$result_charges = $connection->createCommand($sql_charges)->query();
			
			
		$this->render('update_installment',array('charges'=>$result_charges));


	
			}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/dashboard"); }

    }
	
	public function actionInstallmentupdate()
	{       
				$error='';
				
			   $connection = Yii::app()->db;  
				 $error='';
			if ((isset($_POST['status']) && empty($_POST['status']))){
			$error.="Please Select Status. <br>";}
			if ((isset($_POST['remark']) && empty($_POST['remark']))){
			$error.="Please Enter Remarks. <br>";
			}
				
				if(empty($error))
				{
			   $sql="UPDATE installpayment set 
			 	fstatus='".$_POST['status']."',
			    others='".$_POST['remark']."'
			    where id=".$_POST['id']."";
               $command = $connection -> createCommand($sql);
               $command -> execute();
			   	echo 'Installment Updated Successfully';
				}
				else{
					echo $error;
					}
	}	
	
	public function actionIndex()
	{
	if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))

		{
			 $this->redirect(array('datasource'));
		}else
		{
			$error = '';
			$layout='//layouts/column1';
			$this->render('index');
		}
	}

	public function actionFinance()
	 {
				if((Yii::app()->session['user_array']['per9']=='1')&& isset(Yii::app()->session['user_array']['username']))

			{
			
			$connection = Yii::app()->db; 
	
			
			$sql_payment  = "SELECT * FROM installpayment where fstatus='' and paidamount!=''  ";
			$result_payments = $connection->createCommand($sql_payment)->queryAll();
			$installments=count ( $result_payments );

			$sql_project = "SELECT * FROM plotpayment where fstatus='' and paidamount!=''";
			$result_project = $connection->createCommand($sql_project)->query();
			$payments=count ( $result_project );
			
			$sql_transfer = "
			SELECT *
			FROM transferplot 
						  where RFM='' AND fstatus !='Approved'";
			$result_transfer = $connection->createCommand($sql_transfer)->query();
			$transfer=count ( $result_transfer );
			
			$sql_allot = "SELECT mp.* FROM memberplot mp where fstatus=''";
			$result_allot = $connection->createCommand($sql_allot)->query();
			$allot=count ( $result_allot);
			
	
			$layout='//layouts/back';
			$this->render('finance',array('payments'=>$payments,'transfer'=>$transfer,'allot'=>$allot,'installments'=>$installments));
			}
			else{
				$this->redirect(array('user/dashboard'));
				}
	}
	//////////////////////////////////////////

	

	  

	

	public function loadModel($id)
	{

		$model=User::model()->findByPk($id);

		if($model===null)

			throw new CHttpException(404,'The requested page does not exist.');

		return $model;

	}

	protected function performAjaxValidation($model)
	{

		if(isset($_POST['ajax']) && $_POST['ajax']==='user-form')

		{

			echo CActiveForm::validate($model);

			Yii::app()->end();

		}

	}
	
	public function actionReq_detail()
	{

	if(Yii::app()->session['user_array']['per9']=='1')

			{

			$connection = Yii::app()->db; 	

		$sql_details  = "SELECT mp.member_id, u.firstname,u.cnic,u.email,c.size,mp.fcomment,mp.noi,mp.id,mp.create_date,mp.insplan,mp.fstatus,mp.comment,mp.member_id,mp.user_name,mp.plotno,m.id,m.image, p.size2,m.name,m.sodowo,m.cnic,p.price,p.com_res,p.status,p.plot_detail_address,p.type,p.id,p.plot_size,p.project_id,s.street, mp.plot_id,j.project_name FROM  memberplot mp
left join members m on mp.member_id=m.id
left join plots p on mp.plot_id=p.id
left join streets s on p.street_id=s.id
left join size_cat c on p.size2=c.id
left join user u on mp.user_name=u.id

left join projects j on s.project_id=j.id where mp.id=".$_REQUEST['id'];

			$result_details = $connection->createCommand($sql_details)->query();

			

			$sql_payment  = "SELECT * from plotpayment where plot_id='".$_REQUEST['id']."'";

			$result_payments = $connection->createCommand($sql_payment)->queryRow();

			$this->render('req_detail',array('plotdetails'=>$result_details, 'plotpayments'=>$result_payments)); 

			}else{$this->redirect(array("dashboard"));}

	}
	
	public function actionSubmitstatus()
	{
		
	
		$connection = Yii::app()->db;
		$memberid=$_POST['member_id'];
		$plotid=$_POST['plot_id'];
		if($_POST['statusapp']=='Rejected')
		{
		 $sqldel="Delete from  memberplot where plot_id='".$plotid."'";
        $command = $connection -> createCommand($sqldel);
        $command -> execute(); 
		$sqlup="Update plots SET status='' where id='".$plotid."'";	
		
        $command = $connection -> createCommand($sqlup);
        $command -> execute();
		
		$sql2="DELETE FROM  installpayment where plot_id='".$plotid."'";		
        $command = $connection -> createCommand($sql2);
        $command -> execute();

		$this->redirect(array("finance/alotment_lis"));
		}
		if($_POST['statusapp']=='approved')
		{
		$sql="Update memberplot SET fstatus='".$_POST['statusapp']."', fcomment='".$_POST['cmnt']."' where plot_id='".$plotid."'";	
		//$sql="Update plots SET status='Alloted' where plot_id='".$plotid."'";	
        $command = $connection -> createCommand($sql);
        $command -> execute();
		
		$this->redirect(array("finance/alotment_lis"));
		}
		
	}
	
	public function actionTreq_detail()
	{
	if(Yii::app()->session['user_array']['per9']=='1')
			{
			$connection = Yii::app()->db; 	
			$sql_details  = "SELECT tp.*,s.street,p.plot_detail_address,p.plot_size,sc.size,mp.comment,se.sector_name,pro.project_name,m_from.name from_name,m_to.name to_name 
			,m_to.cnic,m_to.address,m_to.sodowo,u.email,u.firstname,m_to.state
			FROM transferplot tp
			Left JOIN members m_from ON m_from.id=tp.transferfrom_id
			Left JOIN members m_to ON m_to.id=tp.transferto_id
			Left JOIN plots p ON p.id=tp.plot_id
			Left JOIN sectors se ON se.id=p.sector
			Left JOIN streets s ON s.id=p.street_id
			Left JOIN size_cat sc ON sc.id=p.size2
			Left JOIN memberplot mp ON p.id=mp.plot_id
			left join user u on tp.uid=u.id
			Left JOIN projects pro ON pro.id=p.project_id where tp.id=".$_REQUEST['id']."";
			$result_details = $connection->createCommand($sql_details)->query();
			$this->render('treq_detail',array('plotdetails'=>$result_details)); 
			}else{$this->redirect(array("dashboard"));}



	}
	
	public function actionTsubmitstatus()
	{
	$connection = Yii::app()->db;  
	// Insert in to member a new member
    $connection = Yii::app()->db;  
    $sql3 = "UPDATE transferplot SET fstatus ='".$_POST['status']."',fcomment ='".$_POST['cmnt']."' WHERE id = ".$_POST['plot_id'].""; 	
   
    $command = $connection -> createCommand($sql3);
	$command -> execute();
	$this->redirect('transfer_lis');
			
	}


}
