<?php































class MemberController extends Controller















{







		public function actionDownload()



{

	$plot_id = $_GET['plot_id'];





	$this->layout='//layouts/front';



	$connection = Yii::app()->db;  



		$sql_member  = "SELECT



    members.id

	,memberplot.plotno

	, members.name



    , members.sodowo



    , members.cnic



    , members.address



    , members.dob



    , members.email



    , members.phone



    , members.image



    , members.nomineename



	,members.city_id



	,plots.street_id



	,plots.type



	,plots.plot_size



	,plots.com_res



	,plots.sector



	,plots.size2

	,size_cat.size



	,plots.plot_detail_address



	,memberplot.create_date

	,streets.street



	FROM



    memberplot



    LEFT JOIN members 



        ON (memberplot.member_id = members.id ) 



		left join plots on memberplot.plot_id=plots.id

		left join size_cat on plots.size2=size_cat.id

		left join streets on plots.street_id=streets.id



		where memberplot.plot_id=".$plot_id;



		



		$member_result = $connection->createCommand($sql_member)->queryAll();



	 	$this->render('pdf1',array('member'=>$member_result)); 



}









	















	/**















	 * Creates a new model.















	 * If creation is successful, the browser will be redirected to the 'view' page.















	 */

public function actionMembershiprequest1()



	     {

		 if(Yii::app()->session['user_array']['per2']=='1')

			{

			$connection = Yii::app()->db; 	

			$and = false;



			$where='';



			if (!empty($_POST['name'])){

				$where.="name LIKE '%".$_POST['name']."%'";

			//	$where.=" name = '".$_POST['name']."'";



				$and = true;



			}



			if (!empty($_POST['cnic'])){



				if ($and==true)



				{



					$where.=" and cnic ='".$_POST['cnic']."'";



				}



				else



				{



					$where.=" cnic = '".$_POST['cnic']."'";



				}



				$and=true;



			}


			 $sql_details  = "SELECT * from members 



where RFM='RFM'";

			$result_details = $connection->createCommand($sql_details)->query();

			$this->render('RFM',array('membershiprequest'=>$result_details));

			}else{

				$this->redirect(array("dashboard"));

				}

	   }





	public function actionRFM()

	     {

		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))



		{	 

		 if(Yii::app()->session['user_array']['per2']=='1')

			{

			$connection = Yii::app()->db; 	

			$sql_details  = "select * from members where RFM='RFM'";

			$result_details = $connection->createCommand($sql_details)->query();

			$this->render('RFM',array('membershiprequest'=>$result_details));

			}else{

				$this->redirect(array("dashboard"));

				}}

				else{$this->redirect(Yii::app()->baseUrl."/index.php/user/user"); }





	   }







public function actionUpdate_member()



	     {

		

		$uid=yii::app()->session['member_array']['id'];



		 if(!empty(Yii::app()->session['member_array']))

			{

			$this->layout='//layouts/front';

			$connection = Yii::app()->db;

				$sql_country  ="SELECT * FROM tbl_country";

			$result_country = $connection->createCommand($sql_country)->query();

		 $sql_details  = "SELECT m.*,c.country,p.city FROM members m

			Left JOIN tbl_country c ON c.id=m.country_id 

			Left JOIN tbl_city p ON p.id=m.city_id 

			 where m.id='".$uid."'";

			

			$result_details = $connection->createCommand($sql_details)->query();

			$this->render('update_member',array('update_member'=>$result_details,'country'=>$result_country));



			}else{$this->redirect(array("dashboard"));}



	   }







	 function actionCrop()















	 {















		if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{ 















			$this->layout='//layouts/front';















			$this->render('crop');















		}else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }















	}















	public function actionDownload1()















{















	$plot_id = $_GET['plot_id'];















	$this->layout='//layouts/front';















	$connection = Yii::app()->db;  















		$sql_member  = "SELECT















    members.name















    , members.sodowo















    , members.cnic















    , members.address















    , members.dob















    , members.email















    , members.phone















    , members.image















    , members.nomineename















	,members.city_id















FROM















    memberplot















    LEFT JOIN members 















        ON (memberplot.member_id = members.id) where memberplot.plot_id=".$plot_id;















		















		$member_result = $connection->createCommand($sql_member)->queryAll();















	 	$this->render('pdf',array('member'=>$member_result)); 















}















public function actionMemberupdate()

	{  

	 if(Yii::app()->session['user_array']['per1']=='1')

			{



		if(isset(Yii::app()->session['user_array']))







		{

			 $connection = Yii::app()->db;  



				

			if($_POST['status']=='1')

			{	



  $sql_update = "UPDATE members SET status ='1',RFM='', name='".$_POST['name']."', username='".$_POST['username']."', cnic='".$_POST['cnic']."', sodowo='".$_POST['sodowo']."', email='".$_POST['email']."', address='".$_POST['address']."', country_id='".$_POST['country']."', city_id='".$_POST['city']."', nomineename='".$_POST['nomineename']."', nomineecnic='".$_POST['nomineecnic']."', rwa='".$_POST['rwa']."' WHERE id = ".$_POST['memreq_id']."";

    		 $command = $connection -> createCommand($sql_update);

             $command -> execute();

			  $this->redirect(array("RFM"));

			}

			if($_POST['status']==2)

			{

			 $sql_delete = "Delete from  members  WHERE id = ".$_POST['memreq_id']."";

    		 $command = $connection -> createCommand($sql_delete);

             $command -> execute();

			 $this->redirect(array("RFM"));

			}

			}

			}



	   }









public function actionUpdate_member1()



	     {



		 if(Yii::app()->session['user_array']['per1']=='1')

			{

			$connection = Yii::app()->db;

				$sql_country  ="SELECT * FROM tbl_country";

			$result_country = $connection->createCommand($sql_country)->query();

		 $sql_details  = "SELECT m.*,c.country,p.city FROM members m

			Left JOIN tbl_country c ON c.id=m.country_id 

			Left JOIN tbl_city p ON p.id=m.city_id 

			 where m.id='".$_REQUEST['id']."'";

			

			$result_details = $connection->createCommand($sql_details)->query();

			$this->render('update_member1',array('update_member'=>$result_details,'country'=>$result_country));



			}else{$this->redirect(array("dashboard"));}



	   }







	public function actionCreate()



	{	if(Yii::app()->session['user_array']['per2']=='1')

		{

  $error =array();



		if((isset($_POST['name']) && empty($_POST['name']))|| (isset($_POST['dob']) && empty($_POST['address']))  || (isset($_POST['sodowo']) && empty($_POST['sodowo'])) || (isset($_POST['cnic']) && empty($_POST['cnic'])) || (isset($_POST['address']) && empty($_POST['address'])) || (isset($_POST['email']) && empty($_POST['email'])) || (isset($_POST['city_id']) && empty($_POST['city_id'])) ||  (isset($_POST['country']) && empty($_POST['country']))  || (isset($_POST['phone']) && empty($_POST['phone'])) || (isset($_POST['nomineename']) && empty($_POST['nomineename'])) || (isset($_POST['rwa']) && empty($_POST['rwa'])) || (isset($_POST['nomineecnic']) && empty($_POST['nomineecnic'])))

		{



			$error = 'Please complete all required fields <br />';



		}

		$connection = Yii::app()->db;  

		$sql_email  = "SELECT * FROM members where email ='".$_POST['email']."'";

		$result_email = $connection->createCommand($sql_email)->queryRow();



		if(!empty($result_email))



		{

			$error .= 'The Email Already Exists Enter Another Email<br>';



		}



       $sql_cnic  = "SELECT * FROM members where cnic ='".$_POST['cnic']."'";

			 $result_sq = $connection->createCommand($sql_cnic)->queryrow();

			 if(!empty($result_sq))

			 {

				  $error .="CNIC Already Exists Please Enter Another CNIC  ";

		}	



		// Insert in to member a new member

if(empty($error)){ 

    $sql  = 'INSERT INTO members 

          (name,username,password,sodowo, cnic, address, email, city_id, country_id,phone,nomineename,nomineecnic,rwa,dob,create_date,status )VALUES ( "'.$_POST['name'].'", "'.$_POST['email'].'", "'.($_POST['cnic']).'", "'.$_POST['sodowo'].'", "'.($_POST['cnic']).'", "'.($_POST['address']).'", "'.$_POST['email'].'", "'.$_POST['city_id'].'", "'.$_POST['country'].'", "'.$_POST['phone'].'", "'.$_POST['nomineename'].'", "'.$_POST['nomineecnic'].'", "'.$_POST['rwa'].'", "'.$_POST['dob'].'", "'.date('Y-m-d').'",1)';	



            $command = $connection -> createCommand($sql);

            $command -> execute();

			$pw=$_POST['cnic']; 

			$memid=Yii::app()->db->getLastInsertID();	

			

			$connection = Yii::app()->db;  

			$sql="SELECT * from members where id='".$memid."'";



			$result = $connection->createCommand($sql)->queryRow();

			//$content='Thank You For Registeration your user name='.$_POST['email'].' and password= '.$pw.'';



			$content='Dear Member,<br />



      We have the Honer to intimate that you have been registered in <b>Royal Developers & Bulders.</b><br />



      <br />



      Your user name = '.$_POST['email'].' <br />



      Password ='.$pw.'<br />



      <br />



      To view your onine profile  <a href="www.rdlpk.com/index.php/member/member">click hare to login </a><br />



      <br />



      Regards,<br />



      



      <b>Col. Fahim-ud-Din Shad</b><br />



      (Manager Marketing)<br />



      <img src="http://localhost/hb/images/logo.png" width="90" height="57" />



      ';



			//mail($_POST['email'],$_POST['email'],$content);







			$useremail=(Yii::app()->session['user_array']['email']);







			$sql1="SELECT * from user where email='".$useremail."'";







			$result1 = $connection->createCommand($sql1)->queryRow();







			echo'New Member Added Successfully<br>';



				echo '<a target="_blank" href="image?id='.$memid.'"><input type="button" class="btn-info" value="Add Image"><br>';



			echo 



			'<span class="btn-info button" font-size="16px"; style="color:#FFFFF";><a  href="sendmail?id='.$memid.'">Send Email To Member</a></span>'



			;

		//	$this->render('sendmail',array('result'=>$result,'content'=>$content,'result1'=>$result1));

	}







	if(!empty($error)){echo $error;exit;}







	}







	}











public function actionImage()



	{



		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))



		{ 



		$this->layout='//layouts/back';



		$this->render('image');



		}else{$this->redirect(Yii::app()->baseUrl."/index.php/user/user"); }

	}

public function actionMemimage()



{		

$connection = Yii::app()->db;  

		if(isset(Yii::app()->session['user_array']) && isset(Yii::app()->session['user_array']['username']))

				{ 

				 $id= $_POST['id'];

				

           

				$time_rand = time();



				$target_path="upload_pic/";



				$target_path = $target_path.$time_rand.$_FILES['image']['name'];



				$ad=explode('.',$_FILES['image']['name']); 



				$rnd=sizeof($ad);



				$ads=$rnd-1;



			     move_uploaded_file($_FILES['image']['tmp_name'], $target_path);

				 $sql="UPDATE members SET image='".$time_rand.$_FILES['image']['name']."' WHERE id=$id ";

				$command = $connection -> createCommand($sql);

			    $command -> execute();



			    $this->redirect(Yii::app()->baseUrl."/index.php/user/membershiprequest"); 

 		}	



	



}

                public function actionUpdateimg()

				{

					

	

					             $connection = Yii::app()->db;  

				  $s = "SELECT * FROM members where id=".$_POST['id'];

			     $res = $connection->createCommand($s)->queryRow();

				

				 if($_FILES['image']["name"]==''){

				 $image=$res['image'];

				  

					}else{ 

					

                 $image=$_FILES['image']["name"]; 

				$newfilename = $_FILES["image"]["name"];

				

				$path="upload_pic/";

				//unlink($path.$newfilename);





				move_uploaded_file($_FILES["image"]["tmp_name"],

				$path.$newfilename);

			    }

				 $sql="UPDATE members set image='".$image."' where id='".$_POST['id']."' ";

								 $command = $connection -> createCommand($sql);

                 $command -> execute(); 

				 $this->redirect(Yii::app()->baseUrl."/index.php/user/membershiprequest");

				

				



             	}



		public function actionSendmail()



			{



        	$connection = Yii::app()->db;  



			$sql="SELECT * from members where id='".$_REQUEST['id']."'";



			$result = $connection->createCommand($sql)->queryRow();



			//$content='Thank You For Registeration your user name='.$result['email'].' and password= '.$result['password'].'';



			//mail($_POST['email'],$_POST['email'],$content);



			$content='



			



			Dear Member,<br />



      We have the Honer to intimate that you have been registered in <b>Royal Developers & Bulders.</b><br />



      <br />



      Your user name = '.$result['email'].' <br />



      Password ='.$result['password'].'<br />



      <br />



      To view your onine profile  <a href="www.rdlpk.com/index.php/member/member">click hare to login </a><br />



      <br />



      Regards,<br />



      



      <b>Col. Fahim-ud-Din Shad</b><br />



      (Manager Marketing)<br />



      <img src="http://localhost/hb/images/logo.png" width="90" height="57" />';







stripslashes($content);



			$useremail=(Yii::app()->session['user_array']['email']);















			















			 















			$sql1="SELECT * from user where email='".$useremail."'";















			















			$result1 = $connection->createCommand($sql1)->queryRow();		















    $this->render('sendmail',array('result'=>$result,'content'=>$content,'result1'=>$result1)); 		















		















	















	}















		















		public function actionRequestTransfer()



	 	{



		if(Yii::app()->session['member_array'])

			{



            $error ='';



	    if(isset($_POST['cnic']) && empty($_POST['cnic']))

			{



				echo $error = 'Please enter cnic<br>';

			}

			if($error=='')



			{	

				  $connection = Yii::app()->db;  

				  $base=$_POST['cnic'];

			  $sql ="SELECT * from members where cnic=".$base;

				  $result_data = $connection->createCommand($sql)->queryRow();

                 			      if(empty($result_data))

				  {	 

                                    $error='';

                                    if ((isset($_POST['name']) && empty($_POST['name']))){

                                        $error.="name required. <br>";



                                    }

                                    if ((isset($_POST['name']) && empty($_POST['name']))){

                                        $error.=" Name required. <br>";

                                    }

                                    if ((isset($_POST['sodowo']) && empty($_POST['sodowo']))){

                                        $error.="SODOWO required. <br>";

                                    }

                                    if ((isset($_POST['cnic']) && empty($_POST['cnic']))){

                                        $error.="CNIC required. <br>";

                                    }

                                    if ((isset($_POST['address']) && empty($_POST['address']))){

                                        $error.="Address required. <br>";

                                    }

                                    if ((isset($_POST['email']) && empty($_POST['email']))){

									   $error.="Email required. <br>";

                                    }



                                    if ((isset($_POST['city']) && empty($_POST['city']))){

                                        $error.="City required. <br>";

                                    }

                                    if ((isset($_POST['state']) && empty($_POST['state']))){

                                        $error.="State required. <br>";

                                    }		

                                    if($error==''){



                                        $connection = Yii::app()->db;  



                                       $sql  = 'INSERT INTO members 

                (name,RFM,username, sodowo, cnic, address, email, city_id, state,status )VALUES ( "'.$_POST['name'].'","RFM", "'.$_POST['email'].'", "'.$_POST['sodowo'].'", "'.$base.'", "'.($_POST['address']).'", "'.$_POST['email'].'", "'.$_POST['city'].'", "'.$_POST['state'].'",0 )';		















                        				$command = $connection -> createCommand($sql);















                                        $command -> execute();















							            $transferto_memberid=Yii::app()->db->getLastInsertID();						 















					 				 //$transferto_memberid = 















                                    }else{















										$this->redirect(array('transferplot'=>$error)); 















                                        exit();















                                   }















                                         }















										 else{















                                        $transferto_memberid = $result_data['id'];















				  		                 }















	            					  $sql="INSERT INTO transferplot SET plot_id='".$_POST['plot_id']."',transferfrom_id='".$_POST['transfer_from_memberid']."',transferto_id='".                                     $transferto_memberid."',status='newrequest',cmnt='New Request',create_date='".date('Y-m-d H:i:s')."'";	  















        		   					 $command = $connection -> createCommand($sql);















                      				 $command -> execute();







									 $this->redirect(Yii::app()->baseUrl."/index.php/member/dashboard");















		}















		















			}















			}































	 function actionEdit()















	 {















		















		 if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{ 















			$this->layout='column3';















			$this->render('edit_register');















			















		}else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }















		 















	}















	public function actionUpdate($id)















	{















		















		$model=$this->loadModel($id);































		// Uncomment the following line if AJAX validation is needed















		// $this->performAjaxValidation($model);































		if(isset($_POST['User']))















		{















			$model->attributes=$_POST['User'];















			if($model->save())















				$this->redirect(array('view','id'=>$model->user_id));















		}































		$this->render('update',array(















			'model'=>$model,















		));















		















	}















	















	//////////////////////email member















	















	















	















	















	public function actionsend_email()







	{







	if(Yii::app()->session['user_array']['per2']=='1')







		{







			$connection = Yii::app()->db;  







			if (isset($_POST["from"]))







			{







			$To = $_POST["To"];







			$from = $_POST["from"];







			$subject="Registeration Confirmation"; 







		   $date= date('Y-m-d H:i:s');







			$content = $_POST["detail_content"];







			$sender=Yii::app()->session['user_array']['username'];







		   ////////////////save data in mailto member table////////////////







				$sql="INSERT into mailto_member(member_id,date,sender,message) VALUES('".$To."','".$date."','".$sender."','".$content."')";







				$command = $connection -> createCommand($sql);







				$command -> execute();







		 ///////////////////////EMAIL to MEMBER//////////////







				mail($To, $subject, $content,"From: $from\n");







				







			}







		}







		$this->redirect(array('member/maillist'));







	}















		/////////////////////Update email to member















	















	















	















	















	















	/////////////////////////MEMBER QUERY DETAIL////////////















	 public function actionRegister_member_query_detail()















	 {















		 $this->layout='//layouts/front';















		 if(Yii::app()->session['user_array']['per8']=='1')















			{















			$connection = Yii::app()->db; 	







	







			$sql="UPDATE register_member_answer SET status='1' WHERE id='".$_REQUEST['id']."'";

			$command = $connection -> createCommand($sql);

            $command -> execute();















			$sql_details  = "SELECT * from register_member_answer where id='".$_REQUEST['id']."'";







			$result_details = $connection->createCommand($sql_details)->query();















			$this->render('register_member_query_detail',array('register_member_query_detail'=>$result_details)); 















			}else{$this->redirect(array("dashboard"));}















	}















	















	















	















	















	/////////////////////////MEMBER MAIL BOX/////////////////















	public function actionMailbox()















	{	















	















	$this->layout='//layouts/front';















    $connection = Yii::app()->db; 















	$uid=yii::app()->session['member_array']['id'];















	$sql = "SELECT * FROM register_member_answer where user_id='".$uid."'";















	$result = $connection->createCommand($sql)->query();















	$this->render('mailbox',array('mailbox'=>$result));















	  	















	}















	/////////////////////////CHANGE MEMBER PASSWORD/////////////////















	public function actionChangepass()















	{	







	$this->layout='//layouts/front';















   $this->render('changepass');







	}













	public function actionUpdateinfo()

	{  



		$this->layout='//layouts/front';	

		$connection = Yii::app()->db; 

		 $error =array();

			 $error="";

			if(isset($_POST['address']) && empty($_POST['address']))

			{

				$error = 'Please Enter Address<br>';

			}

			if(isset($_POST['phone']) && empty($_POST['phone']))

			{

				$error .= 'Please Enter Contact No.<br>';

			}

				if(isset($_POST['city']) && empty($_POST['city']))

			{

				$error .= 'Please Enter City.<br>';

			}

				if(isset($_POST['country']) && empty($_POST['country']))

			{

				$error .= 'Please Enter Country.<br>';

			}

		$uid=yii::app()->session['member_array']['id'];

		if(empty($error)){

		

		 $sql="UPDATE members SET address='".$_POST['address']."',phone='".$_POST['phone']."', country_id='".$_POST['country']."', city_id='".$_POST['city']."' WHERE id='".$uid."'";

	    $command = $connection -> createCommand($sql);

        $command -> execute();

		echo 'Information Changed Successfully';

		

		}

		else{

			echo $error;

		}







		}



	public function actionChangepassword()

	{  



		$this->layout='//layouts/front';	

		$connection = Yii::app()->db; 

		 $error =array();

			 $error="";

			if(isset($_POST['newpassword']) && empty($_POST['newpassword']))

			{

				$error = 'Please Enter New Password<br>';

			}

			if(isset($_POST['newpassword1']) && empty($_POST['newpassword1']))

			{

				$error .= 'Please Enter Confirm New Password<br>';

			}

		$uid=yii::app()->session['member_array']['id'];

		if(empty($error)){

		if($_POST['newpassword']==$_POST['newpassword1'])

		{ 

		$pass=$_POST['newpassword'];	

		$sql="UPDATE members SET password='$pass' WHERE id='$uid'";

	    $command = $connection -> createCommand($sql);

        $command -> execute();

		echo 'Password Change Successfully';

		}



		else{

			echo "New Password And Confirm New Password Are Not Same "; exit;

		}



		}







		else{







			echo $error;







		}







		}







		







	















	 















	//////////////////////////DELETE MAIL/////////////















	















	public function actionRemove_mail()















	{	















	















	















    $connection = Yii::app()->db; 















	















	$sql = "Delete from register_member_answer where id='".$_GET['id']."' ";















	$command = $connection -> createCommand($sql);















    $command -> execute();















 $this->redirect(array("member/mailbox"));		















		















	}















	















	















		















	public function actionMaillist()















	{















		$connection=yii::app()->db;















		$sql="Select * from mailto_member";















		$result=$connection->CreateCommand($sql)->QueryAll();















		$this->render('maillist',array('maillist'=>$result));















			















	}















	public function actionMaildelete()















	{















		















		  $connection = Yii::app()->db;















	     $sql  = "Delete from mailto_member where id='".$_REQUEST['id']."'";















         $command = $connection -> createCommand($sql);















         $command -> execute();















			















		 $this->redirect(array("member/maillist"));		















		















			















	}















	































	/**















	 * Deletes a particular model.















	 * If deletion is successful, the browser will be redirected to the 'admin' page.















	 * @param integer $id the ID of the model to be deleted















	 */















	public function actionDelete($id)















	{















		$this->loadModel($id)->delete();































		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser















		if(!isset($_GET['ajax']))















			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));















	}































	public function actionIndex()















	{















		















		if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{















			 $this->redirect(array('member/dashboard'));















		}else















		{















			$error = '';















			















		$this->redirect('member/member'); 















		}















	}















	















	public function actionDashboard()



	{	

		if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))

		{ 

		    $this->layout='//layouts/front';

			$user_data = Yii::app()->session['member_array'];

			$connection = Yii::app()->db; 

			$sql_member = "SELECT * from members WHERE id = '".$user_data['id']."'";

			$result_members = $connection->createCommand($sql_member)->query();

			$sql = "SELECT mp.member_id,mp.plot_id,mp.status,mp.create_date,m.image,m.phone,p.project_id,m.address,m.name,m.username,m.mem_id,m.sodowo,m.cnic,p.id,p.plot_detail_address,mp.plotno,p.sector,p.plot_size,siz.size,p.street_id,s.street, j.project_name FROM

			 memberplot mp left join members m on mp.member_id=m.id

			  left join plots p on mp.plot_id=p.id

			   left join streets s on p.street_id=s.id

			   left join size_cat siz on p.size2=siz.id

			left join projects j on s.project_id=j.id  WHERE m.id = '".$user_data['id']."' and type='plot' AND mp.status='Approved'";

			$result = $connection->createCommand($sql)->query();

		$sqlfile = "SELECT mf.member_id,mf.plot_id,mf.plotno,mf.create_date,f.sector,f.project_id,siz.size,m.image,m.phone,m.address,m.name,m.username,m.mem_id,m.sodowo,m.cnic,f.id,f.plot_detail_address,f.plot_size,f.street_id,s.street, j.project_name FROM

			 memberplot mf left join members m on mf.member_id=m.id

			 

			  left join plots f on mf.plot_id=f.id

			  left join size_cat siz on f.size2=siz.id

			   left join streets s on f.street_id=s.id

			left join projects j on s.project_id=j.id WHERE m.id = '".$user_data['id']."' and type='file' AND mf.status='Approved'";

			$resultfile = $connection->createCommand($sqlfile)->query();



			 $sql_history  = "SELECT mp.plot_id,mp.transferfrom_id,mp.transfer_date,m.name,m.sodowo,m.cnic, m.address,p.id   plot_id,p.plot_detail_address,siz.size,sector,mp.transfer_date,p.plot_size,s.street,a.plotno, j.project_name FROM plothistory mp 

			left join members m on mp.transferfrom_id=m.id

			left join memberplot a on mp.plot_id=a.plot_id

			 left join plots p on mp.plot_id=p.id 

			 left join streets s on p.street_id=s.id

			  left join size_cat siz on p.size2=siz.id 

			 left join projects j on s.project_id=j.id 

			 WHERE transferfrom_id =".$user_data['id'].""; 















		    $result_pages = $connection->createCommand($sql_history)->query();







		







		







		







		$this->render('dashboard',array('result_members'=>$result_members,'result'=>$result,'resultfile'=>$resultfile,'pages'=>$result_pages));















		}















		else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }		















	}















		















 public function actionMemberimage()















	 {















			$connection = Yii::app()->db; 	















			$sql_details  = "SELECT * from members where id='".$_REQUEST['id']."'";















			















			$result_details = $connection->createCommand($sql_details)->queryRow();















			















			$this->render('dashboard',array('result_details'=>$result_details)); 		















	}		















	















	public function actionQuery()







	{



		  $connection = Yii::app()->db;  



	if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))



		{ 



	         $session=Yii::app()->session['member_array']['id'];



			 $sql  = 'INSERT INTO query (user_id,subject, message,create_date,status ) VALUES ( "'.$session.'", "'.$_POST['subject'].'", "'.$_POST['message'].'","'.date('Y-m-d').'","0" )';	



			 $command = $connection -> createCommand($sql);



             $command -> execute();



			 $this->redirect('dashboard'); 















                        	















		}















	}















	















	public function actionRegister()















	{















	$this->layout='//layouts/back';















		          $connection = Yii::app()->db; 















		  $sql_country  = "SELECT * from tbl_country ORDER BY country ASC";















		$result_country = $connection->createCommand($sql_country)->query();































		$this->render('register',array('country'=>$result_country));















		















	}















			















	public function actionAjaxRequest3($val1)















	{	















		$connection = Yii::app()->db;  















		$sql_city  = "SELECT * from tbl_city where country_id='".$val1."' ORDER BY city ASC";















		$result_city = $connection->createCommand($sql_city)->query();















			















		$city=array();















		foreach($result_city as $cit){















			$city[]=$cit;















			} 















		















	echo json_encode($city); exit();















	}















	















	public function actionUpload_image()







	{



		if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))



		{ 



		$this->layout='//layouts/front';



		$this->render('upload_image');



		}else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }



	}



	public function actionUpload_image1()







	{



		if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))



		{ 



		$this->layout='//layouts/front';



		$this->render('upload_image1');



		}else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }



	}







	function actionDoc_Upload_Form()















	 {















		















		$this->layout='//layouts/front';















		$this->render('Doc_Upload_Form');















		 















	}















	















	  function actionDoc_Upload()















	 {















		















		$this->layout='//layouts/front';















		$this->render('Doc_Upload');















		 















	}















	 function actionView_member_document()















	 {















		 















		if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{ 















		$this->layout='//layouts/front';















		$this->render('view_member_document'); }else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }















		 















	}















	















public function actionUpload_memberimage()

{

  		$connection = Yii::app()->db;  

	    if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))

		{ 

	    $session=Yii::app()->session['member_array']['id'];

		if(!empty($_FILES["image"]["name"]))



			{



				$target = ("SELECT image FROM members WHERE id=$session");

              	$result_image = $connection->createCommand($target)->query();

				foreach($result_image as $row){

				$old_image_name=$row['image'];

				$path="upload_pic/";

				unlink($path.$old_image_name);







				}







				$time_rand = time();



				$target_path="upload_pic/";



				$target_path = $target_path.$time_rand.$_FILES['image']['name'];



				$ad=explode('.',$_FILES['image']['name']); 



				$rnd=sizeof($ad);



				$ads=$rnd-1;



			     move_uploaded_file($_FILES['image']['tmp_name'], $target_path);



			}  $sql="UPDATE members SET image='".$time_rand.$_FILES['image']['name']."' WHERE id=$session ";







				$command = $connection -> createCommand($sql);







			    $command -> execute();



			    $this->redirect('dashboard'); 



 		}	







}







public function actionUpload_memberimage1()







{



		$connection = Yii::app()->db;  



	    if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))



		{ 



	    $session=Yii::app()->session['member_array']['id'];



		



			



				$time_rand = time();



				$target_path="upload_pic/";



				$target_path = $target_path.$time_rand.$_FILES['image']['name'];



				$ad=explode('.',$_FILES['image']['name']); 



				$rnd=sizeof($ad);



				$ads=$rnd-1;



			     move_uploaded_file($_FILES['image']['tmp_name'], $target_path);



			 $sql="UPDATE members SET image='".$time_rand.$_FILES['image']['name']."' WHERE id=$session ";







				$command = $connection -> createCommand($sql);







			    $command -> execute();



			    $this->redirect('dashboard'); 



 		}	







}















	















	public function actionReq_send()















	{















		if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{















		$this->layout='//layouts/front';















		$this->render('req_send');















		}else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }















	}	















	public function actionMember()















	{ 















		$this->layout='//layouts/front';















		$this->render('member');















	}















	















	public function actionCss_Media()















	{ 















		$this->layout='//layouts/front';















		$this->render('www/test/css_media');















	}















	















	public function actionLogout()















	{















		















		if(isset(Yii::app()->session['member_array']))















		{















			 $connection = Yii::app()->db;  















			 $sql_update = "UPDATE members SET login_status ='0' WHERE id = ".Yii::app()->session['member_array']['id']."";















    		 $command=$connection->createCommand($sql_update);















			 $command->execute();















			 unset(Yii::app()->session['member_array']);















			$this->redirect(Yii::app()->baseUrl."/index.php/web");















		}















		















	}















       public function actionGetLogin()











	 {



		 $error ='';



	    if(isset($_POST['username']) && empty($_POST['username']))



			{



				$error = 'Please Enter Username<br>';



			}



			if(isset($_POST['password']) && empty($_POST['password']))



			{



				$error .= 'Please Enter Password<br>';



			}



			if(empty($error))



			{



				 $username = $_POST['username'];



				 $password = $_POST['password'];



				  $connection = Yii::app()->db;  



				  $sql = "SELECT * FROM members where username ='".$username."' AND  password='".$password."' AND status=1"  ;



				  $result_data = $connection->createCommand($sql)->queryRow();



				  if($result_data)



				  {



						Yii::app()->session['member_array'] = $result_data;



						echo 1;



				  }else



				  {



					 echo "Invalid Username and Password"; 



				  }



			}



			if(!empty($error))



			{







				echo $error;



			}



			exit;	 



	}	















	public function actionMember_list()















	{	















	if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{















	$this->layout='//layouts/front';















	$user_data = Yii::app()->session['member_array'];















    $connection = Yii::app()->db; 















	$sql_member = "SELECT mp.member_id,mp.plot_id,mp.create_date,m.name,m.sodowo,m.cnic,p.plot_detail_address,p.plot_size,s.street, j.project_name FROM memberplot mp















left join members m on mp.member_id=m.id left join plots p on mp.plot_id=p.id left join streets s on p.street_id=s.id left join projects j on s.project_id=j.id WHERE m.id = '".    $user_data['id']."'";















	$result_members = $connection->createCommand($sql_member)->query();















	$this->render('member_list',array('members'=>$result_members));















	}else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }















			















	}















	///////////////////////MEMBER PLOT PAYMENT///////////////















	public function actionMember_plotpayment()















	{















   if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{















	$this->layout='//layouts/front';















	$user_data = Yii::app()->session['member_array'];















    $connection = Yii::app()->db; 















	$sql = "SELECT * from plotpayment WHERE mem_id= '".$user_data['id']."' and plot_id='".$_GET['plot_id']."'";















	$result = $connection->createCommand($sql)->queryAll();















	$this->render('member_plotpayment',array('members'=>$result));















	















	















	}else















	{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); 















	}















			















	}















	//////////////////////////////////////////////////////















	















	///////////////////////MEMBER File PAYMENT///////////////















	public function actionMember_filepayment()















	{















   if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{















	$this->layout='//layouts/front';















	$user_data = Yii::app()->session['member_array'];















    $connection = Yii::app()->db; 















	$sql = "SELECT * from filepayment WHERE mem_id= '".$user_data['id']."' and file_id='".$_GET['plot_id']."'";







	//$sql = "SELECT * from plotpayment WHERE mem_id= '".$user_data['id']."' and plot_id='".$_GET['plot_id']."'";























	$result = $connection->createCommand($sql)->queryAll();















	$this->render('member_filepayment',array('members'=>$result));















	















	















	}else















	{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); 















	}















			















	}















	//////////////////////////////////////////////////////















	public function actionTransferplot()

	{	



	if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))

		{ 

	$this->layout='//layouts/front';

	$plotid = $_REQUEST['plot_id'];		 

	$connection = Yii::app()->db;  

	$sql ="SELECT * from transferplot where plot_id='".$plotid."'";

	$result_data = $connection->createCommand($sql)->queryRow();

	if(empty($result_data)){  

	$connection = Yii::app()->db;  



    $user_data = Yii::app()->session['user_array'];

    $sql_plotedtails = "SELECT mp.member_id,mp.create_date, m.name,m.name,m.sodowo,m.cnic,p.id   plot_id,p.plot_detail_address,p.plot_size,s.street, j.project_name 

FROM memberplot mp left join members m on mp.member_id=m.id left join plots p on mp.plot_id=p.id left join streets s on p.street_id=s.id left join projects j on s.project_id=j.id 

   WHERE p.id ='".$_REQUEST['plot_id']."' ";

	$plotdetails = $connection->createCommand($sql_plotedtails)->queryRow();

	$this->render('transferplot',array('plotdetails'=>$plotdetails));

	exit();

	}else



	$connection = Yii::app()->db;

	$sql_new = "SELECT id FROM transferplot where plot_id=".$_REQUEST['plot_id']."";

	$result_new = $connection->createCommand($sql_new)->queryRow();	

	/*		$sql_details  = "SELECT tp.*,s.street,p.plot_detail_address,p.plot_size,pro.project_name,m_from.name from_name,m_from.name from_name,m_to.name to_name,m_to.name to_name FROM transferplot tp

			Left JOIN members m_from ON m_from.id=tp.transferfrom_id

			Left JOIN members m_to ON m_to.id=tp.transferto_id

			Left JOIN plots p ON p.id=tp.plot_id

			Left JOIN streets s ON s.id=p.street_id

			Left JOIN projects pro ON pro.id=p.project_id where tp.id='".$result_new['id']."'"; */

						$sql_details  = "SELECT tp.*,s.street,p.plot_detail_address,p.plot_size,pro.project_name,m_from.name from_name,m_to.name to_name,m_to.cnic to_cnic,m_to.sodowo to_sodowo,m_to.email to_email,m_to.address to_address,m_from.cnic from_cnic 

			,m_to.cnic,tp.create_date,m_to.address,m_to.sodowo,u.email,u.firstname,m_to.city_id,m_to.state

			FROM transferplot tp

			Left JOIN members m_from ON m_from.id=tp.transferfrom_id

			Left JOIN members m_to ON m_to.id=tp.transferto_id

			Left JOIN plots p ON p.id=tp.plot_id

			Left JOIN streets s ON s.id=p.street_id

			left join user u on tp.uid=u.id

			Left JOIN projects pro ON pro.id=p.project_id where tp.id=".$result_new['id']."";

			$result_details = $connection->createCommand($sql_details)->query();



			$result_details = $connection->createCommand($sql_details)->query();

			$this->render('req_detail',array('plotdetails1'=>$result_details)); 

		}else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }



	}



public function actionPayment_details()



	{

		

			$this->layout='//layouts/front';

		$connection = Yii::app()->db;

	 $land  = "SELECT * FROM installpayment where plot_id='".$_REQUEST['id']."' ";

		$land_cost = $connection->createCommand($land)->queryAll();

		$sql_payment  = "SELECT * FROM plotpayment where plot_id='".$_REQUEST['id']."'";

		$result_payments = $connection->createCommand($sql_payment)->queryAll();

	   $sql_member= "SELECT mp.id,mp.plot_id,mp.member_id,m.name FROM memberplot mp

	   left join members m on mp.member_id=m.id

	    where plot_id='".$_REQUEST['id']."'"; 

		$result_members = $connection->createCommand($sql_member)->queryAll();

		$sql = "SELECT pc.plot_id,pc.charges_id,c.name,c.total FROM plotcharges pc

left join charges c on pc.charges_id=c.id 

where plot_id='".$_REQUEST['id']."'";

		$res=$connection->createCommand($sql)->queryAll();



		 $sql_plotinfo  = "SELECT p.*,proj.project_name,s.size FROM plots p

		left join projects proj on p.project_id=proj.id

		left join size_cat s on p.size2=s.id

		 where p.id='".$_REQUEST['id']."'";

		$result_plotinfo = $connection->createCommand($sql_plotinfo)->queryAll();

		$this->render('payment_details',array('payments'=>$result_payments,'landcost'=>$land_cost,'info'=>$result_plotinfo,'receivable'=>$res,    'members'=>$result_members));

	}



	public function actionPayment()







	{	







		







			$this->layout='//layouts/front';







			$connection = Yii::app()->db;







			$sql_projects  = "SELECT * from plothistory where transferfrom_id='".$_REQUEST['id']."'";







			$result_projects = $connection->createCommand($sql_projects)->query();







			







			$sql_page  = "SELECT mp.member_id,mp.create_date, m.name,m.username,m.sodowo,m.cnic, m.address,p.id   ,mp.plot_id,p.plot_detail_address,p.plot_size,s.street, j.project_name 







FROM memberplot mp







left join members m on mp.member_id=m.id







left join plots p on mp.plot_id=p.id







left join streets s on p.street_id=s.id







left join projects j on s.project_id=j.id 







WHERE plot_id ='".$_REQUEST['id']."'";







			$result_pages = $connection->createCommand($sql_page)->query();







				







			$sql_charges  = "SELECT * from charges";







			$result_charges = $connection->createCommand($sql_charges)->query();







			







			$this->render('payment',array('projects'=>$result_projects,'pages'=>$result_pages,'charges'=>$result_charges));







			}







	

public function actionInstallment_details()



	{



		$connection = Yii::app()->db;

$this->layout='//layouts/front';



		



		$sql_payment  = "SELECT * FROM installpayment where plot_id='".$_REQUEST['id']."' ";



		$result_payments = $connection->createCommand($sql_payment)->queryAll();



		

			   $sql_member= "SELECT mp.id,mp.plot_id,mp.member_id,m.name FROM memberplot mp

	   left join members m on mp.member_id=m.id

	    where plot_id='".$_REQUEST['id']."'";



		$result_members = $connection->createCommand($sql_member)->queryAll();



		$sql_charges  = "SELECT * FROM plotcharges where plot_id='".$_REQUEST['id']."'";



		$result_charges = $connection->createCommand($sql_charges)->queryAll();



		

	//	$sql_plotinfo  = "SELECT * FROM plots where id='".$_REQUEST['id']."'";

		

		$sql_plotinfo  = "SELECT p.*,proj.project_name,s.size FROM plots p

		left join projects proj on p.project_id=proj.id

		left join size_cat s on p.size2=s.id

		 where p.id='".$_REQUEST['id']."'";

		$result_plotinfo = $connection->createCommand($sql_plotinfo)->queryAll();



		

		$sql_minfo  = "SELECT * FROM memberplot where plot_id='".$_REQUEST['id']."'";



		$result_minfo = $connection->createCommand($sql_minfo)->queryAll();



		



		$this->render('installment_details',array('payments'=>$result_payments,'charges'=>$result_charges,'info'=>$result_plotinfo,'minfo'=>$result_minfo,'members'=>$result_members));



		



	}



	







	public function actionPlothistory()















	{	















	if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{ 















			$this->layout='//layouts/front';















			$connection = Yii::app()->db;















			















			$sql_page  = "SELECT mp.member_id,mp.create_date, m.name,m.name,m.sodowo,m.cnic, m.address,p.id   plot_id,p.plot_detail_address,p.plot_size,s.street, j.project_name FROM memberplot mp left join members m on mp.member_id=m.id















           left join plots p on mp.plot_id=p.id left join streets s on p.street_id=s.id left join projects j on s.project_id=j.id WHERE plot_id ='".$_REQUEST['id']."'";















		    $result_pages = $connection->createCommand($sql_page)->query();















			















			$sql_history  = "SELECT mp.transferfrom_id,mp.transfer_date, m.name,m.name,m.sodowo,m.cnic, m.address,p.id   plot_id,p.plot_detail_address,p.plot_size,s.street, j.project_name FROM plothistory mp left join members m on mp.transferfrom_id=m.id















           left join plots p on mp.plot_id=p.id left join streets s on p.street_id=s.id left join projects j on s.project_id=j.id WHERE plot_id ='".$_REQUEST['id']."'";















		    $result_history = $connection->createCommand($sql_history)->query();















			















			$sql_projects  = "SELECT * from plothistory where transferfrom_id='".$_REQUEST['id']."'";















			$result_projects = $connection->createCommand($sql_projects)->query();















			















			















			















			$sql_plot_installment = "select installment from plots where id=1";















			$result_plot_installment = $connection->createCommand($sql_plot_installment)->query();	















			















			















			$this->render('plothistory',array('pages'=>$result_pages,'history'=>$result_history, 'projects'=>$result_projects,'num_of_installments'=>$result_plot_installment));















		}















		else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }















	}







public function actionTransferplothistory()















	{	















	if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{ 















			$this->layout='//layouts/front';















			$connection = Yii::app()->db;







			 /* $sql_page  = "SELECT mp.member_id,mp.create_date, m.name,m.name,m.sodowo,m.cnic, m.address,p.id   plot_id,p.plot_detail_address,p.plot_size,s.street, j.project_name FROM memberplot mp left join members m on mp.member_id=m.id















           left join plots p on mp.plot_id=p.id left join streets s on p.street_id=s.id left join projects j on s.project_id=j.id WHERE plot_id ='".$_REQUEST['id']."'";







	    $result_pages = $connection->createCommand($sql_page)->query();*/







			







			 $sql_history  = "SELECT mp.plot_id,mp.transferfrom_id,mp.transfer_date,m.name,m.sodowo,m.cnic, m.address,p.id   plot_id,p.plot_detail_address,p.plot_size,s.street, j.project_name FROM plothistory mp 







			left join members m on mp.transferfrom_id=m.id







			 left join plots p on mp.plot_id=p.id 







			 left join streets s on p.street_id=s.id 







			 left join projects j on s.project_id=j.id 







			 WHERE transferfrom_id =".$_REQUEST['id'].""; 















		    $result_pages = $connection->createCommand($sql_history)->query();















			$sql_projects  = "SELECT * from plothistory where transferfrom_id='".$_REQUEST['id']."'";















			$result_projects = $connection->createCommand($sql_projects)->query();







     		







			$this->render('dashboard',array('pages'=>$result_pages, 'projects'=>$result_projects));















		}















		else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }















	}















	///////////////////////////FILE HISTORY////////////////















	public function actionFilehistory()















	{	















	if(isset(Yii::app()->session['member_array']) && isset(Yii::app()->session['member_array']['username']))















		{ 















			$this->layout='//layouts/front';















			$connection = Yii::app()->db;















			















			$sql_page  = "SELECT mp.member_id,mp.create_date, m.name,m.name,m.sodowo,m.cnic, m.address,p.id   file_id,p.file_detail_address,p.file_size,s.street, j.project_name FROM memberfile mp left join members m on mp.member_id=m.id















           left join file p on mp.file_id=p.id left join streets s on p.street_id=s.id left join projects j on s.project_id=j.id WHERE file_id ='".$_REQUEST['id']."'";















		    $result_pages = $connection->createCommand($sql_page)->query();















			















			$sql_history  = "SELECT mp.transferfrom_id,mp.transfer_date, m.name,m.name,m.sodowo,m.cnic, m.address,p.id   file_id,p.file_detail_address,p.file_size,s.street, j.project_name FROM filehistory mp left join members m on mp.transferfrom_id=m.id















           left join file p on mp.file_id=p.id left join streets s on p.street_id=s.id left join projects j on s.project_id=j.id WHERE file_id ='".$_REQUEST['id']."'";















		    $result_history = $connection->createCommand($sql_history)->query();















			















			$sql_projects  = "SELECT * from filehistory where transferfrom_id='".$_REQUEST['id']."'";















			$result_projects = $connection->createCommand($sql_projects)->query();















			















			















			















			$this->render('filehistory',array('pages'=>$result_pages,'history'=>$result_history, 'projects'=>$result_projects));















		}















		else{$this->redirect(Yii::app()->baseUrl."/index.php/member/member"); }















	}















	















		















	//////////////////////////////////////////////////////















		















	public function loadModel($id)















	{















		$model=User::model()->findByPk($id);















		if($model===null)















		throw new CHttpException(404,'The requested page does not exist.');















		return $model;















	}































	/**















	 * Performs the AJAX validation.















	 * @param User $model the model to be validated















	 */















	protected function performAjaxValidation($model)















	{















		if(isset($_POST['ajax']) && $_POST['ajax']==='user-form')















		{















			echo CActiveForm::validate($model);















			Yii::app()->end();















		}















	}















}















