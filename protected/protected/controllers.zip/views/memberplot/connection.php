<?php

$host="localhost";

$user="rdlpk_admin";

$password="creative123admin";

$databasename="rdlpk_db1";



$con=  mysqli_connect($host,$user,$password,$databasename);



?>

