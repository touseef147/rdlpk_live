<h3>Personal Information</h3>
<table class="table table-striped table-new table-bordered" style="width:40%;">
<tbody>
<?php	
            $res=array();
            foreach($member as $key){
            echo '<tr><td>Name:</td><td>'.$key['name'].'</td></tr><tr><td> User Name:</td><td>'.$key['username'].'</td></tr><tr><td>SODOWO:</td><td>'.$key['sodowo'].'</td></tr><tr><td>CNIC:</td><td>'.$key['cnic'].'</td></tr><tr><td>Address</td><td>'.$key['address'].'</td></tr><tr><td>Email:</td><td>'.$key['email'].'</td></tr><tr><td>Create Date:</td><td>'.$key['create_date'].'</td></tr>'; 
            }?></tbody></table>

<h3>Owner</h3>
<table class="table table-striped table-new table-bordered">
            	<thead style="background:#666; border-color:#ccc; color:#fff;">
                    <tr>
                    
                        <th width="2%">#</th>
                        
                        <th width="11%">Date/Time</th>
                        
                        
                        
                        <th width="4%">Plot</th>
                        
                        <th width="5%">Plot Size</th>
                        
                        <th width="5%">Street</th>
                        
                        <th width="10%">Project</th>
                        
                      
                        
                    
                    </tr>
                </thead>
                
                <tbody>
                    <?php	
            $res=array();
            foreach($pages as $key){
            echo '<tr><td width="1%">'.$key['member_id'].'</td><td>'.$key['create_date'].'</td><td>'.$key['plot_detail_address'].'</td><td>'.$key['plot_size'].'</td><td>'.$key['street'].'</td><td>'.$key['project_name'].'</td></tr>'; 
            }?>
                </tbody>
            </table>

<h3>History</h3>
<table class="table table-striped table-new table-bordered">
            	<thead style="background:#666; border-color:#ccc; color:#fff;">
                    <tr>
                    
                          <th width="2%">#</th>
                        
                        <th width="11%">Date/Time</th>
                        
                        
                        
                        <th width="4%">Plot</th>
                        
                        <th width="5%">Plot Size</th>
                        
                        <th width="5%">Street</th>
                        
                        <th width="10%">Project</th>
                        
                    
                    </tr>
                </thead>
                
                <tbody>
                    <?php	
            $res=array();
            foreach($projects as $key){
            echo '<tr><td width="1%">'.$key['member_id'].'</td><td>'.$key['create_date'].'</td><td>'.$key['plot_detail_address'].'</td><td>'.$key['plot_size'].'</td><td>'.$key['street'].'</td><td>'.$key['project_name'].'</td></tr>';
            }?>
                </tbody>
            </table>