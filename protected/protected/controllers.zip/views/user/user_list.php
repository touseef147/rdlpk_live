<style>
.wc-text .btn-info {
	padding: 10px 15px;
	border-radius: 5px;
	color: #fff;
	text-decoration: none;
}
.wc-text .btn-info:hover {
	background: #09F;
}
</style>

<div class="my-content">
<div class="row-fluid my-wrapper">
<div class="shadow">
  <div class="span5 pull-right wc-text"> <a href="<?php echo Yii::app()->request->baseUrl; ?>/index.php/user/Add_user"  class="btn-info button">Add New Users</a>  </div>
  <h3>Users List</h3>
</div>

<!-- shadow -->

<hr noshade="noshade" class="hr-5 float-left">
<?php



$user_data = Yii::app()->session['user_array'];



 ?>
<form action="member_lis" method="post">
<div class="float-left">
  <p class="reg-right-field-area margin-left-5">
  <table class="table-striped table-bordered table span12">
    <thead>
    
       
    	  <td style="width:7%;"><b>User ID</b></td> 
      <td style="width:10%;"><b>Name</b></td>
      <td style="width:11%;"><b>Middle Name</b></td>
       <td style="width:10%;"><b>Last Name</b></td>
       <td style="width:11%;"><b>Login Name</b></td>
      <td style="width:11%;"><b>S/O,W/O</b></td>
      <td style="width:10%;"><b>Image</b></td>
       <td style="width:15%;"><b>Create Date</b></td>
  	  <td style="width:8%;"><b>Status</b></td>
      <td style="width:12%;"><b>Action</b></td>
        
        </thead>
      <?php	



            $res=array();



            foreach($members as $key){



            echo '<tr>
			
			
			
			<td>'.$key['id'].'</td><td>'.$key['firstname'].'</td><td>'.$key['middelname'].'</td><td>'.$key['lastname'].'</td><td>'.$key['username'].'</td><td>'.$key['sodowo'].'</td><td><img src="'.Yii::app()->request->baseUrl.'/images/user/'.$key['pic'].'" width="100" height="130" /></td><td>'.$key['create_date'].'</td><td>';if($key['status']==1){ echo 'Active';} else { echo 'Inactive';} echo'</td><td><a href="'.Yii::app()->request->baseUrl.'/index.php/user/update_user?id='.$key['id'].'">Update</a>/<a href="'.Yii::app()->request->baseUrl.'/index.php/user/delete_user?id='.$key['id'].'"> Delete</a></td></tr>'; 



            }?>
  </table>
  </p>
  <div class="clearfix"></div>
</div>
</div>
<script>



 



  $(document).ready(function()



     {  	



		



       $("#project").change(function()



           {



         	select_street($(this).val());



		   });



		   



		   $("#street_id").change(function()



           {



         	select_plot($(this).val());



		   });



     });



 



 



function select_street(id)



{



$.ajax({



      type: "POST",



      url:    "ajaxRequest?val1="+id,



	  contenetType:"json",



      success: function(jsonList){var json = $.parseJSON(jsonList);



var listItems='';



	$(json).each(function(i,val){



	listItems+= "<option value='" + val.id + "'>" + val.street + "</option>";



 



});listItems+="";







$("#street_id").html(listItems);



          }



    });



}



 



 



 







	 



function select_plot(id)



{



$.ajax({



      type: "POST",



      url:    "ajaxRequest1?val1="+id,



	  contenetType:"json",



      success: function(jsonList){var json = $.parseJSON(jsonList);



	  



var listItems='';



	$(json).each(function(i,val){



	listItems+= "<option value='" + val.id + "'>" + val.plot_detail_address +" ("+val.plot_size+")</option>";



      







});listItems+="";







$("#plot_id").html(listItems);



          }



    });



}







</script> 
