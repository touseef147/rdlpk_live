<div class="form-signin mg-btm">
<div class="shadow">
  <h3>Add Setting</h3>
</div>
<!-- shadow -->
<hr noshade="noshade" class="hr-5 float-left">
<section class="reg-section margin-top-30">

<form action="create" method="post" enctype="multipart/form-data">
<div id="error-div" class="errorMessage" style="display: none;"></div>
 
    <div class="float-left">
    <p class="reg-left-text">Owner Name<font color="#FF0000">*</font></p>
    <p class="reg-right-field-area margin-left-5">
      <input type="text" value="" name="ownername" id="ownername" class="form-control" placeholder="Enter name" />
    </p>
  </div>
 
   
    
    <div class="float-left">
    <p class="reg-left-text">Mobile No</p>
	<p class="reg-right-field-area margin-left-5">
    <input id="mobile" type="text" name="mobile" placeholder="Enter Mobile No" >
    </p>
    </div>
     <div class="float-left">
    <p class="reg-left-text">Telephone No(Office) </p>
	<p class="reg-right-field-area margin-left-5">
    <input id="phone" type="text" name="phone" placeholder="Enter Phone No" >
    </p>
    </div>
     <div class="float-left">
    <p class="reg-left-text">Email</p>
	<p class="reg-right-field-area margin-left-5">
    <input id="email" type="text" name="email" placeholder="Enter Email Address" >
    </p>
    </div>
      <div class="float-left">
    <p class="reg-left-text">Owner Message</p>
	<p class="reg-right-field-area margin-left-5">
   <textarea name="message" id="message"></textarea>
    </p>
    </div>
      <div class="float-left">
    <p class="reg-left-text">Address</p>
	<p class="reg-right-field-area margin-left-5">
    <input id="address" type="text" name="address" placeholder="Enter Office Address" >
    </p>
    </div>
      <div class="float-left">
    <p class="reg-left-text">Facebook</p>
	<p class="reg-right-field-area margin-left-5">
    <input id="facebook" type="text" name="facebook" placeholder="Enter Facebook Address" >
    </p>
    </div>
      <div class="float-left">
    <p class="reg-left-text">Twitter</p>
	<p class="reg-right-field-area margin-left-5">
    <input id="twitter" type="text" name="twitter" placeholder="Enter Twitter Address" >
    </p>
    </div>
      <div class="float-left">
    <p class="reg-left-text">Flicker</p>
	<p class="reg-right-field-area margin-left-5">
    <input id="flicker" type="text" name="flicker" placeholder="Enter Flicker Address" >
    </p>
    </div>
      <div class="float-left">
    <p class="reg-left-text">Google Plus</p>
	<p class="reg-right-field-area margin-left-5">
    <input id="googleplus" type="text" name="googleplus" placeholder="Enter GooglePlus Address" >
    </p>
    </div>
	
    <button type="submit" class="btn btn-info">Submit</button>
  </form>
 </div>
 </section>
<!-- section 3 --> 
  