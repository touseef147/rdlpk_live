<?php $create=0;?>
<div class="shadow">
   <h3>Installment Details</h3>
</div>

<hr noshade="noshade" class="hr-5">
<span style="float:right;">
	<h4>Member Details</h4>
<?php

 $res=array();
 $msid=0;	
    foreach($members as $mem){             
	echo   '<b>Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>' .$mem['name'].'</br>';
    echo   '<b>CNIC #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>' .$mem['cnic'].'</br>';
	  echo '<b>Membership #&nbsp;:</b>' .$mem['plotno'].'</br>';
	  $msid=$mem['id'];	
	}$connection = Yii::app()->db;
		$discount  = "SELECT * FROM discnt where ms_id='".$msid."' ";
		$discountr = $connection->createCommand($discount)->queryRow(); ?> 
	</span><?php $numbers=0;?>
<h4>Plot Details</h4>
<?php $res=array();
    foreach($info as $row){
$old_date = $row['create_date'];            
$middle = strtotime($old_date);             
$new_date = date('d-m-Y', $middle); 
	if($row['type']=='file'){
		echo '<b>File No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>';
		} 
		else{
			echo '<b>Plot No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>';
			}echo $row['plot_detail_address'].'</br>';
   if($row['type']=='file'){echo '<b>File Size&nbsp;&nbsp;&nbsp;:</b>';}else {echo '<b>Plot Size  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>';} echo $row['size'].' ('.$row['plot_size'].')'.'</br>';
	echo '<b>Location&nbsp;&nbsp;&nbsp;:</b>' .$row['sector_name'].'/'.$row['street'].'</br>';
    echo '<b>Project&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>' .$row['project_name'].'</br>';
	//echo '<b>Date  :</b>' .$new_date.'</br>';
	$price=$row['price'];
	}  ?>
    
    <?php
foreach($minfo as $row6){
	$numbers=$row6['noi'];
	$create=$row6['create_date'];
	$months=$row6['insplan'];
}
	$perins=0;
	if($numbers==0){$numbers=1;}
   $perins=$price/$numbers;
   
    ?>
<hr noshade="noshade" class="hr-5">
<section class="reg-section margin-top-30" style="font-size:11px;">
  <?php

;

// Check connection



$reciveable=0;

$paid=0;
$due=0;
$duesurcharge=0;
$paidsurcharge=0;



?>
<?php
//echo $resultn['status'];
if($resultn['status']=='Sales' ){
?>
<a href="installment_edit?id=<?php echo $_REQUEST['id']; ?>">Edit Installment Plan</a>
  <?php }?>
  <table  class="table table-striped table-new table-bordered">
    <thead style="background:#666; border-color:#ccc; color:#fff; ">
      <tr>
        <th><b>Sr.# </b></th>
       <th style="width:65px;"><b>Due Date</b></th>
        <th style="width:65px;"><b>Paid Date</b></th>
        <th><b>Due Amount</b></th>
        <th><b>Paid Amount</b></th>
       <th><b>Payment Mode</b></th>
        <th><b>DD/PO/CH No.</b></th>
         <th><b>Receipt No.</b></th>
        <th><b>Due Surcharge</b></th>
          <th><b>Paid Surcharge</b></th>
        <th style="width:120px;"><b>Remarks</b></th>
        <th style="width:140px;"><b>Status/Action</b></th>
      </tr>
    </thead>
    <tbody>
     <?php
	  $i=1;
	 $ins='';
	$res=array();
	foreach($payments as $pay)
	{	
$i++;
  $due=$due+$pay['dueamount'];
  $paid=$paid+$pay['paidamount'];
   $duesurcharge=$duesurcharge+$pay['surcharge'];
    $paidsurcharge=$paidsurcharge+$pay['paidsurcharge'];
	$oins=$due-$paid;
 	$co1=1;
	 foreach($payments as $pay2){if($pay2['ref']==$pay['id']){$co1++;}}
	if($pay['ref']==0){
		
  echo '<tr><td rowspan="'.$co1.'">'.$pay['lab']. '</td>

     <td rowspan="'.$co1.'">'.$pay['due_date'].'</td>
     <td>'.$pay['paid_date'].'</td>
     <td rowspan="'.$co1.'" style="text-align:right">'.$pay['dueamount'].'</td>
     <td style="text-align:right">'.$pay['paidamount'].'</td>
     <td>'.$pay['payment_type'].'</td>
     <td>'.$pay['detail'].'</td><td>';
	 if($pay['r_id']>0){
	  	$re1 = "SELECT * FROM rpt_print where rid='".$pay['r_id']."' and msid='".$pay['plot_id']."'";
		$rec1=$connection->createCommand($re1)->queryRow();	
		echo $rec1['r_no'];
		}; 
  if($pay['re_id'] > 0){ 
  		$re = "SELECT * FROM rpt_print where id='".$pay['re_id']."'";
		$rec=$connection->createCommand($re)->queryRow();
		echo $rec['r_no'];
		}
	 echo '</td>
     <td align="right">'.$pay['surcharge'].'</td>
	 <td align="right">'.$pay['paidsurcharge'].'</td>
     <td>'.$pay['remarks'].'</td>
     <td>';if(!empty($pay['fstatus'])){if($pay['fstatus']=='approved'){ 
	 echo '<b style="color:Green;">Verified /</b>';}else{echo '<b style="color:red;">'.$pay['fstatus'].' /</b>';}}
	 if($resultn['status']=='Sales' && $pay['fstatus']!=='approved'){echo '<a href="deleteins?did='.$pay['id'].'">Delete</a>';}
	 echo '</td>';
	 $id='';
	$id=$pay['id'];
	 }
	 foreach($payments as $pay1){
	 if($pay1['ref']==$id){
	echo '<tr>

    
     <td>'.$pay1['paid_date'].'</td>
     <td style="text-align:right">'.$pay1['paidamount'].'</td>
     <td>'.$pay1['payment_type'].'</td>
     <td>'.$pay1['detail'].'</td><td>';
	 if($pay['r_id']>0){
	  	$re1 = "SELECT * FROM rpt_print where rid='".$pay['r_id']."' and msid='".$pay['plot_id']."'";
		$rec1=$connection->createCommand($re1)->queryRow();	
		echo $rec1['r_no'];
		}; 
  if($pay['re_id'] > 0){ 
  		$re = "SELECT * FROM rpt_print where id='".$pay['re_id']."'";
		$rec=$connection->createCommand($re)->queryRow();
		echo $rec['r_no'];
		}
	 echo '</td>
     <td align="right">'.$pay1['surcharge'].'</td>
	 <td align="right">'.$pay1['paidsurcharge'].'</td>
     <td>'.$pay1['remarks'].'</td>
     <td>';if(!empty($pay1['fstatus'])){if($pay1['fstatus']=='approved'){ echo '<b style="color:Green;">Verified</b>';}else{echo '<b style="color:red;">'.$pay1['fstatus'];
echo '</b>';}
}
	 
	if($resultn['status']=='Sales' ){echo '<a href="deleteins?did='.$pay1['id'].'">Delete</a>';}
	}}
	
	 }
	
	echo '<tr>
<td><b>Total:</b></td>
<td></td>
<td></td>
<td style="text-align:right"><b>'.number_format($due).'</b></td>
<td style="text-align:right"><b>'.number_format($paid).'</b></td>
<td align="right"></td>
<td></td>
<td align="right"><b>'.number_format($duesurcharge).'</b></td>
<td align="right"><b>'.number_format($paidsurcharge).'</b></td>
<td></td>
<td></td>
<td></td>
</tr>';
echo '<tr><td><b>Discount:</b></td>
<td></td>
<td></td>
<td align="right"></td><td style="text-align:right"><b>'.$discountr['discount'].'</b></td>
<td></td>
<td align="right"></td>
<td></td><td align="right"></td><td style="text-align:right"><b>'.$discountr['details'].'</b></td>
<td></td><td></td>
</tr>


';
if($due==0){$due=1;}
echo '<tr><td><b>Outstanding Installment</b></td><td></td><td></td><td style="text-align:right;"><b>'.number_format($oins-$discountr['discount']).'</b></td><td style="text-align:right;"><b>'.number_format(($oins-$discountr['discount'])/$due*100).'%'.'</b></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>

';

	?>
    </tbody>
  </table>
</section>
</div>
<form id="form1" action="<?php echo Yii::app()->baseUrl; ?>/dompdf/www/pdfgenerator.php" target="_blank" method="post">

 <input type="hidden" name="paper" value="a4">
  <input type="hidden" name="orientation" value="portrait">
<textarea style="visibility:hidden;" name="html" id="html">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PDF Report</title>
<style>
td{ padding:0px;  border-top:1px solid #000; border-left:1px solid #000;}
.table-bordered{ border-right:1px solid #000; border-bottom:1px solid #000;}


</style>
</head>

<body>


<section class="reg-section " style="font-size:11px;">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
   <td colspan="2" style="border-bottom:thin solid #000"><img  src="<?php echo Yii::getPathOfAlias('webroot')."/images/royal_orchard.jpg";  ?>" height="92px">
   </td>
  </tr>
  <tr>
    <td width="60%"><h4>Plot Details</h4>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
<?php $res=array();
    foreach($info as $row){
$old_date = $row['create_date'];            
$middle = strtotime($old_date);             
$new_date = date('d-m-Y', $middle); 
?>
  <tr>
    <td style="width:85px"><?php if($row['type']=='file'){
		echo '<b>File No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>';
		} 
		else{
			echo 'Plot No:&nbsp;';}?></td>
    <td>
<?php
	echo $row['plot_detail_address'];
	//echo '<b>Date  :</b>' .$new_date.'</br>';
	?>
    &nbsp;</td>
  </tr>
  <tr>
    <td><?php if($row['type']=='file'){
		echo '<b>File Size&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>';
		} 
		else{
			echo 'Plot Size:&nbsp;';}?></td>
    <td>
<?php
    echo $row['size'].' ('.$row['plot_size'].')';
	//echo '<b>Date  :</b>' .$new_date.'</br>';
	?>
    &nbsp;</td>
  </tr>
  <tr>
    <td>Location     :&nbsp;</td>
    <td>
<?php
	echo $row['sector_name'].'/'.$row['street'];
	//echo '<b>Date  :</b>' .$new_date.'</br>';
	?>
    &nbsp;</td>
  </tr>
  <tr>
    <td>Project     :&nbsp;</td>
    <td>
<?php
    echo $row['project_name'];
	//echo '<b>Date  :</b>' .$new_date.'</br>';
	?>
    &nbsp;</td>
  </tr>
  <?php
	$price=$row['price'];
	}  ?><?php $numbers=0;?>
</table>
</td>
    <td><h4>Member Details</h4>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<?php $res=array();
    foreach($members as $mem){             
?>  <tr>
    <td style="width:90px">Name:&nbsp;</td>
    <td>
<?php
	echo $mem['name'];
	//echo '<b>Date  :</b>' .$new_date.'</br>';
	?>
    &nbsp;</td>
  </tr>
  <tr>
    <td>CNIC # :&nbsp;</td>
    <td>
<?php
    echo $mem['cnic'];
	//echo '<b>Date  :</b>' .$new_date.'</br>';
	?>
    &nbsp;</td>
  </tr>
  <tr>
    <td>Membership # :&nbsp;</td>
    <td>
<?php
	echo $mem['plotno'];
	//echo '<b>Date  :</b>' .$new_date.'</br>';
	?>
    &nbsp;</td>
  </tr>
  <?php
	}  ?>
</table>
    </td>
  </tr>
</table>

 <span style="float:right;">
	

	</span>
    
  <?php



// Check connection



$reciveable=0;

$paid=0;
$due=0;
$duesurcharge=0;
$paidsurcharge=0;



?>

  <table class="table table-striped table-new table-bordered">
    <thead style="background:#666; border-color:#ccc; color:#fff; ">
      <tr>
        <th style="width:125px"><b>Installment </b></th>
       <th style="width:65px"><b>Due Date</b></th>
        <th style="width:65px"><b>Paid Date</b></th>
        <th><b>Due Amount</b></th>
        <th><b>Paid Amount</b></th>
       <th><b>Payment Mode</b></th>
        <th><b>DD/PO/CH No.</b></th>
        <th><b>Receipt</b></th>
        <th><b>Due Surcharge</b></th>
          <th><b>Paid Surcharge</b></th>
        <th><b>Remarks</b></th>
        <th><b>Status</b></th>
      </tr>
    </thead>
    <tbody>
     <?php
	    $i=1;
	 $ins='';
	$res=array();
	foreach($payments as $pay)
	{	
$i++;
  $due=$due+$pay['dueamount'];
  $paid=$paid+$pay['paidamount'];
   $duesurcharge=$duesurcharge+$pay['surcharge'];
    $paidsurcharge=$paidsurcharge+$pay['paidsurcharge'];
	$oins=$due-$paid;
 	$co1=1;
	 foreach($payments as $pay2){if($pay2['ref']==$pay['id']){$co1++;}}
	if($pay['ref']==0){
		
  echo '<tr><td rowspan="'.$co1.'">'.$pay['lab']. '</td>

     <td rowspan="'.$co1.'">'.$pay['due_date'].'</td>
     <td>'.$pay['paid_date'].'</td>
     <td rowspan="'.$co1.'" style="text-align:right">'.$pay['dueamount'].'</td>
     <td style="text-align:right">'.$pay['paidamount'].'</td>
     <td>'.$pay['payment_type'].'</td>
     <td>'.$pay['detail'].'</td>
	 <td>';
	 if($pay['r_id']>0){
	  	$re1 = "SELECT * FROM rpt_print where rid='".$pay['r_id']."' and msid='".$pay['plot_id']."'";
		$rec1=$connection->createCommand($re1)->queryRow();	
		echo $rec1['r_no'];
		}; 
  if($pay['re_id'] > 0){ 
  		$re = "SELECT * FROM rpt_print where id='".$pay['re_id']."'";
		$rec=$connection->createCommand($re)->queryRow();
		echo $rec['r_no'];
		}
	 echo '</td>
     <td align="right">'.$pay['surcharge'].'</td>
	 <td align="right">'.$pay['paidsurcharge'].'</td>
     <td>'.$pay['remarks'].'</td>
     <td>';if(!empty($pay['fstatus'])){if($pay['fstatus']=='approved'){ echo '<b style="color:Green;">Verified</b>';}else{echo '<b style="color:red;">'.$pay['fstatus'].'</b>';} }
	 $id='';
	$id=$pay['id'];
	 }
	 foreach($payments as $pay1){
	 if($pay1['ref']==$id){
	echo '<tr>

    
     <td>'.$pay1['paid_date'].'</td>
     <td style="text-align:right">'.$pay1['paidamount'].'</td>
     <td>'.$pay1['payment_type'].'</td>
     <td>'.$pay1['detail'].'</td>
	 <td>';
	 if($pay['r_id']>0){
	  	$re1 = "SELECT * FROM rpt_print where rid='".$pay['r_id']."' and msid='".$pay['plot_id']."'";
		$rec1=$connection->createCommand($re1)->queryRow();	
		echo $rec1['r_no'];
		}; 
  if($pay['re_id'] > 0){ 
  		$re = "SELECT * FROM rpt_print where id='".$pay['re_id']."'";
		$rec=$connection->createCommand($re)->queryRow();
		echo $rec['r_no'];
		}
	 echo '</td>
     <td align="right">'.$pay1['surcharge'].'</td>
	 <td align="right">'.$pay1['paidsurcharge'].'</td>
     <td>'.$pay1['remarks'].'</td>
     <td>';if(!empty($pay1['fstatus'])){if($pay1['fstatus']=='approved'){ echo '<b style="color:Green;">Verified</b>';}else{echo '<b style="color:red;">'.$pay1['fstatus'].'</b>';} }
	
	}}
	
	 }
	
	echo '<tr><td><b>Total:</b></td>
<td></td>
<td></td>
<td align="right"><b>'.number_format($due).'</b></td>
<td align="right"><b>'.number_format($paid).'</b></td>
<td></td>
<td></td>
<td align="right"><b>'.number_format($duesurcharge).'</b></td>
<td align="right"><b>'.number_format($paidsurcharge).'</b></td>
<td></td>
<td></td>
<td></td>
</tr>';
echo '</tr>
<tr><td><b>Discount:</b></td>
<td></td>
<td></td>
<td align="right"></td><td style="text-align:right"><b>'.$discountr['discount'].'</b></td>
<td></td>
<td align="right"></td>
<td></td><td align="right"></td><td style="text-align:right"><b>'.$discountr['details'].'</b></td>
<td></td>
</tr>';
if($due==0){$due=1;}
echo '<tr><td><b>Outstanding Installment</b></td><td></td><td></td><td><b>'.number_format($oins-$discountr['discount']).'</b></td><td><b>'.number_format(($oins-$discountr['discount'])/$due*100).'%'.'</b></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>

';

	?>
    </tbody>
  </table>
</section>
             
</body>
</html>
</textarea>
<input style="float:left;" type="submit" name="submit" value="Print Report" /></form>
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">
<hr noshade="noshade" class="hr-5">