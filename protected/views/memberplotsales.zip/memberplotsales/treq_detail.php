<div class="shadow">
  <h3>Transfer Request Details</h3>
</div>
<section class="reg-section margin-top-30" style="font-size=12px;">
  <?php	            $res=array();
             $key=$plotdetails;
$connection = Yii::app()->db;
$fstatus=$key['fstatus'];
 	$comment=$key['comment'];
$sql_details1  = "SELECT * FROM members where id=".$key['transferfrom_id']."";
$result_details1 = $connection->createCommand($sql_details1)->queryRow();
$imges=Yii::app()->baseUrl.'/upload_pic/'.$result_details1['image'];?>
<div class="span12" style="">
<div class="span6 left-box">
  <h5 style="text-align:left;">Transfer From (Transferor) </h5>
 <table class="table table-striped table-new table-bordered">
 <tbody>
<tr><td rowspan="7"> <img width="150px" src="<?php echo $imges?>"/></td></tr>
      <input type="hidden" value="" name="transfer_from_memberid" id="member_id" class="reg-login-text-field" />
<tr><td>    MS #:</td><td><?php echo $plotdetails['plotno']?></td></tr>
<tr><td>	Saller Name :</td><td><?php echo $result_details1['name']?></td></tr>
<tr><td>    SODOWO:    </td><td><?php echo $result_details1['sodowo']?></td></tr>
<tr><td>    CNIC:    </td><td><?php echo $result_details1['cnic']?></td></tr>
<tr><td>    Address:</td><td><?php echo substr($result_details1['address'],0,40)?></td></tr>
<tr><td>    Email:</td><td><?php $result_details1['email']?></td></tr>
</tbody></table>
</div>
<?php 
$connection = Yii::app()->db; 	
$sql_details  = "SELECT * FROM members where id=".$key['transferto_id']."";
$result_details = $connection->createCommand($sql_details)->queryRow();
$imgesr=Yii::app()->baseUrl.'/upload_pic/'.$result_details['image'];
?>
<div class="span6 left-box">

  <h5 style="text-align:left;">Transfer To (Transferee)</h5>
<table class="table table-striped table-new table-bordered">
 <tbody>
<tr><td rowspan="7"><img width="150px" src="<?php echo $imgesr?>"/></td></tr>
<tr><td>	MS #:</td><td><?php echo $plotdetails['tempms']?></td></tr>
<tr><td>	Purchaser Name :</td><td><?php echo $result_details['name']?></td></tr>
<tr><td>    SODOWO:    </td><td><?php echo $result_details['sodowo']?></td></tr>
<tr><td>    CNIC:    </td><td><?php echo $result_details['cnic']?></td></tr>
<tr><td>    Address:</td><td><?php echo substr($result_details['address'],0,40)?></td></tr>
<tr><td>    Email:</td><td><?php echo $result_details['email']?></td></tr>
</tbody></table>
	</div>
    
</div>
<div class="span12">
<div class="span6">
  <h5 style="text-align:left;">Plot Details</h5> 
   <table class="table table-striped table-new table-bordered">
 <tbody>	
<tr><td>	File/Plot No.</td><td><?php echo $key['plot_detail_address']?></td></tr>
<input type="hidden" value="" name="plot_id" id="plot_id" class="f-left span4 clearfix" />
<tr><td>  	File/Plot Address:</td><td><?php echo $key['street']?>,<?php echo $key['sector_name']?></td></tr>
<tr><td>  	Plot Size:</td><td><?php echo $key['size']?>(<?php echo $key['plot_size']?>)</td></tr>
<tr><td>  	Project Name:</td><td><?php echo $key['project_name']?></td></tr>
</tbody></table>
    <?php	
	$connection = Yii::app()->db; 	
$sql_details2  = "SELECT * FROM plots where id=".$key['plot_id']."";
$result_details2 = $connection->createCommand($sql_details2)->queryRow();

$sql_install  = "SELECT * FROM installpayment where plot_id=".$key['plot_id']."";
$result_install= $connection->createCommand($sql_install)->queryAll();
$pai=0;
$rem=0;
foreach($result_install as $row5){if(empty($row5['paidamount'])){$rem=$rem+$row5['dueamount'];}
if(!empty($row5['paidamount'])){$pai=$pai+$row5['paidamount'];}
}
$sql_details3  = "SELECT * FROM memberplot where plot_id=".$key['plot_id']."";
$result_details3 = $connection->createCommand($sql_details3)->queryRow();
$old_date = $key['create_date'];            
$middle = strtotime($old_date);             
$new_date = date('d-m-y', $middle); 
	?>
    
    <?php $home=Yii::app()->request->baseUrl.'/index.php'; ?>
    <h5 style="text-align:left;">Price/Installments: <a style="float:right;" href="<?php echo $home?>/memberplot/payment_details?id=<?php echo $key['plot_id']; ?>&&pid=">Payment Details List</a><br></h5>
   <table class="table table-striped table-new table-bordered">
 <tbody>	
<tr><td>    Cost Of Plot:</td><td><?php echo number_format($result_details2['price']);  ?></td></tr>
<tr><td>     Paid:</td><td><?php echo number_format($pai);  ?></td></tr>
<tr><td>      Balance:</td><td><?php echo number_format($rem);?></td></tr>
</tbody></table>

    <h5 style="text-align:left;">Request Details:</h5>
   <table class="table table-striped table-new table-bordered">
 <tbody>	
<tr><td>    Request Date:</td><td><?php echo $new_date  ?></td></tr>
<tr><td>    User Name:</td><td><?php echo $key['firstname']?> <?php $key['middelname']?> <?php $key['lastname'] ?></td></tr>
<tr><td>    Sales Center:</td><td><?php echo $key['ssname'] ?></td></tr>
</tbody></table>
    <h5 style="text-align:left;">Admin Status:</h5>
   <table class="table table-striped table-new table-bordered">
 <tbody>	
<tr><td>    Comment:</td><td><?php echo $key['cmnt']  ?></td></tr>
<tr><td>     Status:</td><td><?php echo $key['status']?></td></tr>
</tbody></table>
    </div>
	<div class="span6 left-box" style="
    background-color: #4cd6d4;
    padding: 20px;
    border: 1px solid #000;
    border-radius: 25px;
">
  
    
    <h4>Update Payments (Purchaser)</h4>
  <a class="btn" href="plotchargest?id=<?php echo $key['plot_id']?>&pid=<?php $key['project_id']?>&m=<?php $result_details['id'] ?>">Add Charges </a>
	<?php 
	$stat=$result_details['status'];
	$plotid=$_REQUEST['id'];
	if($stat==0){echo '<h4>Transfer to member is not active register member please update<br/><a href="'.$this->CreateAbsoluteUrl("user/update_member?id=".$key['transferto_id']."").'">Update Member</a></h4> ';}
	?>
  <h4>Documentation</h4>
  <a class="btn" href="doc?id=<?php echo $key['tpid'] ?>">Upload Documents</a>

<?php
 if($plotdetails['com_res']=='Commercial'){$type='C'; }else{$type='R';}
  $path="/images/imagetransfer/";
 
$address= 'http://'.$_SERVER['HTTP_HOST'].Yii::app()->request->baseUrl;;
?>
  <h4>Upload Transfer Photo </h4>

<form action="timage"  enctype="multipart/form-data" method="post"  >
										<input type="hidden" name="plot_id" value="<?php echo $key['plot_id']?>" />
                                        <input type="hidden" value="<?php echo $_REQUEST['id'] ?>" name="reqid" id="reqid"/>
										<input type="file" name="image" class="btn">
										<input type="submit" name="upload" value="Upload" class="btn">
										</form>
                                        <a href="<?php echo $address.$path.$key['image']?>"><img src="<?php echo $address.$path.$key['image']?>" height="100px" width="100" /></a> 
	

    <?php 
	if(Yii::app()->session['user_array']['per20']==1 && $plotdetails['tpsts']=='Sales'){
	$form=$this->beginWidget('CActiveForm', array(
 'id'=>'user_login_form',
 'enableAjaxValidation'=>false,
  'enableClientValidation'=>true,
                'method' => 'POST',
                'clientOptions'=>array(
                     'validateOnSubmit'=>true,
                     'validateOnChange'=>true,
                     'validateOnType'=>false,
  ),
)); ?>
<div id="error-div" class="errorMessage" style="display: none; color:#F00; font-weight:bold;"></div>

    
    <input type="hidden" name="ploid"  value="<?php echo $key['plot_id'];?>" />
	
    <input type="hidden" name="pid"  value="<?php echo $_REQUEST['id'];?>" />
    <label>New MS #</label>
    <input type="text" value="<?php echo $plotdetails['code'] ?>" name="procode" id="procode" class="reg-login-text-field" style="width:60px;"  readonly/>
	<input type="text" value="" name="tempms" id="tempms" class="reg-login-text-field" style="width:140px;" />
    <input type="text" value="<?php echo $type.$plotdetails['scode']; ?>" name="sizecode" id="sizecode" class="reg-login-text-field" style="width:60px;" readonly/>
    
     <?php echo CHtml::ajaxSubmitButton('Submit For Approvel',array('Submitt'), array( 'beforeSend' => 'function(){ 
                                             $("#login").attr("disabled",true);
       										     }',
                                        'complete' => 'function(){ 
                                             $("#user_login_form").each(function(){});
                                             $("#login").attr("disabled",false);
                                        }',
					                   'success'=>'function(data){  
                                             if(data == 1){
                                         location.href = "http://rdlpk.com/index.php/user/dashboard";
                                      }
          									else{
                                                $("#error-div").show();
                                                $("#error-div").html(data);$("#error-div").append("");
												return false;
                                             }}'     ),
                         array("id"=>"login","class" => "btn")      
                ); ?>
<?php $this->endWidget(); }
?>
   
  
    </div>
    </div>
    <?php if($key['status']!=='Approved'){?>
    <a href="canceltreq?" class="btn" style="float:right;" >Cancel(Remove) Request</a><?php //}?>
    <?php }?>
    <div style="height: 600px;

    padding: 0 0 0 32px;

    width: 300px;"> <span style="color:#FF0000; display:block;" id="error-pending"></span> <span style="color:#FF0000;display:block;" id="error-cmnt"></span> <span style="color:#FF0000; display:block;" id="memerror"></span> <span style="color:#FF0000; display:block;" id="plotno"></span> <span style="color:#FF0000; display:block;" id="image"></span> </div>
 
 
  </div>
  <div class="clearfix"></div>
</section>

<!-- section 3 -->

<div class="clearfix"></div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> 
<script>

  $(document).ready(function()
     {   $("#plotno").change(function()
           {
         	select_mem($(this).val());
		   });
		    });


function select_mem(id)
{
$.ajax({
      type: "POST",
      url:    "ajaxRequest6?val1="+id,
	  contenetType:"json",
      success: function(jsonList){var json = $.parseJSON(jsonList);
	  
var listItems='';
	$(json).each(function(i,val){
	listItems+= "<option value='" + val.id + "'>Membership number Already in DB</option>";
      
});listItems+="";

$("#memerror").html(listItems);
          }
});
}
function validateForm(){
	$("#error-pending").hide();
	$("#error-cmnt").hide();
	$("#error-image").hide();
	//	var x=document.forms["form"]["firstname"].value;
	var a = $("#status").val();
	var d = $("#cmnt").val();
	
	var counter=0;



if (a==null || a=="" )

  {

  $("#error-pending").html("Select Status");

  $("#error-pending").show();

  counter =1;

  }


  if (d==null || d=="")

  {

  $("#error-cmnt").html("Please Give Some Comments");

  $("#error-cmnt").show();

  counter =1;

  }
 
 

  if(counter==1)

  	return false;

  

}

 <!--VALIDATION END-->
 

 </script> 